require "spec_helper"

describe Notifier do

  describe 'send mail to assignee' do

    let(:issue) { create :issue }
    let(:user){create(:user, :confirmed, :email => "dummyuser@fooda.com")}
    let(:event){create(:event)}

    let(:issue_mail) { Notifier.send_issue_to_assignee(issue) }
    let(:welcome_c_email) { Notifier.send_catering_welcome_email_to_created_user(user, "dummypassword") }
    let(:welcome_s_email) { Notifier.send_select_welcome_email_to_created_user(user, "dummypassword") }
    let(:feedback) { Notifier.send_feedback_email(event) }
    let(:failure) { Notifier.send_transaction_failure_report("dummy title", "dummy description") }
 
    describe "send_issue_to_assignee email" do
      #ensure that the subject is correct
      it 'renders the subject' do
        issue_mail.subject.should == "[Fooda] You have been assigned a new issue."
      end
   
      #ensure that the receiver is correct
      it 'renders the receiver email' do
        issue_mail.to.should == [issue.assignee.email]
      end
   
      #ensure that the sender is correct
      it 'renders the sender email' do
        issue_mail.from.should == ['snappea@fooda.com']
      end
    end

    describe "send_catering_welcome_email_to_created_user email" do
      #ensure that the subject is correct
      it 'renders the subject' do
        welcome_c_email.subject.should == "Your Fooda account was created!"
      end
   
      #ensure that the receiver is correct
      it 'renders the receiver email' do
        welcome_c_email.to.should == [user.email]
      end
   
      #ensure that the sender is correct
      it 'renders the sender email' do
        welcome_c_email.from.should == ['info@fooda.com']
      end
    end


    describe "send_select_welcome_email_to_created_user email" do
      #ensure that the subject is correct
      it 'renders the subject' do
        welcome_s_email.subject.should == "Your Fooda account was created!"
      end

      #ensure that the receiver is correct
      it 'renders the receiver email' do
        welcome_s_email.to.should == [user.email]
      end

      #ensure that the sender is correct
      it 'renders the sender email' do
        welcome_s_email.from.should == ['info@fooda.com']
      end
    end

    describe "send_feedback_email" do
      #ensure that the subject is correct
      it 'renders the subject' do
        product_type = Product.find_parent(event.product)
        if product_type == "managed_services"
          feedback.subject.should == "Rate Your Catering Event"
        else
          feedback.subject.should == "Fooda Catering - Event Feedback"
          
        end
      end
   
      #ensure that the receiver is correct
      it 'renders the receiver email' do
        feedback.to.should == [event.contact.email]
      end
   
      #ensure that the sender is correct
      it 'renders the sender email' do
        feedback.from.should == ['info@fooda.com']
      end
    end

    describe "send_transaction_failure_report" do
      #ensure that the subject is correct
      it 'renders the subject' do
        failure.subject.should == "dummy title"
      end
   
      #ensure that the receiver is correct
      it 'renders the receiver email' do
        failure.to.should == ["accounting@fooda.com"]
      end
   
      #ensure that the sender is correct
      it 'renders the sender email' do
        failure.from.should == ['info@fooda.com']
      end
    end

  end

end
