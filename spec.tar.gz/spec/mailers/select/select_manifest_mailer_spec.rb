require 'spec_helper'

describe Select::SelectManifestMailer do

  let(:date) { DateTime.now.strftime("%Y-%m-%d") }
  let(:period) { "Lunch" }

  # Select Event w/ multiple MTs
  let(:select_event) do
    create(:select_event, :with_location_delivery_group,
                          :with_bloated_vendor,
                          ordering_window_end_time_utc: 1.hour.from_now.utc)
  end

  let(:user) { create(:user, :confirmed, accounts: [select_event.account]) }

  # First Order from Event 1 to Vendor 1
  let (:select_order) do
    create(:select_order, select_event: select_event,
                          user: user,
                          location: select_event.locations.first,
                          status: :checkout_complete)
  end
  let (:select_order_item_1) do
    create(:select_order_item, inventory_item: select_event.vendors.first.menu_templates.last.inventory_items.first,
                               vendor: select_event.vendors.first,
                               select_order: select_order,
                               special_instructions: 'Extra special sauce',
                               quantity: 1,
                               status: :current)
  end
  let (:select_order_item_2) do
    create(:select_order_item, inventory_item: select_event.vendors.first.menu_templates.last.inventory_items.first,
                               vendor: select_event.vendors.first,
                               select_order: select_order,
                               quantity: 1,
                               status: :current)
  end

  let (:select_manifest) do
    create(:select_manifest, vendor: select_event.vendors.first,
                             select_events: [select_event])

  end

  let (:contact) { create(:contact, :primary, vendor: select_event.vendors.first) }

  let (:mail) { Select::SelectManifestMailer.vendor_email(select_manifest) }

  before do
    select_order.select_order_items = [select_order_item_1, select_order_item_2]
  end

  describe 'select manifest mailer' do

    it 'renders the subject' do
      mail.subject.should =~ Regexp.new("^Fooda Select Manifest " + select_manifest.id.to_s + ".*" + select_manifest.vendor.name)
    end

    it 'receiver emails contain fooda internal and vendor contact emails', focus: true do
      contact.should be_valid
      mail.to.should == ['selectops@fooda.com', contact.email, contact.fax_number.gsub(/[^0-9]+/, '') + '@maxemailsend.com']
    end

    it 'renders the sender email' do
      mail.from.should == ['info@fooda.com']
    end

  end
end
