require 'spec_helper'

describe "/select_event_vendors/_menu_groups" do
  
  let(:user){ create(:user) }
  let(:select_event){ create(:select_event_with_locations) }
  let(:select_event_vendor){ create(:select_event_vendor, select_event: select_event) }
  let(:select_event_menu_group_featured){ create(:select_event_menu_group, name: "Featured") }
  let(:select_event_menu_group_all_other){ create(:select_event_menu_group, name: "All Other") }
  let(:select_event_menu_item){ create(:select_event_menu_item, select_event_menu_group: select_event_menu_group_featured)}

  before do
    select_event_menu_group_featured.select_event_menu_items << select_event_menu_item
    select_event_vendor.select_event_menu_groups << select_event_menu_group_featured
    select_event_vendor.select_event_menu_groups << select_event_menu_group_all_other
    assign(:select_event, select_event)
    render partial: "/select_event_vendors/menu_groups", locals: {select_event_vendor: select_event_vendor}
  end

  it "has proper table elements" do
    rendered.should have_selector "th", "Name (Public)"
    rendered.should have_selector "th", "Name (Vendor)"
    rendered.should have_selector "th", "Type"
    rendered.should have_selector "th", "Description"
    rendered.should have_selector "th", "Options"
    rendered.should have_selector "th", "COGS"
    rendered.should have_selector "th", "Retail Price"
    rendered.should have_selector "th", "Action"
  end

  it "renders select order information" do
    rendered.should have_content("#{select_event_menu_item.inventory_item.name_public}")
  end
end
