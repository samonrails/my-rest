require 'spec_helper'

describe "/select_event_vendors/_edit.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
