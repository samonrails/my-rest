require 'spec_helper'

describe "/inventory_items/_user_reviews.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
