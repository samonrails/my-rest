require 'spec_helper'

describe "/select_events/_select_event.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
