require 'spec_helper'

describe "/select_events/partials/_select_event_vendors.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
