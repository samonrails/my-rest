require 'spec_helper'

describe "/select_events/partials/_select_event_vendor_notifications_log.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
