require 'spec_helper'

describe "/select_events/_delivery.html.haml" do
	let(:market) { create(:market) }
	let(:building) { create(:building) }
	let(:location) { create(:delivery_location, building: building) }
	let(:delivery_group) { create(:delivery_group) }
	let(:delivery_groups_location) { create(:delivery_groups_location, delivery_group: delivery_group, location: location) }
	let(:restaurant_vendor) { create(:vendor, market_list: market.name) }
	let(:delivery_vendor) { create(:vendor, market_list: market.name, vendor_type: "Delivery Service") }
	let(:select_event) { create(:select_event_with_locations) }
	let(:select_event_vendor) { create(:select_event_vendor, :skip_callbacks, select_event: select_event, vendor: restaurant_vendor) }

	before { render partial: "select_events/delivery", locals: { select_event: select_event } }

	describe "delivery directions" do
		it "includes building loading information" do
			rendered.should have_selector "#select_event_select_event_buildings_attributes_0_notes", text: select_event.location.building.loading_information
		end
		
		it "includes building site directions" do
			rendered.should have_selector "#select_event_select_event_buildings_attributes_0_notes", text: select_event.location.building.site_directions
		end

		it "includes building parking information" do
			rendered.should have_selector "#select_event_select_event_buildings_attributes_0_notes", text: select_event.location.building.parking_information
		end

		it "includes location delivery event instructions" do
			rendered.should have_selector "#select_event_select_event_buildings_attributes_0_notes", text: select_event.location.delivery_event_instructions
		end
	end

	describe "delivery instructions" do
		it "includes the default delivery instructions" do
			rendered.should have_selector "#select_event_select_event_locations_attributes_0_delivery_notes", text: "Lay out the food items individually in"
		end

		it "includes the location building address notes (drop off point)" do
			rendered.should have_selector "#select_event_select_event_locations_attributes_0_delivery_notes", text: select_event.location.building_address_notes
		end
	end

	it "shows the available delivery groups for the select event" do
		rendered.should have_selector "#select_event_delivery_group_id" do |s|
			s.should have_selector "option", text: delivery_group.name
		end
	end

	it "shows the select event vendors" do
		rendered.should have_selector "table tbody" do |s|
			s.should have_selector "td", text: select_event_vendor.vendor.name
		end
	end

	it "shows the available delivery vendors for the select event vendors" do
		rendered.should have_selector ".controls select" do |s|
			s.should have_selector "option", text: delivery_vendor.name
		end
	end

	it "needs these selectors for JS to work" do
		rendered.should have_selector "p#drop-priority"
		rendered.should have_selector "a#delivery-group-edit-link"
	end

end
