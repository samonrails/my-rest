require 'spec_helper'

describe "/events/show.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
