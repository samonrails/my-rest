require 'spec_helper'

describe "/events/partials_dashboard/_event.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
