require 'spec_helper'

describe "/events/partials_dashboard/_my_events.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
