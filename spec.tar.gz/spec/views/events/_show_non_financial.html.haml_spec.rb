require 'spec_helper'

describe "/events/_show_non_financial.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
