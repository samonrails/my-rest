require 'spec_helper'

describe "/events/partials_payment/_payment_history.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
