require 'spec_helper'

describe "/menu_templates/change_inventory_items.js.coffee" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
