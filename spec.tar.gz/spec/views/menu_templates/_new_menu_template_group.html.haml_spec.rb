require 'spec_helper'

describe "/menu_templates/_new_menu_template_group.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
