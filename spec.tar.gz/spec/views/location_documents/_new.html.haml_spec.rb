require 'spec_helper'

describe "/location_documents/_new.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
