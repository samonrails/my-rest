require 'spec_helper'

describe "/devise/shared/_links.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
