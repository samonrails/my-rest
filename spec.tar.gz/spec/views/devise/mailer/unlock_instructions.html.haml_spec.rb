require 'spec_helper'

describe "/devise/mailer/unlock_instructions.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
