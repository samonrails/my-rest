require 'spec_helper'

describe "/devise/unlocks/new.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
