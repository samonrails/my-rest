require 'spec_helper'

describe "/documents/templates/default_document.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
