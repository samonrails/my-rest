require 'spec_helper'

describe "/documents/templates/popup_voucher.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
