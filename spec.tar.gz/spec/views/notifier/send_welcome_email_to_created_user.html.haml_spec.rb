require 'spec_helper'

describe "/notifier/send_welcome_email_to_created_user.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
