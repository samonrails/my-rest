require 'spec_helper'

describe "/settings/account/orders/_order_tile_vouchers.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
