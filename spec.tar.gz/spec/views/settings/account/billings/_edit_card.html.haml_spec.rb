require 'spec_helper'

describe "/settings/account/billings/_edit_card.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
