require "spec_helper"

describe "settings/profiles/show.html.haml" do
  let(:user){ FactoryGirl.create(:user) }

  before do
    view.stub(current_user: :user)
  end

  it "has this form" do
    render
    rendered.should have_selector "form", admin_user_path(user) do |s|
      s.should have_selector :input, name: "user[first_name]"
      s.should have_selector :input, name: "user[last_name]"
      s.should have_selector :input, name: "user[email]"
      s.should have_selector :input, name: "user[phone_number]"
      s.should have_selector :input, name: "user[position]"
      s.should have_selector :input, type: "submit"
    end
  end

end
