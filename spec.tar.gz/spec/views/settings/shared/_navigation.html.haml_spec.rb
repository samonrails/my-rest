require "spec_helper"

describe "/settings/shared/_navigation.html.haml" do
  let(:user){ FactoryGirl.create(:user) }
  let(:account){ FactoryGirl.create(:account) }

  before do
    user.accounts << account
    sign_in_user(user)
  end

  describe "the sidebar" do
    it "has these links" do
      render
      rendered.should have_link "Profile", settings_profile_path
      rendered.should have_link "Orders", settings_orders_path
      rendered.should have_link "Locations", settings_locations_path
      rendered.should have_link "Payment Methods", settings_payments_path
    end

    it "has these organizational links" do
      pending 'orgnaizations were scoped out of this release. use these test when we add them again.'
      render
      rendered.should have_link "Profile", settings_account_profile_path(account_id: account.id)
      rendered.should have_link "Company Order History", settings_account_orders_path(account_id: account.id)
      rendered.should have_link "Members", settings_account_members_path(account_id: account.id)
      rendered.should have_link "Delivery Contacts", settings_account_contacts_path(account_id: account.id)
      rendered.should have_link "Delivery Locations", settings_account_locations_path(account_id: account.id)
      rendered.should have_link "Billing Information", settings_account_billings_path(account_id: account.id)
    end
  end
end
