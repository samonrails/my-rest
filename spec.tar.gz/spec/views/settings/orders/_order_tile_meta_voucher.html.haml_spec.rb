require 'spec_helper'

describe "/settings/orders/_order_tile_meta_voucher.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
