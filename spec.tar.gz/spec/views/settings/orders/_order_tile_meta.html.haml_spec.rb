require 'spec_helper'

describe "/settings/orders/_order_tile_meta.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
