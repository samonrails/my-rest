require "spec_helper"

describe "/settings/orders/index.html.haml" do

  let(:user){ FactoryGirl.create(:user) }
  let(:order){ FactoryGirl.create(:order) }
  let(:order_builder){ OrderBuilder.new(order) }

  before do
    assign(:order_builders, [order_builder])
  end

  it "is a total glob." do
    pending "have fun..."
  end

end
