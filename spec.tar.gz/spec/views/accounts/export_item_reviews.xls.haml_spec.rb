require 'spec_helper'

describe "/accounts/export_item_reviews.xls.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
