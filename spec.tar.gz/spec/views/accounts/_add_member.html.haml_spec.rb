require 'spec_helper'

describe "/accounts/_add_member.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
