require 'spec_helper'

describe "/products/_form.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
