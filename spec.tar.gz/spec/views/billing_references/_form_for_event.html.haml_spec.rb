require 'spec_helper'

describe "/billing_references/_form_for_event.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
