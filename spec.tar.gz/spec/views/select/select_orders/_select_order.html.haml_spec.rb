require 'spec_helper'

describe "/select/select_orders/_select_order" do

	# @select_order = FactoryGirl.create(:select_order)

	# before do
	# 	assign(:select_order, @select_order)
	# 	render
	# end

	# describe "when an order is placed" do

	# 	it "displays info" do
	# 		select_order = FactoryGirl.create(:select_order)
	# 		assign(:select_order, select_order)
	# 		render
	# 		rendered.should have_selector 'tr'
	# 	end

	# end

end