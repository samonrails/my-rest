require 'spec_helper'

describe "/select/select_orders/_new" do

	let(:select_order) { create(:select_order)}

	before do
		assign(:select_order, select_order)
		@select_event = select_order.select_event
		render
	end

	it "has the add order headline" do
		rendered.should have_selector("h3", text: "Add Order - Choose User")
	end
	
	it "has form to select user" do
		rendered.should have_selector 'form' do |s|
			s.should have_field 'input', type: 'collection', name: 'select_order[user]'
			s.should have_field 'input', type: 'hidden', value: "#{@select_event.id}"
			s.should have_field 'input', type: 'submit'
		end
	end

	it "has form to create new user" do
		rendered.should have_selector('a', text: 'Create New User')
		rendered.should have_selector 'form' do |s|
			s.should have_field 'simple_fields_for'
			s.should have_field 'input', name: 'select_order_first_name'
			s.should have_field 'input', name: 'select_order_last_name'
			s.should have_field 'input', name: 'select_order_email'
			s.should have_field 'input', name: 'select_order_phone_number'
			s.should have_field 'input', name: 'select_order_position'
			s.should have_field 'input', type: 'collection', name: 'select_order_first_name'
		end
	end

	it "has option to send welcome email" do
		rendered.should have_selector 'form' do |s|
			s.should have_field 'input', type: 'checkbox', name: 'send_email'
		end
	end	
end