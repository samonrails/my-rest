require 'spec_helper'

describe "/select/select_orders/show" do

	before do
		expect("select/select_orders/_show")
	end

end