require 'spec_helper'

describe "/select/select_orders/new_inventory_item.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
