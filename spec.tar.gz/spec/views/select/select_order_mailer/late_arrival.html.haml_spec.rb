require 'spec_helper'

describe "/select/select_order_mailer/late_arrival.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
