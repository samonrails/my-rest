require 'spec_helper'

describe "/locations/_edit_form_delivery_location.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
