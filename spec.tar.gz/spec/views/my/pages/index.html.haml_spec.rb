require 'spec_helper'

describe "/my/pages/index.html.haml" do
end
