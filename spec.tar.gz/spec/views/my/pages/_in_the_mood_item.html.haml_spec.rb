require 'spec_helper'

describe "/my/pages/_in_the_mood_item.html.haml" do
end
