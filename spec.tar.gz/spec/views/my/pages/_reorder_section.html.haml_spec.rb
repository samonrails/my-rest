require 'spec_helper'

describe "/my/pages/_reorder_section.html.haml" do
end
