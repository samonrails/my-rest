require 'spec_helper'

describe "/my/pages/_call_to_action_section.html.haml" do

end
