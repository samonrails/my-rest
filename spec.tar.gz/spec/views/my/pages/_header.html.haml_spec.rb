require 'spec_helper'

describe "/my/pages/_header.html.haml" do
end
