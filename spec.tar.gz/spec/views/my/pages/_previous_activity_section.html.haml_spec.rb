require 'spec_helper'

describe "/my/pages/_previous_activity_section.html.haml" do
end
