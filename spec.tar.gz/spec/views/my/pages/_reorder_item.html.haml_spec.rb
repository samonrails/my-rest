require 'spec_helper'

describe "/my/pages/_reorder_item.html.haml" do
end
