require 'spec_helper'

describe "/my/pages/_in_the_mood_section.html.haml" do
end
