require 'spec_helper'

describe "/max_email_mailer/send_fax.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
