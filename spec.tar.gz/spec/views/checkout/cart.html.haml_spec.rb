require "spec_helper"

describe "/checkout/cart.html.haml" do

  it "should work" do
    pending "halp me"
  end

end
