require 'spec_helper'

describe "/checkout/_header" do

end