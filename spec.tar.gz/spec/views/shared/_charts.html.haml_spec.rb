require 'spec_helper'

describe "/shared/_charts.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
