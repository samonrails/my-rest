require 'spec_helper'

describe "/catering_report_mailer/vendor_billing_summary.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
