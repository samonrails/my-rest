require 'spec_helper'

describe "/catering_report_mailer/end_of_day_sales_report.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
