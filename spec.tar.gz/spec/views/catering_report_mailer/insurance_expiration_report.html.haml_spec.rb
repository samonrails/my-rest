require 'spec_helper'

describe "/catering_report_mailer/insurance_expiration_report.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
