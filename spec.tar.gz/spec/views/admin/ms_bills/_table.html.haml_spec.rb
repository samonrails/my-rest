require 'spec_helper'

describe "/admin/ms_bills/_table.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
