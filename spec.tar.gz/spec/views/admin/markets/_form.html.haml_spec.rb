require 'spec_helper'

describe "/admin/markets/_form.html.haml" do

  context "when form is used for a new market" do

  	before do
	    render :partial => "/admin/markets/form", :locals => {market: Market.new, title: "New Market"}
  	end

	  it "has correct fields in the this form" do
	  	rendered.should have_selector 'h3', text: 'New Market'
	    rendered.should have_selector "form", new_admin_market_path do |f|
	      f.should have_selector 'input', name: 'market[name]'
	      f.should have_selector 'input', name: 'market[default_tax_rate]'	  , text: "#{market.name}"
	      f.should have_selector 'input', type: collection, name: 'market[vendor_id]'
	      f.should have_selector 'input', name: 'market[office_default_phone]'
	      f.should have_selector 'input', name: 'market[office_default_fax]'
	      f.should have_selector 'input', name: 'market[office_default_sms]'
	      f.should have_selector 'input', name: 'market[office_default_email]'
	      f.should have_selector 'input', name: 'market[address1]'
	      f.should have_selector 'input', name: 'market[address2]'
	      f.should have_selector 'input', name: 'market[city]'
	      f.should have_selector 'input', name: 'market[state]'
	      f.should have_selector 'textarea', name: 'zip_codes'
	      f.should have_selector 'input', type: 'submit', name: 'commit', value: 'Create Market'
	    end
	  end

	end

  context "when form is used for existing market" do

  	let(:market){ FactoryGirl.create(:market) }

  	before do
	    render :partial => "/admin/markets/form", :locals => {market: market, title: "Edit Market"}
  	end

	  it "has correct fields in the this form" do
	  	rendered.should have_selector 'h3', text: 'Edit Market'
	    rendered.should have_selector "form" do |f|
	      f.should have_selector 'input', name: 'market[name]', text: "#{market.name}"
	      f.should have_selector 'input', name: 'market[default_tax_rate]', text: "#{market.default_tax_rate}"
	      f.should have_selector 'input', type: collection, name: 'market[vendor_id]', text: "#{market.vendor}"
	      f.should have_selector 'input', name: 'market[office_default_phone]', text: "#{market.office_default_phone}"
	      f.should have_selector 'input', name: 'market[office_default_fax]', text: "#{market.office_default_fax}"
	      f.should have_selector 'input', name: 'market[office_default_sms]', text: "#{market.office_default_sms}"
	      f.should have_selector 'input', name: 'market[office_default_email]', text: "#{market.office_default_email}"
	      f.should have_selector 'input', name: 'market[address1]', text: "#{market.address1}"
	      f.should have_selector 'input', name: 'market[address2]', text: "#{market.address2}"
	      f.should have_selector 'input', name: 'market[city]', text: "#{market.city}"
	      f.should have_selector 'input', name: 'market[state]', text: "#{market.state}"
	      f.should have_selector 'textarea', name: 'zip_codes'
	      f.should have_selector 'input', type: 'submit', name: 'commit', value: 'Save Market'
	    end
	  end

	end
end
