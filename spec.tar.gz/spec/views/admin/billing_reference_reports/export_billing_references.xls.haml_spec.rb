require 'spec_helper'

describe "/admin/billing_reference_reports/export_billing_references.xls.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
