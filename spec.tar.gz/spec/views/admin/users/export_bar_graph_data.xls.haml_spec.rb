require 'spec_helper'

describe "/admin/users/export_bar_graph_data.xls.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
