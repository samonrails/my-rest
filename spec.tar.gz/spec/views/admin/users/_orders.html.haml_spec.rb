require 'spec_helper'

describe "/admin/users/_orders" do
	
	let(:user){ create(:user) }
	let(:select_order){ create(:select_order, user_id: user.id) }

	before do
		assign(:select_orders, Kaminari.paginate_array([select_order]).page(1))
		render
	end

	it "has proper table elements" do
		rendered.should have_selector "th", "Order ID"
		rendered.should have_selector "th", "Email"
		rendered.should have_selector "th", "Vendors"
		rendered.should have_selector "th", "Date"
		rendered.should have_selector "th", "# of Items Ordered"
		rendered.should have_selector "th", "# of Customized Items"
		rendered.should have_selector "th", "Payment Method"
		rendered.should have_selector "th", "Sub Total"
		rendered.should have_selector "th", "Subsidy Amount"
		rendered.should have_selector "th", "Additional Charges"
		rendered.should have_selector "th", "Payment Amount"
		rendered.should have_selector "th", "Payment Status"
	end

	it "renders select order information" do
		rendered.should have_content("#{pretty_id(select_order.id)}")
	end
end