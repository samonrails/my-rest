require 'spec_helper'

describe "/admin/delivery_groups/_accounts_by_market.html.haml" do
  let(:account){ FactoryGirl.create(:account) }
  let(:location){ FactoryGirl.create(:location) }
  let(:account_locations) { { account => [location] } }

  before do
    render :partial => "admin/delivery_groups/accounts_by_market", :locals => {account_locations: account_locations}
  end

  it "shows all accounts" do
    rendered.should have_selector "ul.account" do |s|
      s.should have_selector "li", location.name, data: {id: location.id, account: account.name, location: location.name}
    end
  end

end
