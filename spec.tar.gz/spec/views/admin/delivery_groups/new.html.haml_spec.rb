require 'spec_helper'

describe "/admin/delivery_groups/new.html.haml" do

  let(:account){ FactoryGirl.create(:account) }
  let(:location){ FactoryGirl.create(:location) }

  before do
    account.locations << location
  end

  it "has this form" do
    render
    rendered.should have_selector "form", admin_delivery_groups_path do |f|
      f.should have_selector 'input', name: 'delivery_group[name]'
      f.should have_selector 'select', name: 'delivery_group[market_id]'
      f.should have_selector 'select', name: 'delivery_group[vendor_id]'
      f.should have_selector 'input', type: 'submit', data: {id: 'save-delivery-group'}
    end
  end

  it "needs these divs for JS to work" do
    render
    rendered.should have_selector "#available-accounts-pane"
    rendered.should have_selector "ul#available-accounts"
    rendered.should have_selector "#selected-accounts-pane"
  end

  it "shows all markets" do
    render
    rendered.should have_selector 'option', text: "#{location.building.market.name}"
  end
end
