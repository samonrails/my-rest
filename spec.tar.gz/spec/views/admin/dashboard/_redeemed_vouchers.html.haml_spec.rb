require 'spec_helper'

describe "/admin/dashboard/_redeemed_vouchers.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
