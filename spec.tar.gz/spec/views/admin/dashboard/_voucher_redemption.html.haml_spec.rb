require 'spec_helper'

describe "/admin/dashboard/_voucher_redemption.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
