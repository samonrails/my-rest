require 'spec_helper'

describe "/admin/managed_services_reports/_summary_row.html.haml" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
