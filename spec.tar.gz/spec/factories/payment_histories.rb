# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :payment_history do
    transaction_id Time.now.to_i.to_s(36)
    cc_last4 ['1111', '0004', '4444', '7777', '1117', '0000', '0061'].sample
    customer_id { rand.to_s[2..9] }
    status ['authorized', 'authorization_expired', 'processor_declined', 'gateway_rejected', 'failed', 'voided', 'submitted_for_settlement', 'settling', 'settled'].sample
    amount { rand(100..1000) }
  
    association :event
    association :user, :factory => [:user, :confirmed]
  end
end
