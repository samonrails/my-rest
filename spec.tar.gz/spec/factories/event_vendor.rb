FactoryGirl.define do
  factory :event_vendor do
    participation             0
    default_menu_cogs_cents   825
    default_menu_sell_price_cents  1100
    default_menu_retail_price_cents 1100
    
    association :event
    association :vendor
    association :menu_template
    association :event_transaction_method
  end
end