FactoryGirl.define do 
  factory :menu_level_discount do 
    min_participation 50
    cogs 7
    sell_price 8
  end 
end