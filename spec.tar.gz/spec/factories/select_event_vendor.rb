FactoryGirl.define do
	factory :select_event_vendor do
		association :select_event, factory: :select_event_with_locations
		association :vendor, factory: :vendor
    association :menu_template, factory: :menu_template

		trait :with_delivery_vendor do
			association :delivery_vendor, vendor_type: "Delivery Service", factory: :vendor
		end

		trait :skip_callback do
			after(:build) do |select_event_vendor|
				select_event_vendor.class.skip_callback(:create, :before, :conditionally_assign_delivery_vendor)
			end
		end
	end
end