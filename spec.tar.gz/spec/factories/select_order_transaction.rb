FactoryGirl.define do 
  factory :select_order_transaction, class: Select::SelectOrderTransaction do
    association :user, :confirmed, factory: :user
    association :select_event, factory: :select_event
    association :select_order, factory: :select_order
    is_refund false
    superceded false

  end
end