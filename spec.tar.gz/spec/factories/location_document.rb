FactoryGirl.define do
  factory :location_document do
    document_file_name { Faker::Lorem.word }
    document_content_type "image"
    document_file_size 17
    association :location
    association :user
  end
end
