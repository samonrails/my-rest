# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :review do
    rating {rand(1..5)}
    content "Good"

    association :select_order
  end
end
