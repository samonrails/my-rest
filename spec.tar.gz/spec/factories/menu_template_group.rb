FactoryGirl.define do 
  factory :menu_template_group do 
    association :menu_template
  end
end
