FactoryGirl.define do
  factory :delivery_group do
    name "delivery_group"
    association :vendor, factory: [:vendor, :delivery_service]
    association :market, factory: :market

		before(:create) do |delivery_group|
		  delivery_group.key = delivery_group.suggest_next_key
		end
  end
end
