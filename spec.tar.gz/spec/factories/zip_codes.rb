# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :zip_code do
    zipcode "60654"

    trait :with_tax_rate do
      tax_rate BigDecimal.new("9.5")
    end

    trait :with_market do
      association :market
    end
  end
end
