# Read about factories at https://github.com/thoughtbot/factory_girl
data_hash = {rating: [1,2,3,4,5].sample}
FactoryGirl.define do
  factory :token do
    data data_hash
  end
end