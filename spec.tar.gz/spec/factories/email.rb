FactoryGirl.define do
  factory :email do
    email "david.bremner@fooda.com"
    email_list "catering_schedule_preview"
  end
end
