FactoryGirl.define do
  factory :market do
    name { Faker::Address.city.gsub(/[^a-zA-Z ]/,'')}
    default_tax_rate BigDecimal.new("12.12")

    trait :with_zip_code do
      after(:create) do |market|
        market.zip_codes << FactoryGirl.create(:zip_code)
      end
    end
  end
end