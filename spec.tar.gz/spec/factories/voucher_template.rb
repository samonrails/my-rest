FactoryGirl.define do 
  factory :voucher_template do 
    name          "dummy"
    description   "testing voucher template"
    cogs_cents    5
    line_item_sku "line item"
  end
end