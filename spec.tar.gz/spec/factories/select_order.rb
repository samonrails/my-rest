FactoryGirl.define do
  factory :select_order, :class => Select::SelectOrder do
    created_at '2014-01-01'
    updated_at '2014-01-01'
    status 'cart'
    association :user, :confirmed, factory: :user
    association :select_event, factory: [:select_event_with_locations, :with_bloated_vendor]

    trait :with_event_order_item do
      after(:create) do |select_order| 
        inventory_item = FactoryGirl.create(:inventory_item, :vendor_id => select_order.select_event.vendors.last.id)
        select_order.select_order_items << FactoryGirl.create(:select_order_item, 
                                                              inventory_item: inventory_item,
                                                              vendor: select_order.select_event.vendors.first, 
                                                              status: 'current')
      end
    end


    trait :with_event_order_items do
      after(:create) do |select_order| 
        3.times do
          inventory_item = FactoryGirl.create(:inventory_item, :vendor_id => select_order.select_event.vendors.last.id)
          select_order.select_order_items << FactoryGirl.create(:select_order_item, 
                                                                inventory_item: inventory_item, 
                                                                vendor: select_order.select_event.vendors.first, 
                                                                status: 'current')
        end
      end
    end

    trait :percentage_subsidy_10 do
      association :select_event, :percentage_subsidy_10, factory: :select_event
    end

    trait :percentage_subsidy_10_contrib_req_2 do
      association :select_event, :percentage_subsidy_10, :user_must_contribute_2, factory: :select_event
    end

    trait :percentage_subsidy_10_contrib_req_10 do
      association :select_event, :percentage_subsidy_10, :user_must_contribute_10, factory: :select_event
    end

    trait :percentage_subsidy_10_capped_1 do
      association :select_event, :percentage_subsidy_10, :percentage_capped_1, factory: :select_event
    end

    trait :percentage_subsidy_50_capped_1 do
      association :select_event, :percentage_subsidy_50, :percentage_capped_1, factory: :select_event
    end

    trait :percentage_subsidy_10_capped_1_contrib_req_2 do
      association :select_event, :percentage_subsidy_10, :percentage_capped_1, :user_must_contribute_2, factory: :select_event
    end

    trait :percentage_subsidy_50_capped_1_contrib_req_2 do
      association :select_event, :percentage_subsidy_50, :percentage_capped_1, :user_must_contribute_2, factory: :select_event
    end

    trait :percentage_subsidy_50_capped_1_contrib_req_10 do
      association :select_event, :percentage_subsidy_50, :percentage_capped_1, :user_must_contribute_10, factory: :select_event
    end

    trait :fixed_subsidy_5 do
      association :select_event, :fixed_subsidy_5, factory: :select_event
    end

    trait :fixed_subsidy_10 do
      association :select_event, :fixed_subsidy_10, factory: :select_event_with_locations
    end

    trait :fixed_subsidy_5_contrib_req_2 do
      association :select_event, :fixed_subsidy_5, :user_must_contribute_2, factory: :select_event
    end

    trait :fixed_subsidy_5_contrib_req_5 do
      association :select_event, :fixed_subsidy_5, :user_must_contribute_5, factory: :select_event
    end

    trait :fixed_subsidy_5_contrib_req_10 do
      association :select_event, :fixed_subsidy_5, :user_must_contribute_10, factory: :select_event
    end

    trait :full_subsidy do
      association :select_event, :full_subsidy, factory: :select_event
    end

    trait :full_subsidy_contrib_req_2 do
      association :select_event, :full_subsidy, :user_must_contribute_2, factory: :select_event
    end

    trait :full_subsidy_contrib_req_10 do
      association :select_event, :full_subsidy, :user_must_contribute_10, factory: :select_event
    end
  end
end