# Read about factories at https://github.com/thoughtbot/factory_girl
data = {:reviews=>[], :rating_array=>[]}
FactoryGirl.define do
  factory :reviews_rollup do
    reference   nil
    product_type %w(perks select managed_services).sample
    event_level_reviews       data
    item_level_reviews        data
    food_presentation_reviews data
    order_accuracy_reviews    data
    delivery_reviews          data
    ease_of_ordering_reviews  data
    customer_service_reviews  data
  end
end
