FactoryGirl.define do 
  factory :address do 
    address1 { Faker::AddressUS.street_address }
    address2 { Faker::AddressUS.secondary_address }
    city { Faker::AddressUS.city }
    state { Faker::AddressUS.state_abbr }
    zip_code { Faker::AddressUS.zip_code.first(5) }
    country "United States"

    trait :work do
      name "600 West Chicago"
      address1 "600 W. Chicago Ave."
      address2 ""
      city "Chicago"
      state "IL"
      zip_code "60654"
    end

    trait :with_zip_code_tax do
      after(:create) do |address|
        create(:zip_code, :with_tax_rate, :with_market, zipcode: address.zip_code)
      end
    end

    trait :with_zip_code do 
      after(:create) do |address|
        create(:zip_code, :with_market, zipcode: address.zip_code)
      end
    end
  end 
end
