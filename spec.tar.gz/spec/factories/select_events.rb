FactoryGirl.define do
  factory :select_event do
  	ready_and_bagged 50
  	delivery_time 48.hours.from_now
  	ordering_window_start_time 30.hours.from_now
  	ordering_window_end_time 34.hours.from_now
    default_gratuity 10.0
    meal_period "Lunch"

    association :created_by, :factory => :user
    association :account, :account_pricing_tier_select, factory: :account

    trait :available do
      deleted_at nil
      status "active"
      ordering_window_start_time 1.day.ago
      ordering_window_end_time 5.hours.from_now
      delivery_time 7.hours.from_now
      ready_and_bagged 10
      published true
    end

    trait :percentage_subsidy_10 do
      subsidy "percentage"
      subsidy_percentage_cap 10.0
    end

    trait :percentage_subsidy_50 do
      subsidy "percentage"
      subsidy_percentage_cap 50.0
    end

    trait :percentage_capped_1 do
      is_subsidy_percentage_capped true
      subsidy_percentage_fixed_amount_cap_cents 100
    end

    trait :fixed_subsidy_5 do
      subsidy "fixed_amount"
      subsidy_fixed_amount_cents 500
    end

    trait :fixed_subsidy_10 do
      subsidy "fixed_amount"
      subsidy_fixed_amount_cents 1000
    end

    trait :full_subsidy do
      subsidy "fully_subsidized"
    end

    trait :no_subsidy do
      subsidy "none"
    end

    trait :user_must_contribute_2 do
      user_contribution_required true
      user_contribution_cents 200
    end

    trait :user_must_contribute_5 do
      user_contribution_required true
      user_contribution_cents 500
    end

    trait :user_must_contribute_10 do
      user_contribution_required true
      user_contribution_cents 1000
    end

    #TODO -djb please remove this.
    factory :select_event_with_locations do
      after(:create) do |select_event|
        select_event.locations << FactoryGirl.create(:location)
      end
    end

    trait :with_location do
      after(:create) do |select_event|
        select_event.locations << FactoryGirl.create(:location)
      end
    end

    trait :with_account_locations do
      after(:create) do |select_event|
        select_event.locations << FactoryGirl.create(:location, account: select_event.account)
      end
    end

    trait :with_location_delivery_group do

      after(:create) do |select_event|
        location = FactoryGirl.create(:location, :with_delivery_group)
        select_event.locations << location
        select_event.delivery_group = location.delivery_groups.first
        select_event.save

      end
    end

    trait :with_location_zip_code_tax do
      after(:create) do |select_event|
        location =  FactoryGirl.create(:location, :with_zip_code_tax)
        select_event.locations << location
      end
    end

    trait :with_locations do
      after(:create) do |select_event|
        select_event.locations << FactoryGirl.create(:location)
        select_event.locations << FactoryGirl.create(:location)
      end
    end

    trait :with_vendor do
      after(:create) do |select_event|
        select_event.vendors << FactoryGirl.create(:vendor)
      end
    end

    trait :with_vendor_and_item do
      after(:create) do |select_event|
        vendor = FactoryGirl.create(:vendor, :with_inventory_item)
        select_event.vendors << vendor
        select_event.select_event_vendors.first.menu_template = vendor.menu_templates.first
        select_event.save
      end
    end

    trait :with_bloated_vendor do
      after(:create) do |select_event|
        select_event.vendors << FactoryGirl.create(:vendor, :with_menu_template)
      end
    end

    trait :with_bloated_vendors do
      after(:create) do |select_event|
        2.times do
          select_event.vendors << FactoryGirl.create(:vendor, :with_menu_template)
        end
      end
    end
  end

  factory :select_event_location, :class => Select::SelectEventLocation  do
    delivery_notes "cookies and milk will be required. Act accordingly."
  end

end
