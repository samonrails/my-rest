FactoryGirl.define do
  factory :user do
    first_name { Faker::Name.first_name.gsub(/[^a-zA-Z ]/,'') }
    last_name  { Faker::Name.first_name.gsub(/[^a-zA-Z ]/,'') }
    sequence(:email) {|n| "#{first_name}#{n + rand(100000)}@fooda.com" }

    password "new_passwords"
    password_confirmation "new_passwords"
    roles %w[super_admin fooda_employee accounting catering_foodizen foodizen]

    trait :confirmed do
    end

    trait :unconfirmed do
      password "Welcome1"
      password_confirmation "Welcome1"
    end

  end
end
