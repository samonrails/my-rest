FactoryGirl.define do
	factory :select_order_item, :class => Select::SelectOrderItem do
		association :inventory_item, factory: :inventory_item
		association :select_order, factory: :select_order
    association :vendor, factory: :vendor
		quantity 1
		special_instructions ''
	end
end
