FactoryGirl.define do
  factory :select_event_schedule_vendor do
    association :vendor
    association :menu_template
  end
end