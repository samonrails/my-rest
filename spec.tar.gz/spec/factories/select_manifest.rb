FactoryGirl.define do
  factory :select_manifest, :class => Select::SelectManifest do
    created_at '2014-01-01'
    updated_at '2014-01-01'
    association :vendor, factory: :vendor
    association :select_events, factory: :select_event
  end
end
