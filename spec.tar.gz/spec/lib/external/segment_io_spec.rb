require "spec_helper"

describe SegmentIO do 

  let(:user){create(:user, :confirmed, :email => "testing@fooda.com")}

  it "should returns user information hash" do
    user_account = SegmentIO.user_account_information_for_segment_io(user)
    user_account.should include("email" => "#{user.email}","username" => "#{user.name}")
  end

  it "should returns user details" do
    user_account = SegmentIO.identify_traits(user)
    user_account.should include("email" => "#{user.email}","name" => "#{user.first_name}" + " " + "#{user.last_name}")
  end

end
