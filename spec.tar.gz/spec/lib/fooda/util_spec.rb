require 'spec_helper'

describe Fooda::Util do
  
  let(:user) { create(:user, :confirmed) }
  let(:public_user) { create(:user, :confirmed, :email => 'dummyacc@anythingexceptfooda.com')}

  it 'should create admin users' do
    roles = %w[super_admin fooda_employee accounting catering_foodizen foodizen]
    Fooda::Util.create_admin_users user.email
    expect(user.roles).to eq roles
  end
  
  it 'should remove public users' do
    public_user
    assert_difference 'User.count', -1 do
      Fooda::Util.remove_public_users
    end
  end

  it 'should create pricing tiers' do
    PricingTier.delete_all
    assert_difference 'PricingTier.count', 4 do
      Fooda::Util.create_pricing_tiers
    end
  end

  it 'should create markets' do
    Building.all.each{|b| b.update_attribute('market_id', nil)}
    Market.delete_all
    assert_difference 'Market.count', 2 do
      Fooda::Util.create_markets
    end
  end
  
  it 'should create ssp persistence' do
    SspPersistence.delete_all
    assert_difference 'SspPersistence.count', 3 do
      Fooda::Util.create_ssp_persistences
    end
  end
  
  it 'should create ssp persistence' do
    LineItemType.delete_all
    assert_difference 'LineItemType.count', 23 do
      Fooda::Util.create_line_item_types
    end
  end
  
  it 'should create god user' do
    Fooda::Util.create_god_user
    expect(User.all.map(&:email)).to include('foodadev@fooda.com')
  end
end