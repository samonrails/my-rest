require "spec_helper"

describe SearchSortPaginate do

  let(:event){create_list(:event, 25)}

  describe "search_sort_paginate" do
    it "should perform search sort and paginate" do
     Event.delete_all
     options = {:artificial_attributes => {"market" => "markets.name"}}
     params = {:searchable => {:market => event.map{|cc| cc.location.try(:building).try(:market).try(:name)}}}
     events = Event.includes([:location => [:building => :market]]).search_sort_paginate(params, options)
     events.count.should eq 25
    end
  end
end