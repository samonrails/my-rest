require "spec_helper"

describe SettleSelectEvent do
  it "should queue the select events settler" do
    expect {
      SettleSelectEvent.perform_async
    }.to change(SettleSelectEvent.jobs, :size).by(1)
  end
end
