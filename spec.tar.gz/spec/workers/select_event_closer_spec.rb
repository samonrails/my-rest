require 'spec_helper'

describe SelectEventCloser do
  describe '#perform' do
    let(:select_event){ create(:select_event, published: true) }
    context "closable select events" do
      it "sets the published event status to in_progress" do
        Delorean.time_travel_to "38 hours from now" do
          Sidekiq::Testing.inline! do
            SelectEventCloser.perform_async(select_event.id, select_event.ordering_window_end_time.to_s)
          end
          expect(select_event.reload.status).to eq(Status::Event.in_progress)
        end
      end
      it "keeps the event published flag at true" do
        Delorean.time_travel_to "38 hours from now" do
          Sidekiq::Testing.inline! do
            SelectEventCloser.perform_async(select_event.id, select_event.ordering_window_end_time.to_s)
          end
          expect(select_event.reload.published).to eq(true)
        end
      end
    end
    context "non-closable events" do
      let(:select_event){ create(:select_event) }
      it "does not change unpublished events" do
        Delorean.time_travel_to "38 hours from now" do
          expect {
            select_event.update_attributes(published: false)
            SelectEventCloser.drain
            SelectEventCloser.perform_async(select_event.id, select_event.ordering_window_end_time.to_s)
          }.not_to change{select_event.reload}
        end
      end
      it "does not change completed events" do
        Delorean.time_travel_to "38 hours from now" do
          expect {
            select_event.update_attributes(status: Status::Event.complete)
            SelectEventCloser.drain
            SelectEventCloser.perform_async(select_event.id, select_event.ordering_window_end_time.to_s)
          }.not_to change{select_event.reload}
        end
      end
      it "does not change finalized events" do
        Delorean.time_travel_to "38 hours from now" do
          expect {
            select_event.update_attributes(status: Status::Event.final)
            SelectEventCloser.drain
            SelectEventCloser.perform_async(select_event.id, select_event.ordering_window_end_time.to_s)
          }.not_to change{select_event.reload}
        end
      end
      it "does not change canceled events" do
        Delorean.time_travel_to "38 hours from now" do
          expect {
            select_event.update_attributes(status: Status::Event.canceled)
            SelectEventCloser.drain
            SelectEventCloser.perform_async(select_event.id, select_event.ordering_window_end_time.to_s)
          }.not_to change{select_event.reload}
        end
      end
    end
  end
end
