require 'spec_helper'

feature "Login" do
  let!(:user) { create(:user) }

  scenario "Confirmed User Logs in" do
    visit "/login"
    fill_in 'user_email', with: user.email
    fill_in 'user_password', with: 'new_passwords'
    click_button "Sign in"
    expect(page).to have_text("Signed in successfully.")
  end

  scenario "Someone attempts to login with a utility account" do
    user.update_attribute(:utility_account, true)
    visit "/login"
    fill_in 'user_email', with: user.email
    fill_in 'user_password', with: 'Welcome1'
    click_button "Sign in"
    expect(page).to have_text('Invalid email or password')
  end
end
