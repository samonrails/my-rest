require 'spec_helper'

feature "Select Events" do
  let!(:building){ create(:building, :with_zip_code, is_approved: true) }
  let!(:location){ create(:location, building: building) }
  let!(:account){ create(:account, name: "Groupon", locations: [location], active: true) }
  let!(:inventory_item){ create(:inventory_item) }
  let!(:menu_template){ create(:menu_template, product_type: "select", inventory_items: [inventory_item]) }
  let!(:vendor){ create(:vendor, menu_templates: [menu_template]) }

  let(:user){ create(:user) }

  before do
    Vendor.should_receive(:vendors_by_type_and_product_and_market).and_return([vendor])
    vendor.should_receive(:menu_templates_by_product).and_return([menu_template])
  end

  scenario "Creating a Select Event with Manifest", js: true, core: true do

    # Create the Select Event
    visit "http://localhost:3000"
    click_link "Login"
    fill_in "user_email", with: user.email
    fill_in "user_password", with: user.password
    click_button "Sign in"
    click_link "Events"
    find('#add_select_event').click
    select account.name, from: "select_event_account_id"
    select location.name, from: "select_event_select_event_locations_attributes_0_location_id"
    click_button "Create Select event"
    page.should have_content "Select Event Details"

    # Adding a vendor
    within "#add_event_vendor_select_event_add_event_vendor" do
      find("i.icon-plus").click
    end

    click_button "Add Vendor"
    page.should have_content vendor.name

    # Create Order
    click_link "Orders"
    find('#create_order').click

    # Creating new User via Order
    click_button "Create New User"
    fill_in "select_order_user_first_name", with: "First"
    fill_in "select_order_user_last_name", with: "Last"
    fill_in "select_order_user_email", with: "someone@somewhere.com"
    find('.multiselect.dropdown-toggle.btn').click
    find('input[type="checkbox"][value="Groupon"]').click
    click_button "Start Order"

    # Choose Inventory Item
    find('#new_inventory_item').click
    select vendor.name, from: "select_order_item_vendor_id"
    select inventory_item.name_public, from: "select_order_item_inventory_item_id"
    page.execute_script '$("#select_order_item_inventory_item_id").change();'
    sleep 1 # Allow AJAX some time
    click_button "Add Menu Item"

    # Add Credit Card & Make Payment
    find('.new-select-order-transaction.btn.btn-success.toggle-modal').click
    fill_in "select_order_transaction_name", with: "First Last"
    fill_in "select_order_transaction_ux_number", with: "4111111111111111"
    select "(05) May", from: "select_order_transaction_expiration_month"
    select "2020", from: "select_order_transaction_expiration_year"
    fill_in "select_order_transaction_ux_cvv", with: "999"
    fill_in "select_order_transaction_address1", with: "620 Third St."
    fill_in "select_order_transaction_city", with: "Fairport"
    fill_in "select_order_transaction_state", with: "OH"
    fill_in "select_order_transaction_zipcode", with: "44077"
    click_button "Make Payment"

    # Back to Select Event
    click_link "Select Event: S0001001"

    # Check the Manifest generation
    within 'tr[data-record-id="1"]' do
      first('.btn.btn-mini').click
    end

    page.should have_content "Pre-Manifest"
  end
end
