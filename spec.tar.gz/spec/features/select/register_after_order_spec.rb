require 'spec_helper'

feature "Select Registration" do
  include Warden::Test::Helpers
  Warden.test_mode!

  let!(:user){ create(:user, created_by: "guest") }
  let!(:select_event){ create(:select_event) }
  let!(:select_order){ create(:select_order, user: user) }
  let!(:current_item){ create(:select_order_item, quantity: 1, status: :current) }

  before do
    select_order.select_order_items << current_item
    switch_to_subdomain "select"
  end

  scenario "A new user finishes registration after guest checkout", js: true do
    visit confirmation_select_select_order_path(select_order)
    fill_in 'user_first_name', with: "someone"
    fill_in 'user_last_name', with: "someone"
    fill_in 'user_password', with: 'new_passwords'
    fill_in 'user_password_confirmation', with: 'new_passwords'
    click_button "Create Account"

    expect(current_path).to eq(myfooda_path)
  end

end
