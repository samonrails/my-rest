require 'spec_helper'

describe Select::SelectOrdersController do

  let(:user) { create(:user)}

  before do
    request.env['HTTPS'] = 'on'
    request.env['HTTP_REFERER'] = ':back'
    sign_in_user(user)
  end

  # Order adjustments tests
  # :provision, :discard, :update, :destroy
  context "adjust an existing select order" do
    let(:select_event) { create(:select_event_with_locations)}
    let(:select_order) { create(:select_order)}

    # :provision
    describe "POST :provision" do
      let(:current_item)     { create(:select_order_item, quantity: 1, status: :current)}
      let(:provisioned_item) { create(:select_order_item, quantity: 1, status: :provisioned)}
      before do
        select_order.select_order_items << current_item
        select_order.save
      end

      it "provisions an editable set of order items" do
        line_item_count_1 = select_order.select_order_items.count
        post :provision, id: select_order.id
        line_item_count_2 = select_order.select_order_items.count
        expect(line_item_count_1).to eq(1)
        expect(line_item_count_2).to eq(2)
        expect_redirect_to edit_select_select_order_path(select_order)
      end
    end

    # :discard
    describe "POST :discard" do
      let (:current_item)     { create(:select_order_item, quantity: 1, status: :current)}
      let (:provisioned_item) { create(:select_order_item, quantity: 1, status: :provisioned)}
      before do
        select_order.select_order_items << current_item
        select_order.select_order_items << provisioned_item
        select_order.save
      end

      it "discards provisioned order items" do
        line_item_count_1 = select_order.select_order_items.count
        post :discard, id: select_order.id
        line_item_count_2 = select_order.select_order_items.count
        expect(line_item_count_1).to eq(2)
        expect(line_item_count_2).to eq(1)
        expect_redirect_to select_select_order_path(select_order)
      end
    end

    # :update
    describe "PUT :update" do
      let(:test_card)        { create(:card, token: "fooda")}
      let(:new_card)         { { number: "4005519200000004", cvv: "123", expiration_month: "01", expiration_year: "2020" }}

      context "payments" do
        let(:current_item)     { create(:select_order_item, quantity: 2, status: :current)}
        let(:provisioned_item) { create(:select_order_item, quantity: 3, status: :provisioned)}
        let(:params)           { {transaction: { is_refund: "false", amount: "0" }, send_receipt: "true"}}
        before do
          select_order.select_order_items << current_item
          select_order.select_order_items << provisioned_item
          select_order.save
          @payment_amount = select_order.recalc_totals(:provisioned)[:total_amount] - select_order.recalc_totals(:current)[:total_amount]
          params[:transaction][:amount] = @payment_amount.to_s
        end

        it "succeeds if expected total equals calculated total with an existing card" do
          params[:transaction][:card_id] = test_card.id.to_s
          put :update, id: select_order.id, select_order: params
          expect(flash[:error]).to be_blank
          expect(flash[:notice]).to eq "Order adjustment complete."
          expect_redirect_to select_select_order_path(select_order)
        end

        it "succeeds if expected total equals calculated total with a new card" do
          params[:transaction].merge!(new_card)
          put :update, id: select_order.id, select_order: params
          expect(flash[:error]).to be_blank
          expect(flash[:notice]).to eq "Order adjustment complete."
          expect_redirect_to select_select_order_path(select_order)
        end

        it "fails if expected total is less than calculated total" do
          params[:transaction][:card_id] = test_card.id.to_s
          params[:transaction][:amount] = (@payment_amount - Money.new(1)).to_s
          put :update, id: select_order.id, select_order: params
          expect(flash[:error]).to match "Invalid amount specified for charge"
        end

        it "fails if expected total is greater than calculated total" do
          params[:transaction][:card_id] = test_card.id.to_s
          params[:transaction][:amount] = (@payment_amount + Money.new(1)).to_s
          put :update, id: select_order.id, select_order: params
          expect(flash[:error]).to match "Invalid amount specified for charge"
        end

        it "fails if payment transaction incorrectly marked as refund" do
          params[:transaction][:card_id] = test_card.id.to_s
          params[:transaction][:is_refund] = "true"
          put :update, id: select_order.id, select_order: params
          expect(flash[:error]).to match "Invalid amount specified for refund"
        end

        it "fails if existing card and new card information is missing" do
          put :update, id: select_order.id, select_order: params
          expect(flash[:error]).to match "Invalid card information provided"
        end

        it "fails if new card number is missing" do
          params[:transaction].merge!(new_card.except(:number))
          put :update, id: select_order.id, select_order: params
          expect(flash[:error]).to match "Invalid card information provided"
        end

        it "fails if new card cvv is missing" do
          params[:transaction].merge!(new_card.except(:cvv))
          put :update, id: select_order.id, select_order: params
          expect(flash[:error]).to match "Invalid card information provided"
        end

        it "fails if new card expiration month is missing" do
          params[:transaction].merge!(new_card.except(:expiration_month))
          put :update, id: select_order.id, select_order: params
          expect(flash[:error]).to match "Invalid card information provided"
        end

        it "fails if new card expiration year is missing" do
          params[:transaction].merge!(new_card.except(:expiration_year))
          put :update, id: select_order.id, select_order: params
          expect(flash[:error]).to match "Invalid card information provided"
        end

      end

      context "refunds" do
        before (:all) do
          Braintree::Transaction.sale(
            amount: "10.00",
            credit_card: {
              number: "4111111111111111",
              expiration_date: "01/2020",
            }
          )
        end
        let(:current_item)     { create(:select_order_item, quantity: 2, status: :current)}
        let(:provisioned_item) { create(:select_order_item, quantity: 1, status: :provisioned)}
        let(:params)           { {transaction: { is_refund: "true", amount: "0" }, send_receipt: "true"}}
        before do
          select_order.select_order_items << current_item
          select_order.select_order_items << provisioned_item
          select_order.save
          @refund_amount = select_order.recalc_totals(:current)[:total_amount] - select_order.recalc_totals(:provisioned)[:total_amount]
          params[:transaction][:amount] = @refund_amount.to_s
        end

        it "succeeds if expected total equals calculated total" do
          # Need to create a genuine sale transaction first
          @refund_amount = select_order.recalc_totals(:current)[:total_amount] - select_order.recalc_totals(:provisioned)[:total_amount]
          select_order.braintree_transact({
            is_refund: "false",
            amount: @refund_amount.to_s,
            number: "4009348888881881",
            expiration_month: "01",
            expiration_year: "2020",
            cvv: "123",
          })
          put :update, id: select_order.id, select_order: params
          expect(flash[:error]).to be_blank
          expect(flash[:notice]).to eq "Order adjustment complete."
          expect_redirect_to select_select_order_path(select_order)
        end

        it "fails if expected total is less than calculated total" do
          params[:transaction][:amount] = (@refund_amount - Money.new(1)).to_s
          put :update, id: select_order.id, select_order: params
          expect(flash[:error]).to match "Invalid amount specified for refund"
        end

        it "fails if expected total is greater than calculated total" do
          params[:transaction][:amount] = (@refund_amount + Money.new(1)).to_s
          put :update, id: select_order.id, select_order: params
          expect(flash[:error]).to match "Invalid amount specified for refund"
        end

        it "fails if refund transaction incorrectly marked as payment" do
          params[:transaction][:is_refund] = "false"
          put :update, id: select_order.id, select_order: params
          expect(flash[:error]).to match "Invalid amount specified"
        end

      end

    end

    # :destroy
    describe "DELETE :destroy" do
      let(:test_card)        { create(:card, token: "fooda")}
      let(:current_item)     { create(:select_order_item, quantity: 1, status: :current)}
      let(:provisioned_item) { create(:select_order_item, quantity: 2, status: :provisioned)}
      let(:params)           { {transaction: { is_refund: "false", amount: "0", card_id: test_card.id.to_s }, send_receipt: "true"}}
      before do
        select_order.select_order_items << current_item
        select_order.select_order_items << provisioned_item
        select_order.save
        params[:transaction][:amount] = (select_order.recalc_totals(:provisioned)[:total_amount] - select_order.recalc_totals(:current)[:total_amount]).to_s
        put :update, id: select_order.id, select_order: params
      end

      it "marks the order as canceled and refunds/voids all payment transactions" do
        pre_destroy_transaction_count = select_order.select_order_transactions.count
        delete :destroy, id: select_order.id
        expect(pre_destroy_transaction_count).to eq(1)
        expect(select_order.select_order_transactions.authorized.count).to eq(0)
        expect(select_order.select_order_transactions.voided.count).to eq(1)
        expect(Select::SelectOrder.find_by_id(select_order.id).status).to eq("canceled")
        expect_redirect_to select_select_order_path(select_order)
      end
    end

    # :new_inventory_item
    describe "GET :new_inventory_item" do
      render_views
      let(:current_item)     { create(:select_order_item, quantity: 1, status: :current)}
      let(:provisioned_item) { create(:select_order_item, quantity: 1, status: :provisioned)}
      before do
        select_order.select_order_items << current_item
        select_order.save
      end
      it "displays the correct inventory item" do
        get :new_inventory_item, id: select_order.id, inventory_item_id: select_order.select_order_items.first.inventory_item.id
        expect(response.body).to match select_order.select_order_items.first.inventory_item.name_public
      end
    end

    # :new_transaction
    describe "GET :new_transaction" do
      let(:current_item) { create(:select_order_item, quantity: 2, status: :current)}
      let(:provisioned_item) { create(:select_order_item, quantity: 2, status: :provisioned)}
      before do
        select_order.select_order_items << current_item
        select_order.save
      end

      it "renders the payment form" do
        provisioned_item[:quantity] = 3
        select_order.select_order_items << provisioned_item
        get :new_transaction, id: select_order.id
        response.should render_template("select/select_orders/transactions/_payment")
      end

      it "renders the refund form" do
        provisioned_item[:quantity] = 1
        select_order.select_order_items << provisioned_item
        get :new_transaction, id: select_order.id
        response.should render_template("select/select_orders/transactions/_refund")
      end

      it "renders the no-transaction form" do
        select_order.select_order_items << provisioned_item
        get :new_transaction, id: select_order.id
        response.should render_template("select/select_orders/transactions/_no_transaction")
      end
    end

  #update_reviews
 
  describe "PUT /select/select_orders/:id/update_reviews" do
    let(:inventory_item) {create(:inventory_item)}
    let(:review){create(:review,:reviewable_id => inventory_item.id,:reviewable_type => "InventoryItem", :select_order_id => select_order.id, :rating => 1 )}
    
    it "should update select order reviews" do
          
      put :update_reviews, :id => select_order.id, :select_order => {"select_order_reviews_attributes"=>
                                                         [{"rating"=>"4", "id" => review.id, "rating_type"=>"individual", "content"=>""}]}
    
      expect(flash[:notice]).to eq "Reviews saved successfully."
    end

  end


  end
end
