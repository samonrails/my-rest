require 'spec_helper'

describe LocationDocumentsController do

  let(:user){create(:user, :confirmed)}
  let(:location){ create(:location) }
  let(:location_document){ create(:location_document)}

  before(:each) do
    sign_in_user
    request.env['HTTPS'] = 'on'
  end

  describe " POST /locations/:location_id/location_documents" do
    it "should create location document" do
      request.env["HTTP_REFERER"] = root_path
      post :create, :location_document => {:document => Rack::Test::UploadedFile.new(Rails.root + 'spec/support/avatar.png', 'image/jpeg')}, :location_id => location.id
      expect_success_message "Location Document created succesfully."
      expect_redirect_to root_path
    end
  end
  
  describe "DELETE /locations/:location_id/location_documents/:id" do
    it "should destroy building document" do
      delete :destroy, :id => location_document.id, :location_id => location_document.location.id
      expect_success_message "Location Document deleted successfully."
      expect_redirect_to edit_account_location_path(location_document.location.account, location_document.location)
    end
  end
end
