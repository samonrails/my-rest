require 'spec_helper'

describe MenuTemplatesController do
  let!(:vendor){ FactoryGirl.create(:vendor) }
  let(:mt){ FactoryGirl.create(:menu_template) }
  let(:inventory_item){ FactoryGirl.create(:inventory_item, :eligible_for_catering_add_ons => true) }
  let(:menu_template){{
    name: "Non-Veg Fav", product_type: "managed_services",
    pricing_type: "menu_level", meal_period_list: "dinner",
    start_date: "27 September 2013", expiration_date: "30 September 2013",
    is_eligible_for_self_service: "1", cogs: "20.00", retail_price: "21.00"
  }}

  before(:each) do
    sign_in_user
    request.env['HTTPS'] = 'on'
  end

  describe "GET /vendors/:vendor_id/menu_templates" do
    it "should return vendors in an json array" do
      get :index, :vendor_id => vendor.id, :format => :json
      json_array = JSON.parse response.body
      expect(json_array.count).to eq vendor.menu_templates.count
    end
  end

  describe "POST /vendors/:vendor_id/menu_templates" do
    it "should create menu template" do
      assert_difference 'MenuTemplate.count' do
        post :create, :menu_template => menu_template, :vendor_id => vendor.id
      end

      expect(flash[:notice]).to eq "Menu Template created successfully."
      expect_redirect_to edit_vendor_menu_template_path(vendor, assigns(:menu_template))
    end

    it "should not create menu template with blank fields" do
      assert_difference 'MenuTemplate.count', 0 do
        post :create, :menu_template => menu_template.merge(:product_type => "", :start_date => ""), :vendor_id => vendor.id
      end

      expect(flash[:error]).to eq "Error creating Menu Template - Start date can't be blank, Product type is not included in the list"
    end

    it "should accept nested attributes for menu level discounts" do
      assert_difference 'MenuLevelDiscount.count', 2 do
        menu_template.merge!(:menu_level_discounts_attributes => [
          {:min_participation => "10", :cogs => "25.10", :retail_price => "28.17", :_destroy => false},
          {:min_participation => "12", :cogs => "23.24", :retail_price => "25.80", :_destroy => false},
          {:min_participation => "14", :cogs => "24.34", :retail_price => "26.84", :_destroy => true}
        ])

        post :create, :menu_template => menu_template, :vendor_id => vendor.id
      end
    end

    describe "PUT /vendors/:vendor_id/menu_templates/:id" do
      it "should update any particular menu template" do
        put :update, :menu_template => {:name => "Veg Fav Menu"}, :id => mt.id, :vendor_id => mt.vendor.id
        expect(flash[:notice]).to eq "Menu template updated successfully."
        expect(assigns[:menu_template].name).to eq "Veg Fav Menu"
      end
    end

    describe "DELETE /vendors/:vendor_id/menu_templates/:id" do
      it 'should destroy menu_template' do
        vendor = mt.vendor
        assert_difference 'MenuTemplate.count', -1 do
          delete :destroy, :id => mt.id, :vendor_id => vendor.id
        end
        expect(flash[:notice]).to eq "Menu Template destroyed."
        expect_redirect_to vendor_path(vendor, :selected => "menu_templates")
      end
    end
    
    describe "POST /vendors/:vendor_id/menu_templates/:id/create_menu_group" do
      it 'should create menu group' do
        vendor = mt.vendor
        assert_difference 'MenuTemplateGroup.count', +1 do
          post :create_menu_group, :menu_template_group_id=>"", :item_ids => [inventory_item.id.to_s], :id => mt.id, :vendor_id => vendor.id, :choices_to_select=>"3", :name =>"MTG"
        end
        expect(flash[:notice]).to eq "Menu Template Group added successfully"
        expect_redirect_to edit_vendor_menu_template_path(vendor, mt)
      end
    end
    
    describe "POST /vendors/:vendor_id/menu_templates/:id/create_menu_group" do
      it 'should create menu group' do
        vendor = mt.vendor
        assert_difference 'MenuTemplateGroup.count', +1 do
          post :create_menu_group,:item_ids => [inventory_item.id.to_s], :id => mt.id, :vendor_id => vendor.id, :choices_to_select=>"3", :name =>"MTG"
        end
        expect(flash[:notice]).to eq "Menu Template Group added successfully"
        expect_redirect_to edit_vendor_menu_template_path(vendor, mt)
      end
    end

    describe "POST /vendors/:vendor_id/menu_templates/:id/delete_menu_group" do
      it "delete menu group" do
        vendor = mt.vendor
        post :create_menu_group,:item_ids => [inventory_item.id.to_s], :id => mt.id, :vendor_id => vendor.id, :choices_to_select=>"3", :name =>"MTG"
        mtg = assigns(:menu_template_group)
        mtg.menu_template_inventory_items.delete_all
        assert_difference 'MenuTemplateGroup.count', -1 do
          post :delete_menu_group, :menu_template_group_id => mtg.id, :vendor_id=>vendor.id, :id=> mt.id
        end
      end
    end
  end
end