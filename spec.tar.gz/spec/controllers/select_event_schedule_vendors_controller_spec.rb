require 'spec_helper'

describe SelectEventScheduleVendorsController do

  let(:account){create(:account)}
  let(:vendor){create(:vendor)}
  let(:menu_template){create(:menu_template)}
  let(:select_event_schedule){
    create(:nicer_select_event_schedule, 
           :with_location,
           schedule: IceCube::Rule.daily.to_json,
           account: account)
  }
  let(:select_event_schedule_vendor){create(:select_event_schedule_vendor, :account_id => account.id, :select_event_schedule_id => select_event_schedule.id)}
  let!(:utility_account) {create(:user, :confirmed, utility_account: true)}

  before(:each) do
    sign_in_user
    request.env['HTTPS'] = 'on'
  end

  describe "GET /accounts/:account_id/select_event_schedule_vendors/:id" do
    it "should render select_event_schedule_vendors/edit template" do
      get :show, :id => select_event_schedule_vendor.id, :account_id => select_event_schedule_vendor.account_id
      response.should render_template "select_event_schedule_vendors/_edit"
    end
  end

  describe "POST   /accounts/:account_id/select_event_schedule_vendors" do
    it "should create select_event_schedule_vendor" do
      request.env["HTTP_REFERER"] = account_path(account)
      assert_difference "SelectEventScheduleVendor.count", +1 do
        post :create, :event_vendor => {:menu_template => menu_template.id}, :select_event_schedule_vendor => {:vendor => vendor.id},
                      :select_event_schedule_id => select_event_schedule.id, :account_id => account.id
      end
      expect_redirect_to account_path(account)
      expect_success_message "Select Event Schedule Vendor added."
    end
  end

  describe "PUT /accounts/:account_id/select_event_schedule_vendors/:id" do
    it "should update select_event_schedule_vendor" do
      request.env["HTTP_REFERER"] = account_path(account)
      put :update, :id => select_event_schedule_vendor.id, :account_id => select_event_schedule_vendor.account_id,
                   :event_vendor => {:menu_template => menu_template.id}, :select_event_schedule_vendor => {:vendor => vendor.id}
      expect_redirect_to account_path(account)
      expect_success_message "Select Event Schedule Vendor updated"
    end
  end

  describe "DELETE /accounts/:account_id/select_event_schedule_vendors/:id" do
    it "should delete select_event_schedule_vendor" do
      select_event_schedule_vendor
      request.env["HTTP_REFERER"] = account_path(account)
      assert_difference "SelectEventScheduleVendor.count", -1 do
        delete :destroy, :id => select_event_schedule_vendor.id, :account_id => select_event_schedule_vendor.account_id
      end
      expect_redirect_to account_path(account)
      expect_success_message "Select Event Vendor deleted."
    end
  end

end
