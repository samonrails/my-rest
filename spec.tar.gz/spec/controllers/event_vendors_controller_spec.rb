require 'spec_helper'

describe EventVendorsController do
  
  let(:event_vendor){create(:event_vendor)}
  let(:event){create(:event)}
  let(:account){create(:account)}
  let(:vendor){create(:vendor)}
  let(:menu_template){create(:menu_template)}

  before(:each) do
    sign_in_user
    request.env['HTTPS'] = 'on'
  end

  describe "GET /events/:event_id/event_vendors/:id/edit" do

    it "should render edit template" do
      get :edit, :id =>event_vendor.id, :event_id => event_vendor.event_id
      expect(response).to render_template("edit")
    end

  end

  describe "POST /events/:event_id/event_vendors" do

    it "should create event vendor" do
      post :create, :event_id =>event.id, :event_vendor => {:product => "catering", :account_id => account.id, :market => "Chicago",:cuisine =>"Any", :vendor => vendor.id, :menu_template => menu_template.id}
      expect(flash[:notice]).to eq "Vendor successfully added to event."
    end

    it "should not create event vendor" do
      post :create, :event_id =>event.id, :event_vendor => {:product => "catering", :account_id => account.id, :market => "Chicago",:cuisine =>"Any", :vendor => vendor.id}
      expect(flash[:error]).to eq "Error: No Menu Template chosen."
    end

  end

  describe "PUT /events/:event_id/event_vendors/:id" do

    it "should update event vendor" do
      put :update, :id =>event_vendor.id, :event_id => event_vendor.event_id, :event_vendor => { :participation => "5", :menu_template_id => event_vendor.menu_template.id}
      expect(flash[:notice]).to eq "Vendor information updated successfully."
    end

  end

  describe "DELETE /events/:event_id/event_vendors/:id" do

    it "should destroy event vendor" do
      delete :destroy, :id =>event_vendor.id, :event_id => event_vendor.event_id
      expect(flash[:notice]).to eq "Vendor removed from event."
    end

  end

  describe "POST   /events/:event_id/event_vendors/:id/change_grouped_menu_template_selections" do

    it "should change grouped menu template selections" do
      post :change_grouped_menu_template_selections, :id =>event_vendor.id, :event_id => event_vendor.event_id
      expect(flash[:notice]).to eq "Menu Items Updated"
    end

  end

end
