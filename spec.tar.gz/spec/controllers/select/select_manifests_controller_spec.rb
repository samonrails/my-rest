require 'spec_helper'

describe Select::SelectManifestsController do

  let(:date) { DateTime.now.strftime("%Y-%m-%d") }
  let(:period) { "Lunch" }

  # Select Event w/ multiple MTs
  let(:select_event) do
    create(:select_event, :with_location_delivery_group,
                          :with_bloated_vendor,
                          ordering_window_end_time_utc: 1.hour.from_now.utc)
  end

  let(:user) { create(:user, :confirmed, accounts: [select_event.account]) }

  # First Order from Event 1 to Vendor 1
  let (:select_order) do
    create(:select_order, select_event: select_event,
                          user: user,
                          location: select_event.locations.first,
                          status: :checkout_complete)
  end
  let (:select_order_item_1) do
    create(:select_order_item, inventory_item: select_event.vendors.first.menu_templates.last.inventory_items.first,
                               vendor: select_event.vendors.first,
                               select_order: select_order,
                               special_instructions: 'Extra special sauce',
                               quantity: 1,
                               status: :current)
  end
  let (:select_order_item_2) do
    create(:select_order_item, inventory_item: select_event.vendors.first.menu_templates.last.inventory_items.first,
                               vendor: select_event.vendors.first,
                               select_order: select_order,
                               quantity: 1,
                               status: :current)
  end

  let (:select_manifest) do
    create(:select_manifest, vendor: select_event.vendors.first,
                             select_events: [select_event])

  end

  before do
    select_order.select_order_items = [select_order_item_1, select_order_item_2]
    request.env['HTTPS'] = 'on'
    request.env['HTTP_REFERER'] = ':back'
    sign_in_user(user)
  end

  describe "GET 'index'" do
    it "returns http success" do
      get 'index'
      response.should be_success
    end
  end

  describe "GET 'show'" do
    it "returns http success" do
      get 'show', id: select_manifest.id
      response.should be_success
    end
  end

  describe "GET 'email'", focus: true do
    it "enqueues manifest emails" do
      get 'email', id: select_manifest.id
      expect(flash[:notice]).to eq "Select Manifest emails/faxes queued."
      expect_redirect_to select_select_manifests_path
    end
  end

  describe "GET 'fax'", focus: true do
    it "enqueues manifest faxes" do
      get 'fax', id: select_manifest.id
      expect(flash[:notice]).to eq "Select Manifest emails/faxes queued."
      expect_redirect_to select_select_manifests_path
    end
  end

  describe "GET 'pdf'" do
    render_views
    it "returns http success" do
      get 'pdf', id: select_manifest.id
      response.should be_success
    end
  end

  # 30-May-2014: 1-to-1 Manifest linked Settlements deprecated!
  # describe "GET 'settlement'" do
  #   it "returns http success" do
  #     get 'settlement', id: select_manifest.id
  #     response.should be_success
  #   end
  # end

  # 30-May-2014: 1-to-1 Manifest linked Settlements deprecated!
  # describe "GET 'settlement_pdf'" do
  #   render_views
  #   it "returns http success" do
  #     get 'settlement_pdf', id: select_manifest.id
  #     response.should be_success
  #   end
  # end

  describe "POST 'create'" do
    let (:params) { { vendor: select_event.vendors.first.id, select_events: [select_event.id] } }

    it "creates a new manifest" do
      post 'create', select_select_manifest: params
      expect(flash[:error]).to be_blank
      expect(flash[:notice]).to eq "Select Manifest created."
      expect_redirect_to select_select_manifests_path
    end
  end

  describe "GET 'edit'" do
    it "returns http success" do
      get 'edit', id: select_manifest.id
      response.should be_success
    end
  end

  describe "PUT 'update'" do
    let (:params) { { select_events: [select_event.id] } }

    it "updates existing manifest" do
      put 'update', id: select_manifest.id, select_select_manifest: params
      expect(flash[:error]).to be_blank
      expect(flash[:notice]).to eq "Select Manifest updated succesfully."
      expect_redirect_to select_select_manifests_path
    end
  end

end
