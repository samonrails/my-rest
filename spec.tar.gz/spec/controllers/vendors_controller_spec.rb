require 'spec_helper'

describe VendorsController do

  let!(:vendor){create(:vendor)}

  before(:each) do
    sign_in_user
    request.env['HTTPS'] = 'on'
  end

  describe 'GET /vendors' do

    it "should return vendors in an json array" do
      get :index, :format => :json
      json_array = JSON.parse response.body
      expect(json_array.count).to eq (Vendor.count > 50) ? 50 : Vendor.count
    end
  end

  describe 'POST /vendors' do
    it "should create vendor" do
      assert_difference 'Vendor.count' do
        post :create, :vendor => {:name => "Barbeque Nation", :cuisine_list => "Indian,Vegetarian",
                                :market_list => "Chicago", :vendor_manager_id => @user.id,
                                :default_tax_rate => "10"}
      end
      expect_redirect_to vendor_path(assigns :vendor)
    end

    it "should not create vendor if data is missing" do
      post :create, :vendor => {:name => "Buffet Hut"}
      expect_redirect_to vendors_path
      expect(flash[:error]).to eq "Error creating vendor - Cuisine list can't be blank, Market list can't be blank, Vendor manager can't be blank"
    end
  end


  describe "PUT /vendors/:id" do
    before do
      vendor_products = vendor.products
      vendor_product_types = vendor.product_types
    end

    it "should update vendor's data" do
      put :update, :vendor => {:cuisine_list => "Mexican", :default_tax_rate => "5"}, :id => vendor.id
      expect(flash[:notice]).to eq "Vendor updated successfully."
      expect(vendor.reload.cuisine_list).to eq ["Mexican"]
      expect(vendor.reload.default_tax_rate).to eq 5
    end

    it "should not update vendor's data with blank fields" do
      put :update, :vendor => {:cuisine_list => "", :default_tax_rate => "5"}, :id => vendor.id
      expect(flash[:error]).to eq "Error updating vendor - Cuisine list can't be blank"
      expect(vendor.reload.cuisine_list).to eq ["Italian"]
    end

    it "should enable a product(catering, premium popup gold etc.) for vendor" do
      assert_difference "vendor.products.reload.count", 2 do
        put :update, :vendor => {:product_type_config => {:managed_services => {:status => "active", :catering => "on", :prepaid_popup_gold => "on"}}},
                    :id => vendor.id
      end
    end

    it "should update vendor's Billing Address" do
      put :update, :vendor => {:address_attributes => {:address1 => "Plot No. 25", :address2 => "IT-Park",
                                                     :city => "Chandigarh", :state => "PB", :zip_code => "152002",
                                                     :country => "India", :id => vendor.address.id}},
                  :id => vendor.id
      expect(flash[:notice]).to eq "Vendor updated successfully."
      expect(vendor.reload.billing_address).to eq "Plot No. 25<br>IT-Park<br>Chandigarh, PB 152002"
    end
  end

  describe 'DELETE /vendors/:id' do
    it "should destroy an existing Vendor" do
      vendor.menu_templates.delete_all
      assert_difference 'Vendor.count', -1 do
        delete :destroy, :id => vendor.id
      end
      expect_redirect_to vendors_path
    end

    it "should not destroy an existing Vendor if have some restricted dependents" do
      delete :destroy, :id => vendor.id
      expect_redirect_to vendor_path(vendor)
      expect(flash[:error]).to eq "Error destroying Vendor - Cannot delete record because of dependent menu_templates"
    end
  end

  describe 'GET /vendors/:id' do

    it "should show vendor" do
      get :show, :id => vendor.id
      response.should render_template("show")
    end

  end

  describe 'GET /vendors/:id/export_events' do

    it "should export xls" do
      get :export_events, :id => vendor.id, :format => :xls
      expect(response.header["Content-Type"]).to eq "application/xls; charset=utf-8"
      expect(response.header["Content-Disposition"]).to eq "attachment; filename=\"vendor_events.xls\""
    end

  end

  describe 'GET /vendors/:id/export_item_reviews.xls  ' do

    it "should export xls file" do
      level = ["Event Level Food Ratings", "Aggregate Item Level Food Ratings"].sample
      product_type = %w(select perks managed_services).sample
      get :export_item_reviews, :id => vendor.id, :format => :xls, :product_type => product_type, :level => level
      expect(response.header["Content-Type"]).to eq "application/xls; charset=utf-8"
      expect(response.header["Content-Disposition"]).to eq "attachment; filename=\"#{level}.xls\""
    end

  end

  describe "GET /vendors/:id/export_presentation_reviews.xls" do

    it "should export xls file" do
      level = ["Food Presentation", "Order Accuracy", "On Time Delivery", "Ease of Ordering", "Customer Service"].sample
      product_type = %w(select perks managed_services).sample
      get :export_presentation_reviews, :id => vendor.id, :format => :xls, :product_type => product_type, :level => level
      expect(response.header["Content-Type"]).to eq "application/xls; charset=utf-8"
      expect(response.header["Content-Disposition"]).to eq "attachment; filename=\"#{level} Reviews.xls\""
    end

  end

  describe "GET /vendors/:id/export_bar_graph_data.xls" do
    it "should export xls file" do
      level = ["Event Level Food Ratings", "Aggregate Item Level Food Ratings", "Food Presentation", "Order Accuracy", "On Time Delivery", "Ease of Ordering", "Customer Service"].sample
      product_type = %w(select perks managed_services).sample
      get :export_bar_graph_data, :id => vendor.id, :format => :xls, :product_type => product_type, :level => level
      expect(response.header["Content-Type"]).to eq "application/xls; charset=utf-8"
      expect(response.header["Content-Disposition"]).to eq "attachment; filename=\"bar_graph_reviews.xls\""
    end
  end

  describe "GET /vendors/:id/export_event_reviews.xls" do
    it "should export xls file" do
      level = ["Event Level Food Ratings", "Aggregate Item Level Food Ratings", "Food Presentation", "Order Accuracy", "On Time Delivery", "Ease of Ordering", "Customer Service"].sample
      product_type = %w(select perks managed_services).sample
      get :export_event_reviews, :id => vendor.id, :format => :xls, :product_type => product_type, :level => level
      expect(response.header["Content-Type"]).to eq "application/xls; charset=utf-8"
      expect(response.header["Content-Disposition"]).to eq "attachment; filename=\"#{level}.xls\""
    end
  end

  describe "POST /vendors/:id/toggle_favorite" do
    def get_post
      post :toggle_favorite, :id => vendor.id
    end
    it "should add vendor to favourite " do
      get_post
      expect(response.body).to eq "Added to Favorites."
    end

    it "should remove vendor from favourite " do
      get_post
      get_post
      expect(response.body).to eq "Removed from Favorites."
    end
  end
end
