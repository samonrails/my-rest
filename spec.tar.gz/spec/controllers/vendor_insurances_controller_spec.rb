require 'spec_helper'

describe VendorInsurancesController do

end
