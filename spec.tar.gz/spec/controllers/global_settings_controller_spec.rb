require 'spec_helper'

describe GlobalSettingsController do

end
