require "spec_helper"

describe Checkout::ItemsController do
  let(:inventory_item){ create(:inventory_item) }
  let(:account){ create(:account) }
  let(:select_event){ create(:select_event, account: account) }
  let(:option_group){ FactoryGirl.create(:option_group) }
  let(:inventory_item_option){ FactoryGirl.create(:option_inventory_item) }
  let!(:inventory_items_option_group){
    InventoryItemsOptionGroup.create(
      inventory_item_id: inventory_item.id,
      option_group_id: option_group.id
    )
  }
  let(:options_and_instruction_params) {
      {
        options:
          [
            inventory_items_option_group.id
          ],
        side_options:
          [
            inventory_items_option_group.id
          ],
        instructions: "instructions"
      }
    }

  before do
    request.env["HTTP_REFERER"] = "/back"
    request.env['HTTPS'] = 'on'
  end

  context "when signed in" do
    let(:user){ create(:user) }
    let(:cart){ user.cart }

    before do
      user.add_to_cart(select_event, inventory_item)
      sign_in_user user
    end

    after do
      sign_out user
    end

    it "ensures the cart is not anonymous" do
      expect(cart.anonymous?).to be_false
    end

    describe "POST :create" do
      let(:item_params) {
        {
          parent_id:   select_event.id,
          parent_type: "SelectEvent",
          item_id:     inventory_item.id,
          item_type:   "InventoryItem"
        }
      }

      def do_post
        post :create, account_id: account.id, select_event_id: select_event.id, info: item_params.merge(options_and_instruction_params)
      end

      it "adds the item to the cart" do
        expect(cart.items.count).to eq(1)
        do_post
        cart.reload
        expect(cart.items.count).to eq(2)
      end

      it "should redirect back" do
        do_post
        expect(response).to redirect_to(account_select_event_checkout_path(account, select_event))
      end
    end

    describe "PUT :update" do
      let(:co_item){ user.cart.checkout_items.first }
      let(:option_group){ create(:option_group) }
      let(:inventory_item_option){ create(:option_inventory_item) }
      let!(:inventory_items_option_group){
        InventoryItemsOptionGroup.create(
          inventory_item_id: inventory_item.id,
          option_group_id: option_group.id
        )
      }

      def do_put
        put :update, account_id: account.id, select_event_id: select_event.id, id: co_item.id, info: options_and_instruction_params
      end

      it "updates the item in the cart" do
        do_put
        co_item.reload
        expect(co_item.options).to eq([inventory_items_option_group.id.to_s])
        expect(co_item.side_options).to eq([inventory_items_option_group.id.to_s])
        expect(co_item.instructions).to eq("instructions")
      end

      it "should redirect back" do
        do_put
        expect(response).to redirect_to(account_select_event_checkout_path(account, select_event))
      end
    end

    describe "DELETE :destroy" do
      def do_delete
        delete :destroy, select_event_id: select_event.id, id: user.cart.selection_for(select_event).items.first, parent_type: "SelectEvent", parent_id: select_event.id
      end

      it "should remove the item from the cart" do
        expect {
          do_delete
          cart.reload
        }.to change{ cart.items.size }.by(-1)
      end

      it "should redirect back" do
        do_delete
        cart.reload
        expect(response).to redirect_to("https://test.host/back")
      end
    end
  end


  # -------------------------------------------------------------------


  context "when not signed in" do
    let(:cart){ controller.send(:cart) }

    before do
      Checkout::Cart.destroy_all
      cart.add!(select_event, inventory_item)
    end

    it "ensures the cart is anonymous" do
      expect(cart.anonymous?).to be_true
    end

    describe "POST :create" do
      def do_post
        post :create, account_id: account.id, select_event_id: select_event.id, info: {
          parent_id:   select_event.id,
          parent_type: "SelectEvent",
          item_id:     inventory_item.id,
          item_type:   "InventoryItem"
        }
      end

      it "adds the item to the cart" do
        expect(cart.items.count).to eq(1)
        do_post
        cart.reload
        expect(cart.items.count).to eq(2)
      end

      it "should redirect back" do
        do_post
        expect(response).to redirect_to(account_select_event_checkout_path(account, select_event))
      end
    end

    describe "PUT :update" do
      let(:co_item){ cart.checkout_items.first }
      let(:option_group){ create(:option_group) }
      let(:inventory_item_option){ create(:option_inventory_item) }
      let!(:inventory_items_option_group){
        InventoryItemsOptionGroup.create(
          inventory_item_id: inventory_item.id,
          option_group_id: option_group.id
        )
      }

      def do_put
        put :update, account_id: account.id, select_event_id: select_event.id, id: co_item.id, info: options_and_instruction_params
      end

      it "updates the item in the cart" do
        do_put
        co_item.reload
        expect(co_item.options).to eq([inventory_items_option_group.id.to_s])
        expect(co_item.instructions).to eq("instructions")
        expect(co_item.side_options).to eq([inventory_items_option_group.id.to_s])
      end

      it "should redirect back" do
        do_put
        expect(response).to redirect_to(account_select_event_checkout_path(account, select_event))
      end
    end

    describe "DELETE :destroy" do
      def do_delete
        delete :destroy, select_event_id: select_event.id, id: cart.selection_for(select_event).items.first, parent_type: "SelectEvent", parent_id: select_event.id
      end

      it "should remove the item from the cart" do
        expect {
          do_delete
          cart.reload
        }.to change{ cart.items.size }.by(-1)
      end

      it "should redirect back" do
        do_delete
        cart.reload
        expect(response).to redirect_to("https://test.host/back")
      end
    end
  end


end
