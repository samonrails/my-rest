require "spec_helper"

# NOTE: This is testing CheckoutController functionality
# but as that controller is abstract, we'll test it via
# one of its children.

describe Checkout::CartsController do
  let(:user){ FactoryGirl.create(:user, :confirmed) }
  let(:account){ FactoryGirl.create(:account, sales_rep: user, account_exec: user) }
  let(:contact){ FactoryGirl.create(:contact, account: account) }
  let(:select_event){ FactoryGirl.create(:select_event_with_locations, created_by: user, account: account) }

  before do
    request.env['HTTPS']        = 'on'
    request.env["HTTP_REFERER"] = "/back"
  end

  context "when a user is signed in" do
    let(:cart){ user.cart }

    before do
      sign_in_user user
    end

    it "uses the user's cart" do
      get :show, select_event_id: select_event.id
      expect(controller.send(:cart)).to eq(cart)
    end
  end

  context "when a user is not signed in" do

    context "when a cart exists" do
      let(:cart){ Checkout::Cart.create }

      before do
        request.cookies[:keep_looking] = cart.token
      end

      it "assumes the existing cart" do
        get :show, select_event_id: select_event.id
        expect(controller.send(:cart)).to eq(cart)
      end

      context "when the User logs in" do
        it "assumes control of that cart" do
          sign_in_user user
          get :show, select_event_id: select_event.id
          expect(controller.send(:cart)).to eq(user.cart)
        end
      end
    end

    context "when a cart does not exist" do
      before do
        Checkout::Cart.destroy_all
      end

      it "creates a new anonymous cart" do
        pending
        expect{ get :show, select_event_id: select_event.id }.to change(Checkout::Cart, :count).by(1)
      end
    end
  end

end
