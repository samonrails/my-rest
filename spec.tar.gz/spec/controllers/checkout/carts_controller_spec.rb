require "spec_helper"

describe Checkout::CartsController do
  let(:user){ FactoryGirl.create(:user) }
  let(:cart){ user.cart }
  let(:select_event){ FactoryGirl.create(:select_event_with_locations) }
  let(:item){ create(:inventory_item) }

  before do
    request.env["HTTP_REFERER"] = "/back"
    request.env['HTTPS'] = 'on'
  end

  describe "GET :show" do
    it "sets up @presenter" do
      get :show, select_event_id: select_event.id
      expect(assigns[:presenter]).to be_present
    end

    it "renders the cart page" do
      get :show, select_event_id: select_event.id
      expect(response).to render_template("checkout/cart")
    end
  end

  describe "POST :order" do

    let(:params) { { amount: 7.22,
      card: {
      cardholder_name: "fname lname",
      number: "4111111111111111",
      expiration_month: Date.today.mon.to_s,
      expiration_year: Date.today.year.to_s,
      cvv: "123"
    } } }

    before do
      cart.add!(select_event, item)
    end

    def do_post(params)
      post :order, info: params, select_event_id: select_event.id
    end

    context "when the ordering window has passed" do
      let(:ordering_window_end_time){ 1.minute.ago }
      let(:select_event){
        select_event = build(
          :select_event_with_locations,
          ordering_window_end_time: ordering_window_end_time,
          ordering_window_end_time_utc: ordering_window_end_time.utc
        )
        select_event.save(validate: false)
        select_event
      }

      before do
        sign_in user
      end

      it "doesn't create a new card" do
        expect{ do_post(params) }.not_to change(Card, :count)
      end

      it "does not place an order" do
        expect{ do_post(params) }.not_to change(Select::SelectOrder, :count)
      end

      it "does not run the transaction" do
        expect{ do_post(params) }.not_to change(Select::SelectOrderTransaction, :count)
      end

      it "redirects back" do
        do_post(params)
        response.should redirect_to 'https://test.host/back'
      end
    end

    context "when the event is not published" do
      let(:select_event){ create(:select_event_with_locations, published: false) }

      before do
        sign_in user
      end

      it "doesn't create a new card" do
        expect{ do_post(params) }.not_to change(Card, :count)
      end

      it "does not place an order" do
        expect{ do_post(params) }.not_to change(Select::SelectOrder, :count)
      end

      it "does not run the transaction" do
        expect{ do_post(params) }.not_to change(Select::SelectOrderTransaction, :count)
      end

      it "redirects back" do
        do_post(params)
        response.should redirect_to 'https://test.host/back'
      end
    end

    context "when a stored card is used for payment" do
      before do
        sign_in user
        Braintree.create_verified(user.id, params[:card])
        @card = Card.last
        @params = { card_id: @card.id,
                    amount: 7.22,
                    is_refund: false,
                    store_in_vault: false }
      end

      it "looks into creating a new user and returns the logged in user" do
        controller.should_receive(:maybe_create_user).and_return(user)
        do_post(@params)
      end

      it "doesn't create a new card" do
        expect{ do_post(@params) }.not_to change(Card, :count)
      end

      it "places an order" do
        expect{ do_post(@params) }.to change(Select::SelectOrder, :count).by(1)
      end

      it "runs the transaction using the selected card" do
        do_post(@params)
        expect(Select::SelectOrderTransaction.last.card).to eq(@card)
      end

      it "redirects to the confirmation page" do
        do_post(@params)
        response.should redirect_to confirmation_select_select_order_path(Select::SelectOrder.last, order_params: @params)
      end
    end

    context "when a new card is used for payment" do
      describe "and the card data is valid" do
        context "as a logged in user" do
          before do
            sign_in user
            params.merge!({cardholder_name: "fname lname",
                          number: "4111111111111111",
                          expiration_month: Date.today.mon.to_s,
                          expiration_year: Date.today.year.to_s,
                          cvv: "123",
                          card_id: 1,
                          is_refund: false,
                          options: {verify_card: true},
                          store_in_vault: false,
                          customer_id: nil,
                          card: {customer_id: nil, options: {verify_card: true}}
                        })
          end

          it "looks into creating a new user and returns the logged in user" do
            controller.should_receive(:maybe_create_user).and_return(user)
            do_post(params)
          end

          it "creates a new card" do
            expect{ do_post(params) }.to change(Card, :count).by(1)
          end

          it "places an order" do
            expect{ do_post(params) }.to change(Select::SelectOrder, :count).by(1)
          end

          it "runs the transaction using the new card" do
            do_post(params)
            expect(Select::SelectOrderTransaction.last.card).to eq(Card.last)
          end

          it "redirects to the confirmation page" do
            do_post(params)
            response.should redirect_to confirmation_select_select_order_path(Select::SelectOrder.last, order_params: params)
          end
        end

        context "as a logged out guest user" do
          let(:guest_params) { params.merge({ email: 'awesomesauce@example.com' }) }

          before do
            sign_out user
          end

          it "looks into creating a new user" do
            controller.should_receive(:maybe_create_user).and_return(User.new)
            do_post(guest_params)
          end

          it "does not create a new card" do
            expect{ do_post(guest_params) }.not_to change(Card, :count)
          end

          it "places an order" do
            expect{ do_post(guest_params) }.to change(Select::SelectOrder, :count).by(1)
          end

          it "runs the transaction using the card information" do
            pending("For some reason the cart in the example doesn't have items")
            do_post(guest_params)
            expect(Select::SelectOrderTransaction.last.card).to be_nil
          end

          it "redirects to the confirmation page" do
            do_post(guest_params)
            response.should redirect_to confirmation_select_select_order_path(Select::SelectOrder.last, order_params: guest_params)
          end
        end
      end

      describe "and the card data is invalid" do
        before do
          sign_in user
          FakeBraintree.decline_all_cards!
        end

        after do
          FakeBraintree.clear!
        end

        it "does not create a new card" do
          expect{ do_post(params) }.not_to change(Card, :count)
        end

        it "does not place an order" do
          expect{ do_post(params) }.not_to change(Select::SelectOrder, :count)
        end

        it "does not run the transaction" do
          expect{ do_post(params) }.not_to change(Select::SelectOrderTransaction, :count)
        end

        it "redirects back" do
          do_post(params)
          response.should redirect_to 'https://test.host/back'
        end

        it "displays an error message" do
          do_post(params)
          expect(flash[:error]).to match(/Error/)
        end
      end
    end
  end

  describe "DELETE :destroy" do
    def do_delete
      delete :destroy, select_event_id: select_event.id
    end

    it "should clear the cart" do
      do_delete
      expect(cart.items.size).to eq(0)
    end

    it "should redirect back" do
      do_delete
      expect(response).to redirect_to("https://test.host/back")
    end
  end
end
