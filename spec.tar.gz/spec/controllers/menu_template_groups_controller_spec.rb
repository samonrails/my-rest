require 'spec_helper'

describe MenuTemplateGroupsController do

  let(:menu_template_group){ create(:menu_template_group, :menu_template_id => menu_template) }
  let(:vendor){ create(:vendor) }
  let(:menu_template_group){ create(:menu_template_group) }

  describe "POST toggle_favorite" do

    def do_post
      @menu_template_attributes = FactoryGirl.attributes_for(:comment, :article_id => @article)

      @vendor = FactoryGirl.create(:vendor)
      @menu_template = FactoryGirl.create(:menu_template, :vendor_id => @vendor)
      @menu_template_group_attributes = FactoryGirl.create(:menu_template_group, :menu_template_id => @menu_template)

      post :toggle_favorite, :menu_template_group => @menu_template_group_attributes
    end

    it  "should favorite an unfavorited item" do
      pending
      do_post
      expect(flash[:notice]).to eq "Added to Favorites."
    end

    it "should unfavorite a favorited item" do
      pending
    end

  end

  describe "PUT rank" do

    def do_put
      @vendor = FactoryGirl.create(:vendor)
      @menu_template = FactoryGirl.create(:menu_template, :vendor_id => @vendor)
      @menu_template_group= FactoryGirl.create(:menu_template_group, :menu_template_id => @menu_template)

      put :rank, :menu_template_group => @menu_template_group, :vendor_id => @vendor, :menu_template => @menu_template
    end

    it "should rank a menu up" do
      pending
      do_put

    end

    it "should rank a menu down" do 
      pending
    end
  end
end
