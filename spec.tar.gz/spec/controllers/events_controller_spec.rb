require 'spec_helper'

describe EventsController do

  let!(:event){ create(:event) }
  let(:vendor){ create(:vendor) }
  let(:location){ FactoryGirl.create(:location) }
  let(:account){ location.account }
  let(:contact){ location.contact }
  let(:new_event){{
    account_id: account.id, location_id: location.id, contact_id: contact.id,
    product: "catering", name: "Enbake Event", quantity: "20", meal_period: "lunch",
    service_style: "drop_off", event_start_time: Time.now, status: "scheduled"
  }}

  let(:blank_hash){ new_event.dup }

  before(:each) do
    Fooda::Util::create_pricing_tiers unless PricingTier.any?
    sign_in_user
    request.env['HTTPS'] = 'on'
  end

  describe "POST #send_feedback_email" do
    it "should send feedback email" do
      request.env["HTTP_REFERER"] = "events/#{event.id}"
      post :send_feedback_email, :event_id => event.id
      flash[:notice].should eq("Feedback Email Sent Successfully.")
    end

    it "should not send feedback mail" do
      event = FactoryGirl.create(:event, contact_id: nil)
      request.env["HTTP_REFERER"] = "events/#{event.id}"
      post :send_feedback_email, :event_id => event.id
      flash[:notice].should eq("Error occured in sending feedback email.")
    end
  end

  describe "PUT #claim_event" do
    it "should claim an event" do
      event.event_owner_id.should be nil
      request.env["HTTP_REFERER"] = root_path
      put :claim_event, :id => event.id

      event.reload

      event.event_owner_id.should eq @user.id
      flash[:notice].should eq('Event claimed successfully.')
      response.should redirect_to root_path
    end

    it "should not claim an event" do
      event = FactoryGirl.create(:event_with_owner)
      event.event_owner_id.should_not be nil

      request.env["HTTP_REFERER"] = root_path
      put :claim_event, :id => event.id

      flash[:error].should eq('Sorry! The event has already been claimed.')
      response.should redirect_to root_path
    end
  end

  describe "GET /events" do
    it "should render 'index' template" do
      get :index
      response.should render_template("index")
    end
  end

  describe "GET /events/:id" do
    it "should render 'show' template" do
      get :show, :id => event.id
      response.should render_template("show")
    end
  end

  describe "POST /events" do
    it "should create an event" do
      post :create, :event => new_event
      expect_redirect_to event_path(assigns(:event))
      expect(flash[:notice]).to eq "Event created successfully."
    end

    it "should not create an event without required parameters" do
      post :create, :event => blank_hash.each{|k,v| blank_hash[k]=""}
      expect_redirect_to events_url
      expect(flash[:error]).to eq "Error creating event - Account can't be blank, Event start time can't be blank"
    end

    it "should have payment method 'On Account'" do
      account.update_attributes(credit_status: "On Account")
      post :create, :event => new_event
      assigns(:event).event_transaction_method.transaction_method.should eq "on_account"
    end
  end

  describe "PUT /events/:id" do
    it "should update an existing event" do
      put :update, :event => {name: "Enbake Consulting", meal_period: "Dinner"}, id: event.id
      expect_redirect_to event_path(event)

      expect(flash[:notice]).to eq "Event updated successfully."
      expect(event.reload.name).to eq "Enbake Consulting"
    end

    it "should not update an existing event without required parameters" do
      post :update, :event => blank_hash.each{|k,v| blank_hash[k]=""}, :id => event.id
      expect_redirect_to event_path(event)
      expect(flash[:error]).to eq "Error updating event - Account can't be blank, Event start time can't be blank"
    end
  end

  describe "DELETE /events/:id" do
    it "should delete an existing event" do
      assert_difference 'Event.count', -1 do
        delete :destroy, :id => event.id
      end
      expect(flash[:notice]).to eq "Event deleted."
    end
  end

  describe "GET /events/:id/generate" do
    it "should generate financial report" do
      doc_type = %w(quote invoice invoice_summary).sample
      get :generate, :id => event.id, :doc_type => doc_type, :party => account.id, :party_type => "Account"
      expect(flash[:notice]).to eq "#{doc_type.titleize} being generated. Please refresh the document table in a few seconds."
    end

    it "should generate non financial report" do
      doc_type = %w(packing_slip purchase_order).sample
      get :generate, :id => event.id, :doc_type => doc_type, :party => vendor.id, :party_type => "Vendor"
      expect(flash[:notice]).to eq "#{doc_type.titleize} being generated. Please refresh the document table in a few seconds."
    end
  end

  describe "POST /events/:id/duplicate_event" do
    it "should create duplicate event" do
      assert_difference 'Event.count', 1 do
        post :duplicate_event, :id => event.id, :event_owner_id => @user.id, :event_start_time => Time.now
      end
    end
  end

  describe "GET /events/:id/fetch_cards" do
    it "should fetch cards" do
     get :fetch_cards, :id => event.id
     response.should render_template("events/partials_payment/cards/_index")
    end
  end

  describe "GET /events/:id/event_documents" do
    it "should refresh event documets" do
     get :event_documents, :event_id => event.id
     response.should render_template("events/partials_financials/_documents")
    end
  end

  describe "PUT /events/:id/update_reviews" do
    it "should update event reviews" do
     put :update_reviews, :id => event.id
     expect(flash[:notice]).to eq "Reviews saved successfully."
    end
  end

end
