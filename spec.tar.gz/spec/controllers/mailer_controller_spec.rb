require 'spec_helper'

describe Admin::MailerController do

end
