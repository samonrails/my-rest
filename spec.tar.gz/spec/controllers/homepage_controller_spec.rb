require 'spec_helper'

describe HomepageController do
  
  describe "GET index" do
    
    let(:user){ FactoryGirl.create(:user, :confirmed, :roles => ["fooda_employee", "catering_foodizen", "foodizen"]) }
    
    before(:each) do
      sign_in_user(user)
      request.env['HTTPS'] = 'on'
    end
    
    it "assigns @my_events" do
      event = FactoryGirl.create(:event, :event_owner_id => @user.id, :status => 'proposed')
      get :index
      expect(assigns(:my_events)).to include(event)
     end
    
    it "renders the index template" do
      get :index
      expect(response).to render_template("index")
    end
  end

end   
