require 'spec_helper'

describe SelectEventMenuItemsController do
  
  let(:user){FactoryGirl.create(:user)}
  let(:select_event_vendor){FactoryGirl.create(:select_event_vendor)}
  let(:featured_group){ FactoryGirl.create(:select_event_menu_group, select_event_vendor: select_event_vendor, name: "Featured")}
  let(:all_other_group){ FactoryGirl.create(:select_event_menu_group, select_event_vendor: select_event_vendor, name: "All Other")}
  let(:inventory_item_a) { FactoryGirl.create(:inventory_item) }
  let(:inventory_item_b) { FactoryGirl.create(:inventory_item) }
  let(:inventory_item_c) { FactoryGirl.create(:inventory_item) }
  let!(:featured_menu_item_1){FactoryGirl.create(:select_event_menu_item, inventory_item: inventory_item_a, select_event_menu_group: featured_group)}
  let!(:featured_menu_item_2){FactoryGirl.create(:select_event_menu_item, inventory_item: inventory_item_b, select_event_menu_group: featured_group)}
  let!(:regular_menu_item){FactoryGirl.create(:select_event_menu_item, inventory_item: inventory_item_c, select_event_menu_group: all_other_group)}

  before do
    request.env['HTTPS'] = 'on'
    request.env['HTTP_REFERER'] = ':back'

    sign_in_user(user)
  end 

  describe "DELETE #destroy" do
    def do_delete
      delete :destroy, id: regular_menu_item.id, select_event_id: regular_menu_item.select_event_vendor.select_event.id
    end

    it "deletes the menu item from all groups it belongs to" do
      expect{do_delete}.to change(SelectEventMenuItem, :count).by(-1)
    end

  end

  describe "POST #make_featured" do
    before { featured_group.select_event_menu_items.destroy_all }

    def do_post
      post :make_featured, id: regular_menu_item.id, select_event_id: regular_menu_item.select_event_vendor.select_event.id
    end

    it "adds the menu item to the select event vendor's featured group" do
      expect{ do_post }.to change(featured_group.select_event_menu_items, :count).from(0).to(1)
    end
  end

  describe "POST #remove_from_featured" do
    def do_post
      post :remove_from_featured, id: featured_menu_item_1.id, select_event_id: featured_menu_item_1.select_event_vendor.select_event.id
    end

    it "remove the menu item from the select event vendor's featured group" do
      expect{ do_post }.to change(featured_group.select_event_menu_items, :count).from(2).to(1)
    end
  end

  describe "PUT #rank" do
    before(:each) do
      featured_menu_item_1.set_list_position(1)
      featured_menu_item_2.set_list_position(2)
    end

    def do_put_up
      put :rank, id: featured_menu_item_2.id, select_event_id: featured_menu_item_2.select_event_vendor.select_event.id, direction: "up"
    end

    def do_put_down
      put :rank, id: featured_menu_item_1.id, select_event_id: featured_menu_item_1.select_event_vendor.select_event.id, direction: "down"
    end

    context "when a featured menu item with a lower rank is ranked up" do
      it "changes the menu item's position accordingly" do
        do_put_up
        featured_menu_item_2.reload
        expect(featured_menu_item_2.position).to eq(1)
      end
    end

    context "when a featured menu item with a higher rank is ranked down" do
      it "changes the menu item's position accordingly" do
        do_put_up
        featured_menu_item_1.reload
        expect(featured_menu_item_1.position).to eq(2)
      end
    end
  end

end
