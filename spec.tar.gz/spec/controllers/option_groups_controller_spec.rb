require 'spec_helper'

describe OptionGroupsController do

end
