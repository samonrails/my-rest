require 'spec_helper'

describe VendorPreferencesController do

end
