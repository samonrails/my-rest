require 'spec_helper'

describe Users::SessionsController do
  include Devise::TestHelpers

  let(:user){create(:user)}

  before(:each) do
    @request.env["devise.mapping"] = Devise.mappings[:user]
    request.env['HTTPS'] = 'on'
  end

  describe "POST /users/sign_in" do
    it "should create new user session" do
      post :create, :user => {:email => user.email, :password => "new_passwords"}
      response.should redirect_to root_url
    end

    it "should not create new user session if user not confirmed" do
      post :create, :user => {:email => user.email, :password => "new_passwords"}
      response.should redirect_to root_url
    end

    it "should not create new session with wrong creds" do
      post :create, :user => {:email => user.email, :password => "wrongpassword"}
      response.should redirect_to "/login"
    end
  end

  describe "GET /login" do
    it "should render catering template" do
      get :catering_new, :user => {:email => user.email, :password => "new_passwords", :catering => true}
      response.should render_template "layouts/catering/catering"
    end
  end

  describe "GET /logout" do
    it "should logout catering user" do
      post :create, :user => {:email => user.email, :password => "new_passwords"}
      
      get :catering_logout
      response.should redirect_to root_path
    end
  end

end
