require 'spec_helper'

describe ReviewsRollupsController do

  let (:event) {create(:event)}
  let (:account) {create(:account)}
  let (:reviews_rollup) {create(:reviews_rollup, :reference_id => account.id, :reference_type => "Account")}

  before(:each) do
    sign_in_user
    request.env['HTTPS'] = 'on'
  end

  describe "GET /reviews_rollups" do

    def get_index(level, product_type)
      get :index, :level => level, :product_type => product_type
    end

    it "should render blank template" do
      level = ["Food Presentation", "Order Accuracy", "On Time Delivery", "Ease of Ordering", "Customer Service"].sample
      product_type = %w(select perks managed_services).sample
      get_index(level, product_type)
      response.should render_template(:partial=> "_blank_data_pane")
    end

    it "should render admin/dashboard/data_pane" do
      level = ["Food Presentation", "Order Accuracy", "On Time Delivery", "Ease of Ordering", "Customer Service"].sample
      product_type = Product.find_parent(event.product)
      @review = FactoryGirl.create(:review, :reviewable_id => event.id, :reviewable_type => "Event", :additional_event_ratings => level )
      get_index(level, product_type)
      response.should render_template(:partial=> "_data_pane")
    end
  end

  describe "GET /reviews_rollups/:id" do

    def get_show(id, level, product_type)
      get :show, :id => @review_rollup1.id, :level => level, :product_type => product_type
    end

    it "should render /shared/event_reviews" do
      level = "Event Level Food Ratings"
      product_type = Product.find_parent(event.product)
      @review = FactoryGirl.create(:review, :reviewable_id => event.id, :reviewable_type => "Event", :additional_event_ratings => level )
      @review_rollup1 = FactoryGirl.create(:reviews_rollup, :reference_id => account.id, :reference_type => "Account",:event_level_reviews => {:reviews=>[@review.id], :rating_array=>[3]})
      get_show(@review_rollup1.id, level, product_type)
      response.should render_template(:partial=> "_event_reviews")
    end

    it "should render /shared/item_reviews" do
      level = "Aggregate Item Level Food Ratings"
      product_type = Product.find_parent(event.product)
      @review = FactoryGirl.create(:review, :reviewable_id => event.id, :reviewable_type => "Event", :additional_event_ratings => level )
      @review_rollup1 = FactoryGirl.create(:reviews_rollup, :reference_id => account.id, :reference_type => "Account", :item_level_reviews => {:reviews=>[@review.id], :rating_array=>[3]})
      get_show(@review_rollup1.id, level, product_type)
      response.should render_template(:partial=> "_item_reviews")
    end

    it "should render /shared/item_reviews" do
      level = ["Food Presentation", "Order Accuracy", "On Time Delivery", "Ease of Ordering", "Customer Service"].sample
      product_type = Product.find_parent(event.product)
      @review = FactoryGirl.create(:review, :reviewable_id => event.id, :reviewable_type => "Event", :additional_event_ratings => level )
      @review_rollup1 = FactoryGirl.create(:reviews_rollup, :reference_id => account.id, :reference_type => "Account",
                                           :food_presentation_reviews => {:reviews=>[@review.id], :rating_array=>[3]},
                                           :order_accuracy_reviews => {:reviews=>[@review.id], :rating_array=>[3]},
                                           :delivery_reviews => {:reviews=>[@review.id], :rating_array=>[3]},
                                           :ease_of_ordering_reviews => {:reviews=>[@review.id], :rating_array=>[3]},
                                           :customer_service_reviews => {:reviews=>[@review.id], :rating_array=>[3]})
      get_show(@review_rollup1.id, level, product_type)
      response.should render_template(:partial=> "_presentation_reviews")
    end
  end
  
   #select_reviews 
  describe "/reviews_rollups/:id/select_reviews" do
    
    let(:inventory_item) {create(:inventory_item)}
    let(:select_order){ FactoryGirl.create(:select_order) }
    let(:review){FactoryGirl.create(:review,:reviewable_id => inventory_item.id,:reviewable_type => "InventoryItem", :select_order_id => select_order.id, :additional_select_order_reviews => ["taste","supplies"] )}
    
    def get_select_reviews(id, level)
      get :select_reviews, :id => id, :level => level
    end
    it "should render /shared/select/_select_event_reviews" do
     level = "Event Level Food Ratings"
      @reviews_rollup = FactoryGirl.create(:reviews_rollup, :reference_id => inventory_item.vendor.id, :reference_type => "Vendor", 
                                           :select_event_level_reviews =>  {:reviews => [review.id], :rating_array => [3] })
      get_select_reviews(@reviews_rollup.id, level)
      response.should render_template(:partial=> "/shared/select/_select_event_reviews")
    end
    
    it "should render /shared/select/_item_reviews" do
      level = "Aggregate Item Level Food Ratings"
      @reviews_rollup = FactoryGirl.create(:reviews_rollup, :reference_id => inventory_item.vendor.id, :reference_type => "Vendor", 
                                           :item_level_reviews =>  {:reviews => review.id, :rating_array => [3] })
      get_select_reviews(reviews_rollup.id, level)
      response.should render_template(:partial=> "/shared/select/_item_reviews")
    end

    it "should render /shared/select/_supplemental_reviews" do
      level = ["1-3 Star Rating Supplemental Questions","3 Star Rating Supplemental Questions","2 Star Rating Supplemental Questions","1 Star Rating Supplemental Questions"].sample
      @reviews_rollup = FactoryGirl.create(:reviews_rollup, :reference_id => inventory_item.vendor.id, :reference_type => "Vendor", 
                                             :upto_three_star_rating_supplemental_reviews =>  {:reviews => [review.id], :rating_array => [3]},
                                             :three_star_rating_supplemental_reviews =>  {:reviews => [review.id], :rating_array => [3]},
                                             :two_star_rating_supplemental_reviews => {:reviews => [review.id], :rating_array => [2]},
                                            :one_star_rating_supplemental_reviews => {:reviews => [review.id], :rating_array => [1] })      
      get_select_reviews(@reviews_rollup.id, level)
      response.should render_template(:partial=> "/shared/select/_supplemental_reviews")
   end

  end
end
