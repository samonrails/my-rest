require 'spec_helper'

describe Admin::DashboardController do
  
  describe "GET index" do
  
    before(:each) do
      sign_in_user
      request.env['HTTPS'] = 'on'
    end
    
    it "assigns @markets" do
      market = FactoryGirl.create(:market)
      get :index
      expect(assigns(:markets)).to include(market)
     end
    
    it "renders the index template" do
      get :index
      expect(response).to render_template("index")
    end
  
    it "assigns @buildings if format is xls" do
      building = FactoryGirl.create(:building, :with_zip_code)
      get :index, :format => :xls
      expect(assigns(:buildings)).to include(building)
    end
  
  end

end 	
