require 'spec_helper'

describe Admin::VouchersController do

end
