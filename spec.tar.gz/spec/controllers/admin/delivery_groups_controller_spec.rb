require "spec_helper"

describe Admin::DeliveryGroupsController do
  let(:user){ FactoryGirl.create(:user) }
  let(:account){ FactoryGirl.create(:account) }
  let(:building) { FactoryGirl.create(:building, :with_zip_code)}
  let(:location){ FactoryGirl.create(:location, account: account, building: building) }
  let(:dg_params){ FactoryGirl.attributes_for(:delivery_group, market_id: building.market.id, vendor_id: vendor.id, key: delivery_group.key) }
  let(:vendor){ FactoryGirl.create(:vendor, market_list: building.market.name, vendor_type: "Delivery Service") }
  let(:delivery_group){ FactoryGirl.create(:delivery_group, market_id: building.market.id, vendor_id: vendor.id) }
	let!(:delivery_groups_location){ FactoryGirl.create(:delivery_groups_location, delivery_group: delivery_group, location: location) }

  before do
    request.env['HTTPS'] = 'on'
    request.env['HTTP_REFERER'] = ':back'

    sign_in_user(user)
  end

  describe "POST #create" do
    context "when valid" do
      def do_post
        post :create, delivery_group: dg_params, location_ids: [location.id]
      end

      it "should create a new Delivery Group" do
        expect{ do_post }.to change(DeliveryGroup, :count).by(1)
      end

      it "should show a notice" do
        do_post
        expect(flash[:notice]).to match /created/
      end
    end

    context "when it fails" do
      def do_post
        dg_params.delete(:name)
        post :create, delivery_group: dg_params, location_ids: [location.id]
      end

      it "should not create a new Delivery Group" do
        expect{ do_post }.to change(DeliveryGroup, :count).by(0)
      end

      it "should show an error" do
        do_post
        expect(flash[:error]).to be_present
      end
    end
  end

  describe "PUT #update" do
    context "when valid" do
      def do_put
        dg_params[:name] = "Something New"
        put :update, id: delivery_group.id, delivery_group: dg_params, location_ids: [location.id]
      end

      it "should update the Delivery Group" do
        expect do
          do_put
          delivery_group.reload
        end.to change(delivery_group, :name).to("Something New")
      end

      it "should show a notice" do
        do_put
        expect(flash[:notice]).to match /updated/
      end
    end

    context "when it fails" do
      def do_put
        dg_params[:name] = nil
        put :update, id: delivery_group.id, delivery_group: dg_params, location_ids: []
      end

      it "should not create a new Delivery Group" do
        expect{do_put}.to change(DeliveryGroup, :count).by(0)
      end

      it "should show an error" do
        do_put
        expect(flash[:error]).to be_present
      end
    end
  end

  describe "DELETE #destroy" do
    def do_delete
      delete :destroy, id: delivery_group.id
    end

    it "should update the Delivery Group" do
      expect{do_delete}.to change(DeliveryGroup, :count).by(-1)
    end

    it "should show a notice" do
      do_delete
      expect(flash[:notice]).to match /deleted/
    end
  end

  describe "GET #all_accounts_by_market" do
    def do_get
      get :all_accounts_by_market, market_id: building.market.id
    end

    it "should get account locations" do
      do_get
      expect(assigns(:account_locations)).to eq([[account, [location]]])
    end

    it "should render partial" do
      do_get
      response.should render_template(partial: '_accounts_by_market')
    end
  end

  describe "GET #available_accounts_by_market" do
    def do_get
      get :available_accounts_by_market, market_id: building.market.id, id: delivery_group.id
    end

    it "renders accounts partial" do
      do_get
      response.should render_template(partial: '_accounts_by_market')
    end

    it "should only show unselected locations" do
      do_get
      expect(assigns(:account_locations)).to eq([])
    end
  end

  describe "GET #delivery_vendors_by_market" do
    def do_get
      get :delivery_vendors_by_market, market_id: building.market.id, format: :json
    end

    before do
      request.env["HTTP_ACCEPT"] = 'application/json'
    end

    it "renders delivery vendor id and name data pairs as json for delivery vendors in the market" do
      vendor_data_array = [[vendor.id, vendor.name]]
      do_get
      json_array = JSON.parse(response.body)
      json_array.should eq(vendor_data_array)
    end
  end

    describe "GET #delivery_group_details" do
      let(:select_event){ create(:select_event) }

    def do_get
      select_event.locations << location
      delivery_group.locations << location
      get :delivery_group_details, location_id: location.id, id: delivery_group.id, select_event_id: select_event.id
    end

    it "should get delivery groups location" do
      pending
      do_get
      expect(assigns(:delivery_group_locations)).to eq([delivery_groups_location])
    end

    it "should render partial" do
      do_get
      response.should render_template(partial: '_delivery_group_details')
    end
  end

end
