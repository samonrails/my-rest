require 'spec_helper'

describe Admin::BuildingsController do
  let(:building){ FactoryGirl.create(:building, :with_zip_code, :is_approved => true) }
  let(:market){ FactoryGirl.create(:market) }
  let(:location){ FactoryGirl.create(:location) }
  let(:building_data){{
    :name => "Enbake Tower", :market_id => market.id, :timezone => "Central Time (US & Canada)",
    :contact_name => "Mukul", :contact_title => "Mr.", :contact_email => "advaitya@fooda.com",
    :contact_phone => "(123)456-7890", :contact_cell => "(123)456-7890", :contact_fax => "(123)456-7890",
    :insurance_required => 0, :insurance_requirements => "", :loading_information => "Information about Loading",
    :site_directions => "Information about directions", :parking_information => "Information about parking"
  }}

  let(:dummy_building){{
    :name => "", :market_id => "", :timezone => "", :is_approved => true, address_attributes: {}
  }}

  before(:each) do
    sign_in_user
    request.env['HTTPS'] = 'on'
  end

  describe 'POST /admin/buildings' do
    let(:zipcode) { FactoryGirl.create(:zip_code) }
    let(:market) { FactoryGirl.create :market }
    let(:building) { {:name => "Enbake Tower", :market_id => market.id, :timezone => "Central Time (US & Canada)", 
              :contact_name => "Mukul", :contact_title => "Mr.", :contact_email => "advaitya@fooda.com", 
              :contact_phone => "(123)456-7890", :contact_cell => "(123)456-7890", :contact_fax => "(123)456-7890", 
              :insurance_required => 0, :insurance_requirements => "", :loading_information => "Information about Loading", 
              :site_directions => "Information about directions", :parking_information => "Information about parking", :address_attributes => { :zip_code => zipcode.zipcode } } }

    it "should create a building record" do
      assert_difference 'Building.count' do
        post :create, :building => building
      end

      expect_redirect_to admin_root_path(:selected => "buildings")
      expect_success_message "Building created."
    end

   it "should not create a building record without required fields" do
     post :create, :building => dummy_building
     expect_redirect_to admin_root_path(:selected => "buildings")
     expect_error_message "Error creating Building  - Name can't be blank, Timezone can't be blank, Market can't be blank, Zip code can't be blank"
   end
  end

   describe 'PUT /admin/buildings/:id' do
    it 'should update building record' do
      put :update, :building => {:name => "My Building"}, :id => building.id
      expect_redirect_to admin_root_path(:selected => "buildings")
      expect_success_message "Building updated."
      expect(building.reload.name).to eq "My Building"
    end

   it 'should not update building record without required fields' do
     name = building.name
     put :update, :building => {:name => ""}, :id => building.id
     expect_redirect_to admin_root_path(:selected => "buildings")
     expect_error_message "Error updating Building  - Name can't be blank"
     expect(building.reload.name).to eq name
   end
  end

  describe 'DELETE /admin/buildings/:id' do
    it 'should destroy a building record' do
      delete :destroy, :id => building.id
      expect_success_message "Building deleted."
      expect_redirect_to admin_root_path(:selected => "buildings")
    end

    it 'should not destroy a building record if having some dependent records' do
      delete :destroy, :id => location.building.id
      expect_error_message "Error destorying Building - Cannot delete record because of dependent locations"
      expect_redirect_to admin_root_path(:selected => "buildings")
    end
  end
end
