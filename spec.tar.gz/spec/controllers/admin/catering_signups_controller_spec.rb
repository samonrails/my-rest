require 'spec_helper'

describe Admin::CateringSignupsController do
  before(:each) do
    @user = FactoryGirl.create(:user)
    @user.roles_mask = 2
    @user.save!

    @account = FactoryGirl.create(:account)
    @account_role = FactoryGirl.build(:account_role)
    @account_role.role = 'administrator'
    @account_role.account_id = @account.id
    @user.account_roles.push(@account_role)
    request.env['HTTPS'] = 'on'
  end

  describe "GET 'index'" do
    it "returns a CateringSalesLead records" do
      sign_in_user(@user)
      get 'index'
      response.should render_template('index')
    end
  end

  describe "POST 'search'" do
    let(:catering_sales_lead) {
      FactoryGirl.build(:catering_sales_lead)
    }

    let(:default_params){
        {
          :zip_code => catering_sales_lead.zip_code,
          :state => catering_sales_lead.state,
          :city => catering_sales_lead.city,
          :company_name => catering_sales_lead.organization_name
        }
    }

    it 'should return search results' do
      sign_in_user(@user)
      post :search, :catering_signup_search => default_params
      assigns[:signups].include?(@catering_sales_lead)
    end

    it 'should load the index template' do
      sign_in_user(@user)
      post :search, :catering_signup_search => default_params
      response.should render_template('index')
    end

    it 'should redirect a post to a get for an xls request' do
      sign_in_user(@user)
      post :search, :catering_signup_search => default_params, :xls => 'xls'
      expect_response_code(302)
    end

    it 'should render a file ' do
      sign_in_user(@user)
      get :search, :catering_signup_search => default_params, :format => 'xls'
      (expect(response.headers['Content-Type'].include?('application/xls')).to eq true) &&
        (expect(response.headers['Content-Disposition'].include?('attachment')).to eq true)

    end


  end
end
