require 'spec_helper'

describe Admin::BillingReferenceReportsController do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
