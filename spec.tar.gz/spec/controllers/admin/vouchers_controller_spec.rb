require 'spec_helper'

describe Admin::VouchersController do

    let(:event){create(:event)}
    let(:order){create(:order)}
    let(:user){create(:user)}
    let(:voucher_template){create(:voucher_template)}
    let(:voucher_group){ VoucherGroup.create(:name => "VoucherGroup", :description => "For testing", 
                         :cogs_cents => 1200, :quantity => 4, :event_id =>event.id,
                         :order_id => order.id, :voucher_template_id => voucher_template.id,
                         :purcashed_by_id => user.id )}

    before(:each) do
      sign_in_user
      request.env['HTTPS'] = 'on'
    end

  describe "GET /admin/vouchers" do

    it "should render admin/dashboard/voucher_lists template" do
      get :index, :voucher => {:ids => Voucher.find_by_voucher_group_id(voucher_group.id).token}  
      expect(response).to render_template("admin/dashboard/_voucher_lists")
    end

  end

  describe "PUT /admin/vouchers/:id/redeem_voucher" do

    it "should render admin/dashboard/voucher_lists template" do
      voucher = Voucher.find_by_voucher_group_id(voucher_group.id)
      put :redeem_voucher, :id => voucher.id, :redeem_voucher => {:tokens => [voucher.token]}  
      expect(response).to render_template("admin/dashboard/_voucher_lists")
    end

  end

  describe "PUT /admin/vouchers/:id/redeem_all_vouchers" do

    it "should render admin/dashboard/voucher_lists template" do
      put :redeem_all_vouchers, :redeem_voucher => {:tokens => Voucher.find_all_by_voucher_group_id(voucher_group.id).map(&:token)}
      expect(response).to render_template("admin/dashboard/_voucher_lists")
    end

  end

end
