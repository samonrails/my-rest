require 'spec_helper'

describe Admin::EmailsController do

  let(:email){create(:email)}

  before(:each) do
    sign_in_user
    request.env['HTTPS'] = 'on'
  end

  describe "POST /admin/emails" do
    it "should create email" do
      email_list = %w(catering_schedule_preview new_catering_sales vendor_billing_summaries insurance_expiration_report).sample
      assert_difference "Email.count", +1 do
        post :create, :email =>{ :email_list => email_list, :email => "testemail@fooda.com" }
      end
      expect_success_message "Email Saved"
      expect_redirect_to admin_root_path(:selected => "email_management")
    end
  end

  describe "PUT /admin/emails/:id" do
    it "should update email" do
      email_list = %w(catering_schedule_preview new_catering_sales vendor_billing_summaries insurance_expiration_report).sample
      put :update, :id => email.id, :email =>{ :email_list => email_list, :email => "testupdatedemail@fooda.com" }
      expect_success_message "Email updated."
      expect_redirect_to admin_root_path(:selected => "email_management")
    end
  end

  describe "DELETE /admin/emails/:id" do
    it "should delete email" do
      email
      assert_difference "Email.count", -1 do
        delete :destroy, :id => email.id
      end
      expect_success_message "Email Deleted"
      expect_redirect_to admin_root_path(:selected => "email_management")
    end
  end

end
