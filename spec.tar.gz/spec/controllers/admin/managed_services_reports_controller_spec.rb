require 'spec_helper'

describe Admin::ManagedServicesReportsController do

  describe "GET /admin/managed_services_reports" do
    
    before(:each) do
      sign_in_user
      request.env['HTTPS'] = 'on'
    end

    it "should render index template" do
      get :index
      expect(response).to render_template("index")
    end

    it "should export xls file" do
      get :index, :format => :xls
      expect(response.header["Content-Type"]).to eq "application/xls; charset=utf-8"
      expect(response.header["Content-Disposition"]).to eq "attachment; filename=\"managed_services.xls\""
    end
  end

end
