require 'spec_helper'

describe CommentsController do

end
