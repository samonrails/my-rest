require 'spec_helper'

describe TransactionsController do

  before(:each) do
    sign_in_user
    request.env['HTTPS'] = 'on'
  end

  let(:payment_history){ create(:payment_history, :amount => 500) }
  let(:user){create(:user)}
  let(:event){create(:event)}

  let(:card) do
    card_user = payment_history.user
    card_result = Braintree::Customer.create( email: card_user.email, first_name: card_user.first_name, last_name: card_user.last_name )
    braintree_id = card_result.customer.id if card_result.success?
    parameters = {}
    parameters[:card] = {"cardholder_name"=>"Fooda", "number"=>"5555555555554444", "cvv"=>"123", "expiration_month"=>"3", "expiration_year"=>"2016", "billing_address"=>{"street_address"=>"", "extended_address"=>"", "locality"=>"", "region"=>"", "postal_code"=>"", "country_name"=>"United States"}}
    parameters[:card][:options] = {}
    parameters[:card].merge!(customer_id: braintree_id)[:options].merge!(verify_card: true)
    credit_card = Braintree::CreditCard.create(parameters[:card])
    card = card_user.cards.create(:token => credit_card.credit_card.token, :nickname => "tester")
    card
  end
  
  let(:transaction) do
    trans_result = Braintree::Transaction.sale(amount: payment_history.amount, payment_method_token: card.token, 
                                               options: {submit_for_settlement: [true, false].sample}, order_id: payment_history.event.id)
    trans_result
  end

  describe "POST /events/:event_id/transactions" do
    it "should create new transaction" do
      post :create, :event_id => event.id, :user_id => user.id, :amount => 500, :card => card.token
      expect_success_message "Transaction Submitted for Processing"
      expect_redirect_to event_path(event, selected: 'payment', anchor: "payment")
    end
  end

  describe "POST /events/:event_id/transactions/settle" do
    it "should submit transaction for settle" do
      result = transaction
      if result.success?
        post :settle, :event_id => event.id, :amount => 500, :trans_id => result.transaction.id 
        expect_success_message "Transaction Submitted for Processing"
        expect_redirect_to event_path(event, selected: 'payment', anchor: "payment")
      end
    end
  end

  describe "POST /events/:event_id/transactions/void" do
    it "should submit transaction for void" do
      result = transaction
      if result.success?
        post :void, :event_id => event.id, :amount => 500, :trans_id => result.transaction.id 
        expect_success_message "Transaction Submitted for Processing"
        expect_redirect_to event_path(event, selected: 'payment', anchor: "payment")
      end
    end
  end

  describe "POST /events/:event_id/transactions/refund" do
    it "should submit transaction for refund" do
      result = transaction
      if result.success?
        post :refund, :event_id => event.id, :amount => 500, :trans_id => result.transaction.id 
        expect_success_message "Transaction Submitted for Processing"
        expect_redirect_to event_path(event, selected: 'payment', anchor: "payment")
      end
    end
  end

end
