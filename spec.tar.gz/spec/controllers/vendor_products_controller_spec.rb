require 'spec_helper'

describe VendorProductsController do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
