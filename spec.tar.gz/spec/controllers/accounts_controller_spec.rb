require 'spec_helper'

describe AccountsController do
  let(:account){ FactoryGirl.create(:account) }
  let(:user){ FactoryGirl.create(:user) }

  before(:each) do
    sign_in_user
    request.env['HTTPS'] = 'on'
  end

  describe "GET /accounts" do

    it "should render index template" do
      get :index
      response.should render_template "accounts/index"
    end

    it "should export xls file" do
      get :index, :format => :xls
      expect(response.header["Content-Type"]).to eq "application/xls; charset=utf-8"
      expect(response.header["Content-Disposition"]).to eq "attachment; filename=\"my_accounts.xls\""
    end
  end

  describe "GET /accounts/:id" do
    it "should return a specific in an json format" do
      get :show, :id => account.id, :format => :json
      json_response = JSON.parse response.body
      expect(json_response["name"]).to eq account.name
    end
  end

  describe "GET /accounts/:id/export_events.xls" do
    it "should export xls file" do
      get :export_events, :id => account.id, :format => :xls
      expect(response.header["Content-Type"]).to eq "application/xls; charset=utf-8"
      expect(response.header["Content-Disposition"]).to eq "attachment; filename=\"account_events.xls\""
    end
  end

  describe "GET /accounts/:id/export_memberships.xls" do
    it "should export xls file" do
      get :export_memberships, :id => account.id, :format => :xls
      expect(response.header["Content-Type"]).to eq "application/xls; charset=utf-8"
      expect(response.header["Content-Disposition"]).to eq "attachment; filename=\"account_memberships.xls\""
    end
  end

  describe "GET /accounts/:id/finalize" do
      let(:account){
        { "account_role"=>
              {"role"=>"administrator",
               "user_attributes"=>
                   {"first_name"=>"Siddharth",
                    "last_name"=>"Ravichandran",
                    "email"=>"siddharth@idyllic-software.com",
                    "phone_number" => "(123) 123 1231"
                   }
              },
          "account"=>
              {"account_type"=>"corporate",
               "name"=>"Idyllic Software",
               "address_attributes"=>
                   {"name"=>"Poxabogue Golf Center - Pro Shop",
                    "address1"=>"3556 Montauk Highway",
                    "address2"=>"",
                    "city"=>"Wainscott",
                    "state"=>"New York",
                    "zip_code"=>"10020"
                   }
              },
          "location" => {
              "name" => "Loading Docs"
          }
        }
      }

    it 'should render the 2nd part of the account creation page' do
      market = FactoryGirl.create(:market)
      ZipCode.stub(:markets_by_zip_code).and_return([market])
      post :create, account
      account_id = assigns[:account].id
      get :finalize, :id => account_id
      assigns[:account].should_not be_nil
    end

    it 'should have a valid user associated with the account' do
      market = FactoryGirl.create(:market)
      ZipCode.stub(:markets_by_zip_code).and_return([market])
      post :create, account
      account_id = assigns[:account].id
      get :finalize, :id => account_id
      assigns[:user].should_not be_nil
    end
  end

  describe 'PUT /accounts/:id/complete' do
    let(:default_account_params){
      { "account_role"=>
            {"role"=>"administrator",
             "user_attributes"=>
                 {"first_name"=>"Siddharth",
                  "last_name"=>"Ravichandran",
                  "email"=>"siddharth@idyllic-software.com",
                  "phone_number" =>  "(123) 123 1231"
                 }
            },
        "account"=>
            {"account_type"=>"corporate",
             "name"=>"Idyllic Software",
             "address_attributes"=>
                 {"name"=>"Poxabogue Golf Center - Pro Shop",
                  "address1"=>"3556 Montauk Highway",
                  "address2"=>"",
                  "city"=>"Wainscott",
                  "state"=>"New York",
                  "zip_code"=>"10020"
                 }
            },
        "location" => {
            "name" => "Loading Docs"
        }
      }
    }

    let(:params){
      {"utf8"=>"✓",
       "_method"=>"put",
       "account_role"=>
           {"role"=>"administrator",
            "user_attributes"=>
                {"password"=>"abcabcabc",
                 "password_confirmation"=>"abcabcabc",
                 "id"=>"15"}},
       "commit"=>"Submit",
       "action"=>"complete",
       "controller"=>"accounts",
       "terms_of_service" => 1,
       "id"=>"14"
      }
    }

    it 'should redirect the user to finalize if the user could not be saved' do
      market = FactoryGirl.create(:market)
      ZipCode.stub(:markets_by_zip_code).and_return([market])
      post :create, default_account_params
      local_params = params.clone
      local_params.merge!({'account_role_id' => assigns[:account].account_roles.first.id.to_s,
                           'id' => assigns[:account].id.to_s
                          })

      local_params['account_role']['user_attributes']['password'] = '123123123'
      local_params['location_id'] = assigns[:location].id
      put :complete, local_params
      expect_redirect_to finalize_account_url(assigns[:account])
    end

    it 'should redirect the user to the root url on success' do
      market = FactoryGirl.create(:market)
      ZipCode.stub(:markets_by_zip_code).and_return([market])
      post :create, default_account_params
      local_parameters = params.clone
      local_parameters.merge!({'account_role_id' => assigns[:account].account_roles.first.id.to_s,
                               'id' => assigns[:account].id.to_s
                              })
      local_parameters['location_id'] = assigns[:location].id
      put :complete, local_parameters
      expect_redirect_to root_url
    end

    it 'should assign the foodizen role to the user on successful' do
      market = FactoryGirl.create(:market)
      ZipCode.stub(:markets_by_zip_code).and_return([market])
      post :create, default_account_params
      local_parameters = params.clone
      local_parameters.merge!({'account_role_id' => assigns[:account].account_roles.first.id.to_s,
                               'id' => assigns[:account].id.to_s
                              })
      local_parameters['location_id'] = assigns[:location].id
      put :complete, local_parameters
      expect(assigns[:user].roles).to eq ['catering_foodizen', 'foodizen']
    end

    it 'should log the user in on success' do
      market = FactoryGirl.create(:market)
      ZipCode.stub(:markets_by_zip_code).and_return([market])
      post :create, default_account_params
      local_param = params.clone
      local_param.merge!({'account_role_id' => assigns[:account].account_roles.first.id.to_s,
                               'id' => assigns[:account].id.to_s
                              })
      local_param['location_id'] = assigns[:location].id
      put :complete, local_param
      controller.current_user.should_not be_nil
    end

    it 'should redirect the user to step if the terms of service is not accepted' do
      market = FactoryGirl.create(:market)
      ZipCode.stub(:markets_by_zip_code).and_return([market])
      post :create, default_account_params
      local_param = params.clone
      local_param.merge!({'account_role_id' => assigns[:account].account_roles.first.id.to_s,
                          'id' => assigns[:account].id.to_s
                         })
      local_param['location_id'] = assigns[:location].id
      local_param.delete('terms_of_service')
      put :complete, local_param
      expect_redirect_to finalize_account_url(assigns[:account])
    end

    it 'should save the time the terms of service agreement was accepted' do
      market = FactoryGirl.create(:market)
      ZipCode.stub(:markets_by_zip_code).and_return([market])
      post :create, default_account_params
      local_param = params.clone
      local_param.merge!({'account_role_id' => assigns[:account].account_roles.first.id.to_s,
                          'id' => assigns[:account].id.to_s
                         })
      local_param['location_id'] = assigns[:location].id
      put :complete, local_param
      assigns[:user].agreed_terms_at.should_not be_nil
    end
  end

  describe 'POST /accounts - as admin' do
    let(:account) {
      {"utf8" => "✓",
          "account" => {
          "name" => "Arsenal FC",
          "account_type" => "corporate",
          "account_manager_id" => "430",
          "account_exec_id" => "430",
          "sales_rep_id" => "430",
          "active" => "1",
          "tax_exempt" => "1"
      },
          "admin_account_creation" => "true"
      }
    }

    it 'should create a new account when created via the admin route' do
      user = User.where(:roles_mask => 31).last
      user.save
      account['account'].merge!({'account_exec_id' => user.id,
                                 'sales_rep_id' => user.id,
                                 'account_manager_id' => user.id
                                })

      account_count = Account.count
      post :create, account
      Account.count.should eq(account_count + 1)
    end
  end

  describe "POST /accounts" do
    let(:account){
                   { "account_role"=>
                    {"role"=>"administrator",
                     "user_attributes"=>
                         {"first_name"=>"Siddharth",
                          "last_name"=>"Ravichandran",
                          "email"=>"siddharth@idyllic-software.com",
                          "phone_number" => "(123) 123 1231"
                         }
                    },
                "account"=>
                    {"account_type"=>"corporate",
                     "name"=>"Idyllic Software",
                     "address_attributes"=>
                         {"name"=>"Poxabogue Golf Center - Pro Shop",
                          "address1"=>"3556 Montauk Highway",
                          "address2"=>"",
                          "city"=>"Wainscott",
                          "state"=>"New York",
                          "zip_code"=>"10020"
                         }
                    },
                "location" => {
                    "name" => "Loading Docs"
                  }
                }
    }

    it "should create an account" do
      market = FactoryGirl.create(:market)
      ZipCode.stub(:markets_by_zip_code).and_return([market])
      assert_difference 'Account.count' do
        post :create, account
      end
      expect_redirect_to finalize_account_url(assigns(:account))
      expect(flash[:notice]).to eq "Almost done!"
    end

    it "should not create an account when there is no active market" do
      params = account.clone
      params['account']['address_attributes']['zip_code'] = 'asdasdasd'
      post :create, params
      expect_redirect_to share_accounts_url
    end

    it '- on failure should create a new CateringSalesLead' do
      param = account.clone
      param['account']['address_attributes']['zip_code'] = 'asdasdasd'
      c = CateringSalesLead.count
      post :create, param
      CateringSalesLead.count.should eq(c + 1)
    end

    it "should not create an account without required parameters" do
      blankhash = account.clone
      blankhash["account_role"]["user_attributes"]["first_name"] = ""
      post :create, blankhash
      response.should render_template('new')
    end
  end

  describe do
    user = FactoryGirl.create :user
    new_account = {:name => "Enbake Consulting", :account_type => "corporate", :account_manager_id => user.id,
                   :account_exec_id => user.id, :sales_rep_id => user.id, :active => 1, :tax_exempt => 1}
    blank_hash = new_account.dup

    describe "PUT /accounts/:id" do
      it "should update an existing account" do
        put :update, :account => new_account.dup.select{|k,v| k == :name}, :id => account.id
        expect_redirect_to account_path(account)
        expect(flash[:notice]).to eq "Account updated successfully."
        expect(account.reload.name).to eq "Enbake Consulting"
      end

      it "should not update an existing account without required parameters" do
        post :update, :account => blank_hash.each{|k,v| blank_hash[k]=""}, :id => account.id
        expect_redirect_to account_path(account)
        expect(flash[:error]).to eq "Error updating account - Name can't be blank, Account type can't be blank"
      end
    end

    describe "DELETE /accounts/:id" do
      it "should delete an existing account" do
        account # preload
        assert_difference 'Account.count', -1 do
          delete :destroy, :id => account.id
        end
        expect(flash[:notice]).to eq "Account deleted."
      end

      it "should not delete an existing account if have some restricted dependents" do
        create_system_user
        event_schedule = FactoryGirl.create :event_schedule
        delete :destroy, :id => event_schedule.account.id
        expect(flash[:error]).to eq "Error destorying account - Cannot delete record because of dependent events"
      end
    end

    describe "PUT /account/:id/associate_users" do
      let(:user1){ FactoryGirl.create(:user) }
      let(:user2){ FactoryGirl.create(:user) }

      it "should associate users as members" do
        assert_difference 'account.users.count', 2 do
          put :associate_users, :id => account.id, :add_users => "#{user1.id},#{user2.id}", :remove_users => ""
        end
      end

      it "should dis-associate users as members" do
        test_user1 = FactoryGirl.create(:user)
        test_user1.email = "testuser#{Time.now.to_i}@example.com"
        test_user1.save
        account_role = AccountRole.new
        account_role.account_id = account.id
        account_role.user_id = test_user1.id
        account.account_roles << account_role
        account.save
        user_count = account.users.size
        put :associate_users, :id => account.id, :add_users => "",
            :remove_users => "#{test_user1.id}"

        expect(account.users.size.to_i).to eq (user_count - 1)
      end
    end
  end

  describe "GET /accounts/:id/export_bar_graph_data.xls" do
    it "should export xls file" do
      level = ["Event Level Food Ratings", "Aggregate Item Level Food Ratings", "Food Presentation", "Order Accuracy", "On Time Delivery", "Ease of Ordering", "Customer Service"].sample
      product_type = %w(select perks managed_services).sample
      get :export_bar_graph_data, :id => account.id, :format => :xls, :product_type => product_type, :level => level
      expect(response.header["Content-Type"]).to eq "application/xls; charset=utf-8"
      expect(response.header["Content-Disposition"]).to eq "attachment; filename=\"bar_graph_reviews.xls\""
    end
  end

  describe "GET /accounts/:id/export_item_reviews.xls" do
    it "should export xls file" do
      level = ["Event Level Food Ratings", "Aggregate Item Level Food Ratings"].sample
      product_type = %w(select perks managed_services).sample
      get :export_item_reviews, :id => account.id, :format => :xls, :product_type => product_type, :level => level
      expect(response.header["Content-Type"]).to eq "application/xls; charset=utf-8"
      expect(response.header["Content-Disposition"]).to eq "attachment; filename=\"#{level}.xls\""
    end
  end

  describe "GET /accounts/:id/export_presentation_reviews.xls" do
    it "should export xls file" do
      level = ["Food Presentation", "Order Accuracy", "On Time Delivery", "Ease of Ordering", "Customer Service"].sample
      product_type = %w(select perks managed_services).sample
      get :export_item_reviews, :id => account.id, :format => :xls, :product_type => product_type, :level => level
      expect(response.header["Content-Type"]).to eq "application/xls; charset=utf-8"
      expect(response.header["Content-Disposition"]).to eq "attachment; filename=\"#{level}.xls\""
    end
  end
end
