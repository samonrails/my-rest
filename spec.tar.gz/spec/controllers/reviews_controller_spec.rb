require 'spec_helper'

describe ReviewsController do

 let(:user) { create(:user)}

  before do
    request.env['HTTPS'] = 'on'
    request.env['HTTP_REFERER'] = ':back'
    sign_in_user(user)
  end

#update
 describe "PUT  /reviews/:id" do
   let(:inventory_item) {create(:inventory_item)}
   let(:select_order_item){create(:select_order_item)}
   let(:select_order) {create(:select_order)}
   let(:review){create(:review,:reviewable_id => inventory_item.id,:reviewable_type => "InventoryItem", :select_order_id => select_order.id )}

    it "should update reviews without items" do
      put :update, :id => review.id, :review => { :rating => "3", :id => review.id,:rating_type=>"individual", 
                                                      :additional_select_order_reviews=> ["packaging", "delivery", "portion"],:content => "deliver it at a time"}
      json_response = JSON.parse response.body
      expect(json_response["message"]).to eq "Reviews saved successfully."
   end
   
  end


end
