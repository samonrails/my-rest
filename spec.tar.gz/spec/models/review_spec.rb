# == Schema Information
#
# Table name: reviews
#
#  id                              :integer          not null, primary key
#  reviewable_id                   :integer
#  reviewable_type                 :string(255)
#  contact_id                      :integer
#  rating                          :integer
#  content                         :text
#  event_id                        :integer
#  created_at                      :datetime         not null
#  updated_at                      :datetime         not null
#  rating_type                     :string(255)
#  additional_event_ratings        :string(255)
#  select_order_id                 :integer
#  additional_select_order_reviews :string(255)
#

require 'spec_helper'

 describe Review do
  
  let(:review) { create(:review) }

  it "should be valid" do
    review.should be_valid
  end

  it "should belong to select order" do
    review.should belong_to(:select_order)
  end
end