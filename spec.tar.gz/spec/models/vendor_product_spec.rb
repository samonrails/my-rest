# == Schema Information
#
# Table name: vendor_products
#
#  id           :integer          not null, primary key
#  product      :string(30)
#  vendor_id    :integer
#  product_type :string(20)
#

require 'spec_helper'

describe "VendorProduct" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
