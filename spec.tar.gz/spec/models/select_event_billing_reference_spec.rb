# == Schema Information
#
# Table name: select_event_billing_references
#
#  select_event_id      :integer
#  billing_reference_id :integer
#  id                   :integer          not null, primary key
#

require 'spec_helper'

describe "SelectEventBillingReference" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
