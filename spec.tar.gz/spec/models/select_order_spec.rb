require 'spec_helper'

describe Select::SelectOrder do

  let (:inventory_item) { create(:inventory_item, sell_price_cents: 533) }
  let (:select_event) { create(:select_event_with_locations)}
  let (:select_order) { create(:select_order)}
  let (:current_item) { create(:select_order_item, quantity: 1, status: :current, inventory_item: inventory_item)}

  before do
    select_order.select_order_items << current_item
  end

  it "is valid" do
    expect(select_order).to be_valid
  end

  describe "calculating totals gets correct" do
    let(:adjusted_subtotal){ Money.new(1000) }
    # it "subtotal" do
    # 	expect(select_order.order_subtotal(:provisioned)).to eq(480)
    # end

    # it "gratuity if default" do
    # 	expect(select_order.gratuity_amount(480)).to eq(48)
    # end

    # it "delivery amount" do
    # end

    # it "tax amount" do
    # 	expect(select_order.tax_amount(480)).to eq(tax)
    # end

    # it "subsidy amount" do
    # end

    # it "total amount" do
    # end
    it "calculates gratuity if selected" do
      select_order.update_attributes(gratuity_selected: 20.0)
      expect(select_order.gratuity_calculation(adjusted_subtotal)).to eq(Money.new(200))
    end

    it "calculates gratuity based on event if not selected" do
      expect(select_order.gratuity_calculation(adjusted_subtotal)).to eq(Money.new(100))
    end

  end

  describe "#subsidy" do
    before { select_order.save }

    let(:order_subtotal) do
      select_order.subtotal_amount +
        select_order.gratuity_amount +
        select_order.delivery_amount +
        select_order.tax_amount
    end

    it "returns the correct subsidy amount" do
      expect(select_order.subsidy(order_subtotal)).to eq(Money.new(0))
    end

    context "when the event has fixed amount subsidy" do
      let(:select_order) { create(:select_order, :fixed_subsidy_10) }

      it "returns the correct subsidy amount" do
        expect(select_order.subsidy(order_subtotal)).to eq(order_subtotal)
      end
    end
  end

  # describe "#recalc_totals_for_save" do
  # end

  describe "#can_save?" do

    it "prohibits save when status is not set" do
      select_order.status = nil
      expect(select_order.can_save?).to be_false
    end

    it "saves order if it has 'cart' status" do
      select_order.status = 'cart'
      expect(select_order.can_save?).to be_true
    end

    it "saves order if has 'checkout' status" do
      select_order.status = 'checkout'
      expect(select_order.can_save?).to be_true
    end

    # it "saves order if checkout complete and user is admin" do
    # 	select_order.status = 'checkout_complete'
    # 	DETERMINE THAT USER IS ADMIN
    # 	expect(select_order.can_save?).to be_true
    # end

    # it "saves order if checkout is canceled and user is admin" do
    # 	select_order.status = 'canceled'
    # 	DETERMINE THAT USER IS ADMIN
    # 	expect(select_order.can_save?).to be_true
    # end

    # it "will not save order for checkout if user is not admin" do
    # 	select_order.status = 'checkout_complete'
    # 	expect(select_order.can_save?).to be_false
    # end
  end

  describe "calculating order totals" do
    it "returns the correct quantity" do
      select_order.select_order_items.count.should == 1
    end
  end

  def closed_ordering_window
    Time.at(0)
  end

  describe "payment transaction" do
    let(:test_card) { create(:card, token: "fooda")}
    let(:new_card)  { { number: "4005519200000004", cvv: "123", expiration_month: "01", expiration_year: "2020" }}
    let (:provisioned_item_2qty) { create(:select_order_item, quantity: 2, status: :provisioned, inventory_item: inventory_item)}
    before do
      # Add a current item with qty = 2 to the order
      select_order.select_order_items << provisioned_item_2qty
      select_order.save
    end

    it "calculates the payment amount correctly", focus: true do
      totals = select_order.recalc_totals :current
      # 500 based on cogs of 4 in inventory_item x 25% markup
      expect(totals[:subtotal_amount].cents).to eq(533)
      expect(select_order.payment_or_refund_amount.cents).to be > 500
    end

    # valid_for_transaction? payment, strict=true
    context "perform strict sanity checks on transaction data" do
      let(:params)         { { is_refund: "false", amount: "0", card_id: test_card.id.to_s }}
      let(:payment_amount) { select_order.recalc_totals(:provisioned)[:total_amount] - select_order.recalc_totals(:current)[:total_amount]}
      before(:each)        { params[:amount] = payment_amount.to_s}

      # Tests to check totals on payments
      it "is valid if expected total equals calculated total" do
        expect(select_order.valid_for_transaction?(params, true)).to eq(true)
      end
      it "is not valid if expected total is more than the calculated total" do
        params[:amount] = (payment_amount + Money.new(1.0)).to_s
        expect(select_order.valid_for_transaction?(params, true)).to eq(false)
      end
      it "is not valid if expected total is less than the calculated total" do
        params[:amount] = (payment_amount - Money.new(1.0)).to_s
        expect(select_order.valid_for_transaction?(params, true)).to eq(false)
      end

      # Test to check totals on payments if refund is set to TRUE
      it "is not valid if expected and calculated totals match but transaction is marked as refund" do
        params[:is_refund] = "true"
        expect(select_order.valid_for_transaction?(params, true)).to eq(false)
      end

      # Test to check for new cards with valid amounts
      it "is not valid if a new card is provided and card number is not present" do
        expect(select_order.valid_for_transaction?(params.except(:card_id).merge(new_card.except(:number)), true)).to eq(false)
      end
      it "is not valid if a new card is provided and cvv is not present" do
        expect(select_order.valid_for_transaction?(params.except(:card_id).merge(new_card.except(:cvv)), true)).to eq(false)
      end
      it "is not valid if a new card is provided and expiration month is not present" do
        expect(select_order.valid_for_transaction?(params.except(:card_id).merge(new_card.except(:expiration_month)), true)).to eq(false)
      end
      it "is not valid if a new card is provided and expiration year is not present" do
        expect(select_order.valid_for_transaction?(params.except(:card_id).merge(new_card.except(:expiration_year)), true)).to eq(false)
      end

      # valid if all data is available with valid amount
      it "is valid if a new card is provided" do
        expect(select_order.valid_for_transaction?(params.except(:card_id).merge(new_card), true)).to eq(true)
      end
    end

    # valid_for_transaction? payment, strict=false
    context "perform un-strict sanity checks on arbitrary transaction data" do
      let(:params) { { is_refund: "false", amount: "0", card_id: test_card.id.to_s }}

      it "is not valid if a zero amount is provided for payment" do
        expect(select_order.valid_for_transaction?(params, false)).to eq(false)
      end
      it "is not valid if a negative amount is provided for payment" do
        expect(select_order.valid_for_transaction?(params.merge({amount: "-1.00"}), false)).to eq(false)
      end
      it "is valid if any positive amount is provided for payment" do
        use_amount = (select_order.recalc_totals(:current)[:total_amount] + Money.new(Random.rand(100000)))
        expect(select_order.valid_for_transaction?(params.merge({amount: use_amount.to_s}), false)).to eq(true)
      end
    end

    # braintree_transact payments
    context "collect payments from the user" do
      before(:all) do
        FakeBraintree.verify_all_cards!
        Braintree::Customer.create(id: "dummy", first_name: "Fooda")
        Braintree::CreditCard.create(
          customer_id: "dummy",
          number: "4111111111111111",
          expiration_date: "01/2020",
          token: "fooda")
      end
      let(:test_card)      { create(:card, token: "fooda")}
      let(:payment_amount) { select_order.recalc_totals(:provisioned)[:total_amount] - select_order.recalc_totals(:current)[:total_amount]}
      let(:params)         { { is_refund: "false", amount: payment_amount.to_s, store_in_vault: "false"}}

      # Existing cards
      it "rejects a payment transaction using a bad/non-existent card" do
        FakeBraintree.decline_all_cards!
        params[:card_id] = 100000 + Random.rand(100000)
        expect(select_order.braintree_transact(params)).to be(false)
      end
      it "creates a payment transaction using an existing card" do
        params[:card_id] = test_card.id.to_s
        expect(select_order.braintree_transact(params)).to be(true)
      end

      # New card
      it "rejects a payment transaction when a card number is not present" do
        FakeBraintree.decline_all_cards!
        expect(select_order.braintree_transact(params.merge(new_card.except(:number)))).to be(false)
      end
      it "rejects a payment transaction when the expiration month not present" do
        FakeBraintree.decline_all_cards!
        expect(select_order.braintree_transact(params.merge(new_card.except(:expiration_month)))).to be(false)
      end
      it "rejects a payment transaction when the expiration year not present" do
        FakeBraintree.decline_all_cards!
        expect(select_order.braintree_transact(params.merge(new_card.except(:expiration_year)))).to be(false)
      end

      it "creates a payment transaction using a valid new card" do
        expect(select_order.braintree_transact(params.merge(new_card))).to be(true)
      end
    end

  end

  describe "refund transaction" do
    let (:select_event) { create(:select_event)}
    let (:select_order) { create(:select_order)}
    let (:current_item_2qty) { create(:select_order_item, quantity: 1, status: :current, inventory_item: inventory_item)}
    before do
      # Add a current item with qty = 2 to the order
      select_order.select_order_items << current_item_2qty
      select_order.save
    end

    it "calculates the refund amount correctly" do
      totals = select_order.recalc_totals :current
      # 1000 based on cogs of 4 in inventory_item x 25% markup x 2 qty
      totals[:subtotal_amount].cents.should eq(1066)
      expect(select_order.payment_or_refund_amount.cents).to be < -1000
    end

    # valid_for_transaction? refund, strict=true
    context "perform strict sanity checks on transaction data" do
      let(:params)        { { is_refund: "true", amount: "0" }}
      let(:refund_amount) { select_order.recalc_totals(:current)[:total_amount] - select_order.recalc_totals(:provisioned)[:total_amount]}

      # Tests to check totals on payments
      it "is valid if expected total equals calculated total" do
        params[:amount] = refund_amount.to_s
        expect(select_order.valid_for_transaction?(params, true)).to be(true)
      end
      it "is not valid if expected total is more than the calculated total" do
        params[:amount] = (refund_amount + Money.new(1.0)).to_s
        expect(select_order.valid_for_transaction?(params, true)).to be(false)
      end
      it "is not valid if expected total is less than the calculated total" do
        params[:amount] = (refund_amount - Money.new(1.0)).to_s
        expect(select_order.valid_for_transaction?(params, true)).to be(false)
      end

      # Test to check totals on payments if refund is set to TRUE
      it "is not valid if expected and calculated totals match but transaction is marked as payment" do
        params[:is_refund] = "false"
        params[:amount] = refund_amount.to_s
        expect(select_order.valid_for_transaction?(params, true)).to be(false)
      end
    end

    # valid_for_transaction? refund, strict=false
    context "perform un-strict sanity checks on arbitrary transaction data" do
      let(:params) { { is_refund: "true", amount: "0"}}
      before do
        select_order.save
      end

      it "is not valid if a zero amount is provided for refund" do
        expect(select_order.valid_for_transaction?(params, false)).to eq(false)
      end
      it "is not valid if a negative amount is provided for refund" do
        expect(select_order.valid_for_transaction?(params.merge({amount: "-1.00"}), false)).to eq(false)
      end
      it "is not valid if any amount higher than order total is provided for refund" do
        use_amount = (select_order.recalc_totals(:current)[:total_amount] + Money.new(Random.rand(100000)))
        expect(select_order.valid_for_transaction?(params.merge({amount: use_amount.to_s}), false)).to eq(false)
      end
      it "is valid if any amount equal to the order amount is provided for refund" do
        use_amount = select_order.recalc_totals(:current)[:total_amount]
        expect(select_order.valid_for_transaction?(params.merge({amount: use_amount.to_s}), false)).to eq(true)
      end
      it "is valid if any amount less than the order amount is provided for refund" do
        use_amount = (select_order.recalc_totals(:current)[:total_amount] - Money.new(1))
        expect(select_order.valid_for_transaction?(params.merge({amount: use_amount.to_s}), false)).to eq(true)
      end
    end

    # braintree_transact refunds
    context "issue refunds to the user" do
      let(:refund_amount) { select_order.recalc_totals(:current)[:total_amount] - select_order.recalc_totals(:provisioned)[:total_amount]}
      let(:params)        { { is_refund: "true", amount: refund_amount.to_s }}

      before do
        FakeBraintree.verify_all_cards!
        # Create a payment transaction to begin with
        totals = select_order.recalc_totals :current
        select_order.braintree_transact({
          is_refund: "false",
          amount: refund_amount.to_s,
          number: "4009348888881881",
          expiration_month: "01",
          expiration_year: "2020",
          cvv: "123",
        })
      end

      it "creates a refund transaction with partial amount due to user" do
        expect(select_order.braintree_transact(params)).to be(true)
      end
      it "creates a refund transaction with full amount due to user" do
        params[:amount] = select_order.recalc_totals(:current)[:total_amount].to_s
        expect(select_order.braintree_transact(params)).to be(true)
      end
    end
  end

  describe "payment settlements" do
    let (:select_event) { create(:select_event) }
    let (:select_order) { create(:select_order, status: :checkout_complete) }
    let (:current_item) { create(:select_order_item, quantity: 1, status: :current, inventory_item: inventory_item) }
    let (:payment_amount) { select_order.recalc_totals(:current)[:total_amount] }
    before do
      select_order.select_order_items << current_item
      select_order.save
      select_order.braintree_transact({
        is_refund: "false",
        amount: payment_amount.to_s,
        number: "4012000033330026",
        expiration_month: "01",
        expiration_year: "2020",
        cvv: "123",
      })
    end

    it "has unsettled transactions" do
      expect(select_order.braintree_settled?).to be(false)
    end

    # fake_braintree 0.4.1 now supports Braintree::Transaction.submit_for_settlement
    it "has no unsettled transactions after settelements" do
      expect(select_order.braintree_settle).to eq(1)
      expect(select_order.select_order_transactions.first.status).to eq('submitted_for_settlement')
    end

  end

end
