require 'spec_helper'

describe Event::FinancialsRollup do

  before(:each) do
    if PricingTier.all.count == 0
      Fooda::Util::create_pricing_tiers
    end

    if LineItemType.all.count == 0
      Fooda::Util::create_line_item_types
    end
  end
  
  let(:vendor) { create(:vendor) }

  let(:account) { create(:account) }

  let(:product) { 'catering' }

  let(:populated_menu_template_catering) do
    menu_template   = create(:menu_template, vendor: vendor, pricing_type: MenuPricingType.menu_level, cogs: 7.10, retail_price: 9.40)

    # do some work to make sure that the inventory items all have unique buy prices
    3.times { |count|
      menu_template.inventory_items << create(:inventory_item, vendor: vendor, cogs: 10*count + 1)
    }

    # do some work to make sure that the menu level discounts all have unique buy and sell prices
    3.times { |count|
      menu_template.menu_level_discounts << create(:menu_level_discount, cogs: 10*count + 1, sell_price: 10*count + 2)
    }

    menu_template
  end
  let(:event_catering) do
    e1 = Event.create!(
      :account => account,
      :name => "My Catering Event", :event_start_time => "5/1/2013 11:30pm", 
      :meal_period => MealPeriod.lunch, :product => product, :location => FactoryGirl.create(:spot_location))

    e1.add_replace_menu_template(populated_menu_template_catering, 40)
    e1
  end
  
  let(:event_catering_account_credit) do
    e1 = Event.create!(
      :account => account,
      :name => "My Catering Event", :event_start_time => "5/1/2013 11:30pm", 
      :meal_period => MealPeriod.lunch, :product => product, :location => FactoryGirl.create(:spot_location))

    e1.add_replace_menu_template(populated_menu_template_catering, 40)

    line_item_type = LineItemType.where(:line_item_type => "Financial", :line_item_sub_type => "Credit Memo").first

    e1.line_items.create!(
      :line_item_type => line_item_type.line_item_type,
      :line_item_sub_type => line_item_type.line_item_sub_type,
      :sku => line_item_type.sku,
      :name => line_item_type.line_item_type,
      :notes => "Do some stuff",
      :quantity => 1,
      :include_price_in_expense => true,
      :include_price_in_revenue => true,
      :billable_party_type => "Account",
      :billable_party_id => e1.account.id,
      :unit_price_revenue => 45.15)

    e1
  end

  let(:event_catering_vendor_credit) do
    e1 = Event.create!(
      :account => account,
      :name => "My Catering Event", :event_start_time => "5/1/2013 11:30pm", 
      :meal_period => MealPeriod.lunch, :product => product, :location => FactoryGirl.create(:spot_location))

    e1.add_replace_menu_template(populated_menu_template_catering, 40)

    line_item_type = LineItemType.where(:line_item_type => "Financial", :line_item_sub_type => "Credit Memo").first

    e1.line_items.create!(
      :line_item_type => line_item_type.line_item_type,
      :line_item_sub_type => line_item_type.line_item_sub_type,
      :sku => line_item_type.sku,
      :name => line_item_type.line_item_type,
      :notes => "Do some stuff",
      :quantity => 1,
      :include_price_in_expense => true,
      :include_price_in_revenue => true,
      :payable_party_type => "Vendor",
      :payable_party_id => e1.event_vendors.first.vendor.id,
      :unit_price_expense => 45.15)

    e1
  end

  let(:event_catering_account_credit_after_subtotal) do
    e1 = Event.create!(
      :account => account,
      :name => "My Catering Event", :event_start_time => "5/1/2013 11:30pm", 
      :meal_period => MealPeriod.lunch, :product => product, :location => FactoryGirl.create(:spot_location))

    e1.add_replace_menu_template(populated_menu_template_catering, 40)

    line_item_type = LineItemType.where(:line_item_type => "Financial", :line_item_sub_type => "Credit Memo").first

    e1.line_items.create!(
      :line_item_type => line_item_type.line_item_type,
      :line_item_sub_type => line_item_type.line_item_sub_type,
      :sku => line_item_type.sku,
      :name => line_item_type.line_item_type,
      :notes => "Do some stuff",
      :quantity => 1,
      :include_price_in_expense => true,
      :include_price_in_revenue => true,
      :billable_party_type => "Account",
      :billable_party_id => e1.account.id,
      :unit_price_revenue => 45.15,
      :after_subtotal => true)

    e1
  end

  let(:event_catering_vendor_credit_after_subtotal) do
    e1 = Event.create!(
      :account => account,
      :name => "My Catering Event", :event_start_time => "5/1/2013 11:30pm", 
      :meal_period => MealPeriod.lunch, :product => product, :location => FactoryGirl.create(:spot_location))

    e1.add_replace_menu_template(populated_menu_template_catering, 40)

    line_item_type = LineItemType.where(:line_item_type => "Financial", :line_item_sub_type => "Credit Memo").first

    e1.line_items.create!(
      :line_item_type => line_item_type.line_item_type,
      :line_item_sub_type => line_item_type.line_item_sub_type,
      :sku => line_item_type.sku,
      :name => line_item_type.line_item_type,
      :notes => "Do some stuff",
      :quantity => 1,
      :include_price_in_expense => true,
      :include_price_in_revenue => true,
      :payable_party_type => "Vendor",
      :payable_party_id => e1.event_vendors.first.vendor.id,
      :unit_price_expense => 45.15,
      :after_subtotal => true)

    e1
  end

  let(:event_catering_account_credit_after_subtotal_percentage) do
    e1 = Event.create!(
      :account => account,
      :name => "My Catering Event", :event_start_time => "5/1/2013 11:30pm", 
      :meal_period => MealPeriod.lunch, :product => product, :location => FactoryGirl.create(:spot_location))

    e1.add_replace_menu_template(populated_menu_template_catering, 40)

    line_item_type = LineItemType.where(:line_item_type => "Financial", :line_item_sub_type => "Credit Memo").first

    e1.line_items.create!(
      :line_item_type => line_item_type.line_item_type,
      :line_item_sub_type => line_item_type.line_item_sub_type,
      :sku => line_item_type.sku,
      :name => line_item_type.line_item_type,
      :notes => "Do some stuff",
      :quantity => 1,
      :include_price_in_expense => true,
      :include_price_in_revenue => true,
      :billable_party_type => "Account",
      :billable_party_id => e1.account.id,
      :unit_price_revenue => 45.15,
      :after_subtotal => true,
      :percentage_of_subtotal => true)

    e1
  end

  let(:event_catering_vendor_credit_after_subtotal_percentage) do
    e1 = Event.create!(
      :account => account,
      :name => "My Catering Event", :event_start_time => "5/1/2013 11:30pm", 
      :meal_period => MealPeriod.lunch, :product => product, :location => FactoryGirl.create(:spot_location))

    e1.add_replace_menu_template(populated_menu_template_catering, 40)

    line_item_type = LineItemType.where(:line_item_type => "Financial", :line_item_sub_type => "Credit Memo").first

    e1.line_items.create!(
      :line_item_type => line_item_type.line_item_type,
      :line_item_sub_type => line_item_type.line_item_sub_type,
      :sku => line_item_type.sku,
      :name => line_item_type.line_item_type,
      :notes => "Do some stuff",
      :quantity => 1,
      :include_price_in_expense => true,
      :include_price_in_revenue => true,
      :payable_party_type => "Vendor",
      :payable_party_id => e1.event_vendors.first.vendor.id,
      :unit_price_expense => 45.15,
      :after_subtotal => true,
      :percentage_of_subtotal => true)

    e1
  end
  
  context "rolling up catering prices with just a per-person fee" do

    it "calculate the revenue sub-total"  do
      event_catering.revenue_subtotal_by_party(account).should == event_catering.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total
    end

    it "calculate the revenue tax"  do
      event_catering.revenue_general_tax_by_party(account).should == event_catering.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_tax
    end

    it "calculate the revenue after-subtotal items"  do
      event_catering.revenue_after_subtotal_by_party(account).should == 0
    end

    it "calculate the revenue total"  do
      event_catering.revenue_total_by_party(account).should == 
        event_catering.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total +
        event_catering.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_tax
    end

    it "calculate the expense sub-total"  do
      event_catering.expense_subtotal_by_party(vendor).should == event_catering.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total
    end

    it "calculate the expense tax"  do
      event_catering.expense_general_tax_by_party(vendor).should == event_catering.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_tax
    end

    it "calculate the expense after-subtotal items"  do
      event_catering.expense_after_subtotal_by_party(vendor).should == 0
    end

    it "calculate the expense total"  do
      event_catering.expense_total_by_party(vendor).should == 
        event_catering.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total +
        event_catering.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_tax
    end

    it "calculate the total of Menu-Fee revenue items" do
      event_catering.revenue_by_party_and_line_item_subtype(account, "Menu-Fee") == 
      event_catering.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total
    end

    it "calculate the total of Menu-Fee expense items" do
      event_catering.expense_by_party_and_line_item_subtype(vendor, "Menu-Fee") == 
      event_catering.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total
    end

  end

  context "rolling up catering prices with a per-person fee and subtotal-included account credit" do

    it "calculate the revenue sub-total"  do

      event_catering_account_credit.revenue_subtotal_by_party(account).should == 
        event_catering_account_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total +
        event_catering_account_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Credit Memo"}.first.revenue_total
    end

    it "calculate the revenue tax"  do
      event_catering_account_credit.revenue_general_tax_by_party(account).should == 
        event_catering_account_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_tax +
        event_catering_account_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Credit Memo"}.first.revenue_tax
    end

    it "calculate the revenue after-subtotal items"  do
      event_catering_account_credit.revenue_after_subtotal_by_party(account).should == 0
    end

    it "calculate the revenue total"  do
      event_catering_account_credit.revenue_total_by_party(account).should == 
        event_catering_account_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total +
        event_catering_account_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_tax +
        event_catering_account_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Credit Memo"}.first.revenue_total +
        event_catering_account_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Credit Memo"}.first.revenue_tax
    end

    it "calculate the expense sub-total"  do
      event_catering_account_credit.expense_subtotal_by_party(vendor).should == 
        event_catering_account_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total
    end

    it "calculate the expense tax"  do
      event_catering_account_credit.expense_general_tax_by_party(vendor).should == 
        event_catering_account_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_tax
    end

    it "calculate the expense after-subtotal items"  do
      event_catering_account_credit.expense_after_subtotal_by_party(vendor).should == 0
    end

    it "calculate the expense total"  do
      event_catering_account_credit.expense_total_by_party(vendor).should == 
        event_catering_account_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total +
        event_catering_account_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_tax
    end

    it "calculate the total of Menu-Fee revenue items" do
      event_catering_account_credit.revenue_by_party_and_line_item_subtype(account, "Menu-Fee") == 
        event_catering_account_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total
    end

    it "calculate the total of Menu-Fee expense items" do
      event_catering_account_credit.revenue_by_party_and_line_item_subtype(vendor, "Menu-Fee") == 
        event_catering_account_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total
    end

    it "calculate the total of Credit Memo revenue items" do
      event_catering_account_credit.revenue_by_party_and_line_item_subtype(account, "Credit Memo") == 
        event_catering_account_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Credit Memo"}.first.revenue_total
    end

    it "calculate the total of Credit Memo expense items" do
      event_catering_account_credit.revenue_by_party_and_line_item_subtype(vendor, "Credit Memo") == 0
    end

  end

  context "rolling up catering prices with a per-person fee and subtotal-included vendor credit" do

    it "calculate the revenue sub-total"  do
      event_catering_vendor_credit.revenue_subtotal_by_party(account).should == 
        event_catering_vendor_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total
    end

    it "calculate the revenue tax"  do
      event_catering_vendor_credit.revenue_general_tax_by_party(account).should == 
        event_catering_vendor_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_tax
    end

    it "calculate the revenue after-subtotal items"  do
      event_catering_vendor_credit.revenue_after_subtotal_by_party(account).should == 0
    end

    it "calculate the revenue total"  do
      event_catering_vendor_credit.revenue_total_by_party(account).should == 
        event_catering_vendor_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total +
        event_catering_vendor_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_tax
    end

    it "calculate the expense sub-total"  do
      event_catering_vendor_credit.expense_subtotal_by_party(vendor).should == 
        event_catering_vendor_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total +
        event_catering_vendor_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Credit Memo"}.first.expense_total
    end

    it "calculate the expense tax"  do
      event_catering_vendor_credit.expense_general_tax_by_party(vendor).should == 
        event_catering_vendor_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_tax +
        event_catering_vendor_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Credit Memo"}.first.expense_tax
    end

    it "calculate the expense after-subtotal items"  do
      event_catering_vendor_credit.expense_after_subtotal_by_party(vendor).should == 0
    end

    it "calculate the expense total"  do
      event_catering_vendor_credit.expense_total_by_party(vendor).should == 
        event_catering_vendor_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total +
        event_catering_vendor_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_tax +
        event_catering_vendor_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Credit Memo"}.first.expense_total +
        event_catering_vendor_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Credit Memo"}.first.expense_tax
    end

    it "calculate the total of Menu-Fee revenue items" do
      event_catering_vendor_credit.revenue_by_party_and_line_item_subtype(account, "Menu-Fee") == 
        event_catering_vendor_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total
    end

    it "calculate the total of Menu-Fee expense items" do
      event_catering_vendor_credit.revenue_by_party_and_line_item_subtype(vendor, "Menu-Fee") == 
        event_catering_vendor_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total
    end

    it "calculate the total of Credit Memo revenue items" do
      event_catering_vendor_credit.revenue_by_party_and_line_item_subtype(account, "Credit Memo") == 0
    end

    it "calculate the total of Credit Memo expense items" do
      event_catering_vendor_credit.revenue_by_party_and_line_item_subtype(vendor, "Credit Memo") ==
        event_catering_vendor_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Credit Memo"}.first.expense_total
    end

  end

  context "rolling up catering prices with a per-person fee and and after-subtotal account credit" do

    it "calculate the revenue sub-total"  do
      event_catering_account_credit_after_subtotal.revenue_subtotal_by_party(account).should == 
        event_catering_account_credit_after_subtotal.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total
    end

    it "calculate the revenue tax"  do
      event_catering_account_credit_after_subtotal.revenue_general_tax_by_party(account).should == 
        event_catering_account_credit_after_subtotal.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_tax
    end

    it "calculate the revenue after-subtotal items"  do
      event_catering_account_credit_after_subtotal.revenue_after_subtotal_by_party(account).should ==
        event_catering_account_credit_after_subtotal.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Credit Memo"}.first.revenue_total
    end

    it "calculate the revenue total"  do
      event_catering_account_credit_after_subtotal.revenue_total_by_party(account).should == 
        event_catering_account_credit_after_subtotal.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total +
        event_catering_account_credit_after_subtotal.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_tax +
        event_catering_account_credit_after_subtotal.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Credit Memo"}.first.revenue_total
    end

    it "calculate the expense sub-total"  do
      event_catering_account_credit_after_subtotal.expense_subtotal_by_party(vendor).should == 
        event_catering_account_credit_after_subtotal.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total
    end

    it "calculate the expense tax"  do
      event_catering_account_credit_after_subtotal.expense_general_tax_by_party(vendor).should == 
        event_catering_account_credit_after_subtotal.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_tax
    end

    it "calculate the expense after-subtotal items"  do
      event_catering_account_credit_after_subtotal.expense_after_subtotal_by_party(vendor).should == 0
    end

    it "calculate the expense total"  do
      event_catering_account_credit_after_subtotal.expense_total_by_party(vendor).should == 
        event_catering_account_credit_after_subtotal.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total +
        event_catering_account_credit_after_subtotal.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_tax
    end

    it "calculate the total of Menu-Fee revenue items" do
      event_catering_account_credit.revenue_by_party_and_line_item_subtype(account, "Menu-Fee") == 
        event_catering_account_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total
    end

    it "calculate the total of Menu-Fee expense items" do
      event_catering_account_credit.revenue_by_party_and_line_item_subtype(vendor, "Menu-Fee") == 
        event_catering_account_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total
    end

    it "calculate the total of Credit Memo revenue items" do
      event_catering_account_credit.revenue_by_party_and_line_item_subtype(account, "Credit Memo") == 
        event_catering_account_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Credit Memo"}.first.revenue_total
    end

    it "calculate the total of Credit Memo expense items" do
      event_catering_account_credit.revenue_by_party_and_line_item_subtype(vendor, "Credit Memo") == 0
    end

  end

  context "rolling up catering prices with a per-person fee and an after-subtotal vendor credit" do

    it "calculate the revenue sub-total"  do
      event_catering_vendor_credit_after_subtotal.revenue_subtotal_by_party(account).should == 
        event_catering_vendor_credit_after_subtotal.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total
    end

    it "calculate the revenue tax"  do
      event_catering_vendor_credit_after_subtotal.revenue_general_tax_by_party(account).should == 
        event_catering_vendor_credit_after_subtotal.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_tax
    end

    it "calculate the revenue after-subtotal items"  do
      event_catering_vendor_credit_after_subtotal.revenue_after_subtotal_by_party(account).should == 0
    end

    it "calculate the revenue total"  do
      event_catering_vendor_credit_after_subtotal.revenue_total_by_party(account).should == 
        event_catering_vendor_credit_after_subtotal.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total +
        event_catering_vendor_credit_after_subtotal.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_tax
    end

    it "calculate the expense sub-total"  do
      event_catering_vendor_credit_after_subtotal.expense_subtotal_by_party(vendor).should == 
        event_catering_vendor_credit_after_subtotal.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total
    end

    it "calculate the expense tax"  do
      event_catering_vendor_credit_after_subtotal.expense_general_tax_by_party(vendor).should == 
        event_catering_vendor_credit_after_subtotal.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_tax
    end

    it "calculate the expense after-subtotal items"  do
      event_catering_vendor_credit_after_subtotal.expense_after_subtotal_by_party(vendor).should ==
        event_catering_vendor_credit_after_subtotal.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Credit Memo"}.first.expense_total
    end

    it "calculate the expense total"  do
      event_catering_vendor_credit_after_subtotal.expense_total_by_party(vendor).should == 
        event_catering_vendor_credit_after_subtotal.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total +
        event_catering_vendor_credit_after_subtotal.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_tax +
        event_catering_vendor_credit_after_subtotal.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Credit Memo"}.first.expense_total
    end

    it "calculate the total of Menu-Fee revenue items" do
      event_catering_vendor_credit.revenue_by_party_and_line_item_subtype(account, "Menu-Fee") == 
        event_catering_vendor_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total
    end

    it "calculate the total of Menu-Fee expense items" do
      event_catering_vendor_credit.revenue_by_party_and_line_item_subtype(vendor, "Menu-Fee") == 
        event_catering_vendor_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total
    end

    it "calculate the total of Credit Memo revenue items" do
      event_catering_vendor_credit.revenue_by_party_and_line_item_subtype(account, "Credit Memo") == 0
    end

    it "calculate the total of Credit Memo expense items" do
      event_catering_vendor_credit.revenue_by_party_and_line_item_subtype(vendor, "Credit Memo") ==
        event_catering_vendor_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Credit Memo"}.first.expense_total
    end

  end

  context "rolling up catering prices with a per-person fee and and after-subtotal account credit that is a percentage" do

    it "calculate the revenue sub-total"  do
      event_catering_account_credit_after_subtotal_percentage.revenue_subtotal_by_party(account).should == 
        event_catering_account_credit_after_subtotal_percentage.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total
    end

    it "calculate the revenue tax"  do
      event_catering_account_credit_after_subtotal_percentage.revenue_general_tax_by_party(account).should == 
        event_catering_account_credit_after_subtotal_percentage.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_tax
    end

    it "calculate the revenue after-subtotal items"  do
      event_catering_account_credit_after_subtotal_percentage.revenue_after_subtotal_by_party(account).should ==
        event_catering_account_credit_after_subtotal_percentage.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Credit Memo"}.first.revenue_total_with_percentage(
          event_catering_account_credit_after_subtotal_percentage.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total)
    end

    it "calculate the revenue total"  do
      event_catering_account_credit_after_subtotal_percentage.revenue_total_by_party(account).should == 
        event_catering_account_credit_after_subtotal_percentage.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total +
        event_catering_account_credit_after_subtotal_percentage.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_tax +
        event_catering_account_credit_after_subtotal_percentage.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Credit Memo"}.first.revenue_total_with_percentage(
          event_catering_account_credit_after_subtotal_percentage.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total)
    end

    it "calculate the expense sub-total"  do
      event_catering_account_credit_after_subtotal_percentage.expense_subtotal_by_party(vendor).should == 
        event_catering_account_credit_after_subtotal_percentage.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total
    end

    it "calculate the expense tax"  do
      event_catering_account_credit_after_subtotal_percentage.expense_general_tax_by_party(vendor).should == 
        event_catering_account_credit_after_subtotal_percentage.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_tax
    end

    it "calculate the expense after-subtotal items"  do
      event_catering_account_credit_after_subtotal_percentage.expense_after_subtotal_by_party(vendor).should == 0
    end

    it "calculate the expense total"  do
      event_catering_account_credit_after_subtotal_percentage.expense_total_by_party(vendor).should == 
        event_catering_account_credit_after_subtotal_percentage.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total +
        event_catering_account_credit_after_subtotal_percentage.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_tax
    end

    it "calculate the total of Menu-Fee revenue items" do
      event_catering_account_credit.revenue_by_party_and_line_item_subtype(account, "Menu-Fee") == 
        event_catering_account_credit.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total
    end

    it "calculate the total of Menu-Fee expense items" do
      event_catering_account_credit.revenue_by_party_and_line_item_subtype(vendor, "Menu-Fee") == 
        event_catering_account_credit.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total
    end

    it "calculate the total of Credit Memo revenue items" do
      event_catering_account_credit.revenue_by_party_and_line_item_subtype(account, "Credit Memo") == 
        event_catering_account_credit_after_subtotal_percentage.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Credit Memo"}.first.revenue_total_with_percentage(
        event_catering_account_credit_after_subtotal_percentage.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total)
    end

    it "calculate the total of Credit Memo expense items" do
      event_catering_account_credit.revenue_by_party_and_line_item_subtype(vendor, "Credit Memo") == 0
    end

  end

  context "rolling up catering prices with a per-person fee and an after-subtotal vendor credit that is a percentage" do

    it "calculate the revenue sub-total"  do
      event_catering_vendor_credit_after_subtotal_percentage.revenue_subtotal_by_party(account).should == 
        event_catering_vendor_credit_after_subtotal_percentage.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total
    end

    it "calculate the revenue tax"  do
      event_catering_vendor_credit_after_subtotal_percentage.revenue_general_tax_by_party(account).should == 
        event_catering_vendor_credit_after_subtotal_percentage.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_tax
    end

    it "calculate the revenue after-subtotal items"  do
      event_catering_vendor_credit_after_subtotal_percentage.revenue_after_subtotal_by_party(account).should == 0
    end

    it "calculate the revenue total"  do
      event_catering_vendor_credit_after_subtotal_percentage.revenue_total_by_party(account).should == 
        event_catering_vendor_credit_after_subtotal_percentage.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total +
        event_catering_vendor_credit_after_subtotal_percentage.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_tax
    end

    it "calculate the expense sub-total"  do
      event_catering_vendor_credit_after_subtotal_percentage.expense_subtotal_by_party(vendor).should == 
        event_catering_vendor_credit_after_subtotal_percentage.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total
    end

    it "calculate the expense tax"  do
      event_catering_vendor_credit_after_subtotal_percentage.expense_general_tax_by_party(vendor).should == 
        event_catering_vendor_credit_after_subtotal_percentage.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_tax
    end

    it "calculate the expense after-subtotal items"  do
      event_catering_vendor_credit_after_subtotal_percentage.expense_after_subtotal_by_party(vendor).should ==
        event_catering_vendor_credit_after_subtotal_percentage.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Credit Memo"}.first.expense_total_with_percentage(
          event_catering_vendor_credit_after_subtotal_percentage.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total)
    end

    it "calculate the expense total"  do
      event_catering_vendor_credit_after_subtotal_percentage.expense_total_by_party(vendor).should == 
        event_catering_vendor_credit_after_subtotal_percentage.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total +
        event_catering_vendor_credit_after_subtotal_percentage.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_tax +
        event_catering_vendor_credit_after_subtotal_percentage.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Credit Memo"}.first.expense_total_with_percentage(
          event_catering_vendor_credit_after_subtotal_percentage.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total)
    end

    it "calculate the total of Menu-Fee revenue items" do
      event_catering_vendor_credit_after_subtotal_percentage.revenue_by_party_and_line_item_subtype(account, "Menu-Fee") == 
        event_catering_vendor_credit_after_subtotal_percentage.line_items.select{|li| li.billable_party == account && li.line_item_sub_type == "Menu-Fee"}.first.revenue_total
    end

    it "calculate the total of Menu-Fee expense items" do
      event_catering_vendor_credit_after_subtotal_percentage.revenue_by_party_and_line_item_subtype(vendor, "Menu-Fee") == 
        event_catering_vendor_credit_after_subtotal_percentage.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total
    end

    it "calculate the total of Credit Memo revenue items" do
      event_catering_vendor_credit_after_subtotal_percentage.revenue_by_party_and_line_item_subtype(account, "Credit Memo") == 0
    end

    it "calculate the total of Credit Memo expense items" do
      event_catering_vendor_credit_after_subtotal_percentage.revenue_by_party_and_line_item_subtype(vendor, "Credit Memo") == 
        event_catering_vendor_credit_after_subtotal_percentage.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Credit Memo"}.first.expense_total_with_percentage(
        event_catering_vendor_credit_after_subtotal_percentage.line_items.select{|li| li.payable_party == vendor && li.line_item_sub_type == "Menu-Fee"}.first.expense_total)
    end

  end
end