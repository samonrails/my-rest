# == Schema Information
#
# Table name: inventory_items_option_groups
#
#  inventory_item_id :integer
#  option_group_id   :integer
#  id                :integer          not null, primary key
#

require 'spec_helper'

describe "InventoryItemsOptionGroup" do
  let(:account) { create(:account) }
  let(:inventory_item) { create(:inventory_item) }
  let(:option_group) { create(:option_group) }
  let(:inventory_item_option) { create(
    :option_inventory_item,
    sell_price: 6,
    premium_sell_price: 5
  ) }
  let(:iiog) {
    InventoryItemsOptionGroup.create(
      inventory_item_id: inventory_item_option.id,
      option_group_id: option_group.id
    )
  }

  before do
    inventory_item.option_groups << option_group
  end

  describe "#select_pricing" do
    context "when the option group has included options" do
      it "returns sell price using the item premium price" do
        expect(iiog.select_pricing).to eq(Money.new(500))
      end
    end

    context "when the option group has no included options" do
      let(:option_group) { create(:option_group, included: 0) }

      it "returns sell price using the item cogs price" do
        expect(iiog.select_pricing).to eq(Money.new(600))
      end
    end
  end

end
