require 'spec_helper'

describe SelectEvent do
  let(:zip_code) { create(:zip_code, :with_tax_rate) }
  let(:address) { create(:address, zip_code: zip_code.zipcode) }
  let(:market) { create(:market, default_tax_rate: BigDecimal.new("10.5")) }
  let(:building) { create(:building, address: address, market: market) }

  # Select Event with 2 orders
  let(:vendor_1)          { FactoryGirl.create(:vendor) }
  let(:vendor_2)          { FactoryGirl.create(:vendor) }
  let(:select_event_vendor_1) { FactoryGirl.create(:select_event_vendor, select_event: select_event, vendor: vendor_1) }

  let(:select_event) { create(:select_event_with_locations, delivery_fee_payer: "account", tax_payer: "account", 
                              gratuity_payer: "user",  subsidy_fixed_amount_cents: 200, subsidy: "fixed_amount" ) }
  let(:select_order1) { create(:select_order, select_event: select_event, status: "checkout_complete")}
  let(:select_order2) { create(:select_order, select_event: select_event, status: "checkout_complete")}

  let(:inventory_item) { create(:inventory_item, sell_price_cents: 533) }

  let(:current_item1) { create(:select_order_item, quantity: 1, status: :current, vendor: vendor_1, inventory_item: inventory_item)}
  let(:current_item2) { create(:select_order_item, quantity: 1, status: :current, vendor: vendor_2, inventory_item: inventory_item)}
  
  

  # Add a 3 dollar line item to the account as well as a 2 dollar one
  let(:select_line_item1) { create(:select_line_item, select_event: select_event, unit_price_cents: 300, party_type: "account", party_id: select_event.account.id )}
  let(:select_line_item2) { create(:select_line_item, select_event: select_event, unit_price_cents: 200, party_type: "account", party_id: select_event.account.id )}

  # User transactions for each of the orders
  let(:select_order_transaction1) { create(:select_order_transaction, select_event: select_event, amount: 3, select_order: select_order1 )}
  let(:select_order_transaction2) { create(:select_order_transaction, select_event: select_event, amount: 3, select_order: select_order2 )}

  before do
    select_order1.select_order_items << current_item1
    select_order2.select_order_items << current_item2
    select_order1.save
    select_order2.save
    select_line_item1.save
    select_line_item2.save
    select_order_transaction1.save
    select_order_transaction2.save
    vendor_1.save
    select_event_vendor_1.save
  end
  
  
  before(:each) do
    if LineItemType.all.count == 0
      Fooda::Util::create_line_item_types
    end
  end

 
  describe "#tax_amount_account" do
    it "should calculate the tax to be returned to the account" do
      total_account_tax = select_order1.tax_amount_account
      expect(total_account_tax).to eq(Money.new(65))
    end
  end

  describe "#total_account_paid" do
    it "should bundle up the subsidy, delivery fee and gratuity to return to account" do
      total_account_pays = select_order1.total_account_paid
      expect(total_account_pays).to eq(Money.new(265))
    end
  end

  describe "#process_full_refund" do
    it "should increase the count of line items by 2 if fooda is at fault" do
      expect do
        select_order1.process_full_refund({party_at_fault_type: "fooda"})
      end.to change(select_event.select_line_items, :count).by(2)
    end

    it "should increase the count of line items by 2 if vendor1 is at fault" do
      expect do
        select_order1.process_full_refund({full_refund_party_type_fault: "all_vendors", full_refund_party_id_at_fault: vendor_1.id })
      end.to change(select_event.select_line_items.where(:party_type => "vendor"), :count).by(1)
    end
  end


end
