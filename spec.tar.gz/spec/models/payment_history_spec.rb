# == Schema Information
#
# Table name: payment_histories
#
#  id               :integer          not null, primary key
#  event_id         :integer
#  transaction_id   :string(255)
#  cc_last4         :string(255)
#  customer_id      :string(255)
#  status           :string(255)
#  amount           :float
#  transaction_type :string(255)
#  timestamp        :datetime
#  created_at       :datetime         not null
#  updated_at       :datetime         not null
#  user_id          :integer
#  is_latest        :boolean
#  card_type        :string(255)
#  nickname         :string(255)
#  exp_date         :string(255)
#

require 'spec_helper'

describe PaymentHistory do
  
  let (:payment_history){ create(:payment_history) }

  def create_transaction
    @payment_history = payment_history
    @user = @payment_history.user
    card_result = Braintree::Customer.create( email: @user.email, first_name: @user.first_name, last_name: @user.last_name )
    braintree_id = card_result.customer.id if card_result.success?
    parameters = {}
    parameters[:card] = {"cardholder_name"=>"Fooda", "number"=>"5555555555554444", "cvv"=>"123", "expiration_month"=>"3", "expiration_year"=>"2016", "billing_address"=>{"street_address"=>"", "extended_address"=>"", "locality"=>"", "region"=>"", "postal_code"=>"", "country_name"=>"United States"}}
    parameters[:card][:options] = {}
    parameters[:card].merge!(customer_id: braintree_id)[:options].merge!(verify_card: true)
    @card = Braintree::CreditCard.create(parameters[:card])
    trans_result = Braintree::Transaction.sale(amount: @payment_history.amount, payment_method_token: @card.credit_card.token, 
                                               options: {submit_for_settlement: [true, false].sample}, order_id: @payment_history.event.id)
  end
  
  it "should be valid" do
    payment_history.should be_valid
  end
  
  it "should belong to User" do
    payment_history.should belong_to(:user)
  end
  
  it "should belong to Event" do
    payment_history.should belong_to(:event)
  end
  
  it 'should update payment history or record errors' do
    result = create_transaction
    transaction = result.transaction
     if result.success?
       assert_difference 'EventTransaction.count', +1 do
         PaymentHistory.update_history(@payment_history.event, transaction, @user)
       end
     else
       assert_difference 'Issue.count', +1 do
         PaymentHistory.record_errors(@payment_history.event, result.errors, @user, transaction.id, @card.credit_card.token)
       end
     end
  end

end