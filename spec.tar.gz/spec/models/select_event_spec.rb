# == Schema Information
#
# Table name: select_events
#
#  id                                        :integer          not null, primary key
#  ready_and_bagged                          :integer          not null
#  delivery_time                             :datetime
#  delivery_time_utc                         :datetime
#  ordering_window_start_time                :datetime
#  ordering_window_end_time                  :datetime
#  ordering_window_start_time_utc            :datetime
#  ordering_window_end_time_utc              :datetime
#  created_by_id                             :integer
#  deleted_by_id                             :integer
#  created_at                                :datetime         not null
#  updated_at                                :datetime         not null
#  deleted_at                                :datetime
#  gratuity_payer                            :string(255)      default("user")
#  default_gratuity                          :decimal(, )      default(10.0)
#  delivery_fee_payer                        :string(255)      default("user")
#  tax_payer                                 :string(255)      default("user")
#  subsidy                                   :string(255)      default("none")
#  is_subsidy_percentage_capped              :boolean          default(FALSE)
#  subsidy_percentage_cap                    :decimal(, )
#  subsidy_percentage_fixed_amount_cap_cents :integer
#  subsidy_fixed_amount_cents                :integer
#  hide_gratuity_from_site                   :boolean          default(FALSE)
#  hide_delivery_fee_from_site               :boolean          default(FALSE)
#  hide_tax_from_site                        :boolean          default(FALSE)
#  account_id                                :integer
#  contact_id                                :integer
#  meal_period                               :string(255)
#  event_owner_id                            :integer
#  status                                    :string(255)
#  email_list_id                             :string(255)
#  introduction_email_time                   :datetime
#  final_email_time                          :datetime
#  introduction_email_campaign_id            :integer
#  final_email_campaign_id                   :integer
#  user_contribution_required                :boolean          default(FALSE)
#  user_contribution_cents                   :integer
#  introduction_email_time_utc               :datetime
#  final_email_time_utc                      :datetime
#  delivery_fee_fixed_amount_cents           :integer
#  campaign_scheduled                        :boolean          default(FALSE)
#  delivery_group_id                         :integer
#  fooda_internal_notes                      :text
#  published                                 :boolean          default(TRUE)
#  featured_vendor_id                        :integer
#  select_event_schedule_id                  :integer
#  settlement_job                            :string(255)
#  is_delivery_fee_flat_amount               :boolean          default(FALSE)
#  is_subsidy_promotion                      :boolean          default(FALSE), not null
#  event_transaction_method_id               :integer
#

require 'spec_helper'

describe SelectEvent do
  let(:select_event) { build(:select_event_with_locations, subsidy: "percentage") }

  describe "before create" do
    it "should run the proper callbacks" do
      expect(select_event).to receive(:conditionally_assign_delivery_group)
      select_event.save
    end
  end

  describe "after_save" do
    it "should queue a closer worker job" do
      expect{select_event.save}.to change(SelectEventCloser.jobs, :size).by(1)
    end
  end

  describe "#destroy" do
    it "should not be destroyable unless the status is auto-generated" do
      expect{select_event.destroy}.not_to change{SelectEvent.count}
    end
    it "should be destroyable if the status is auto_generated" do
      select_event.update_attributes(status: Status::Event.auto_generated)
      expect{select_event.destroy}.to change{SelectEvent.count}.by(-1)
    end
  end

  describe "validations" do
    describe "#ordering_window_end_time_before_delivery_offset" do
      it "does not allow an ordering window end time before delivery + ready and bagged" do
        select_event.ordering_window_end_time = select_event.delivery_time + 10
        expect(select_event).not_to be_valid
      end
    end
    describe "#ordering_window_start_time" do
      it "does not allow the ordering window start time to be past the end time" do
        select_event.ordering_window_start_time = select_event.ordering_window_end_time + 5
        expect(select_event).not_to be_valid
      end
    end
  end

  describe "ordering window logic" do
    let!(:past_select_event) {create(:select_event_with_locations,
                                   delivery_time: 1.day.ago,
                                   ready_and_bagged: 50,
                                   ordering_window_start_time: 3.days.ago,
                                   ordering_window_end_time: 2.days.ago)}
    let!(:future_select_event) {create(:select_event_with_locations,
                                      delivery_time: 3.days.from_now,
                                      ready_and_bagged: 50,
                                      ordering_window_start_time: 1.day.from_now,
                                      ordering_window_end_time: 2.days.from_now)}
    describe "scope ordering_window_future" do
      it "does not contain past select_events" do
        expect(SelectEvent.ordering_window_future).not_to include(past_select_event)
      end
      it "does contain future select_events" do
        expect(SelectEvent.ordering_window_future).to include(future_select_event)
      end
    end
    describe "scope ordering_window_ended" do
      it "does not include future events" do
        expect(SelectEvent.ordering_window_ended).not_to include(future_select_event)
      end
      it "does contain past events" do
        expect(SelectEvent.ordering_window_ended).to include(past_select_event)
      end
    end
    describe "scope within_ordering_window" do
      it "contains select_events within the ordering window" do
        Delorean.time_travel_to "36 hours from now" do
          expect(SelectEvent.within_ordering_window).to include(future_select_event)
        end
      end
    end
    describe "#within_ordering_window?" do
      it "is true if we're within the ordering window" do
        Delorean.time_travel_to "36 hours from now" do
          expect(future_select_event.within_ordering_window?).to be_true
        end
      end
      it "is false outside the ordering window" do
        expect(future_select_event.within_ordering_window?).to be_false
      end
    end
    describe "#ordering_window_in_future?" do
      it "is not true for events in the current window" do
        Delorean.time_travel_to "36 hours from now" do
          expect(future_select_event.ordering_window_in_future?).not_to be_true
        end
      end
      it "is true if the ordering window is in the future" do
        expect(future_select_event.ordering_window_in_future?).to be_true
      end
    end
    describe "#ordering_window_in_past?" do
      it "is not true for events in the current window" do
        Delorean.time_travel_to "36 hours from now" do
          expect(future_select_event.ordering_window_in_past?).not_to be_true
        end
      end
      it "is true if the ordering window is in the past" do
        expect(past_select_event.ordering_window_in_past?).to be_true
      end
    end
  end

  describe "#conditionally_assign_delivery_group" do
    let(:delivery_group) { create(:delivery_group) }

    # 29-Apr-14: This test is deprecated! We always need to have at least
    # 1 Delivery Group for the Event (Event belongsTo Delivery Group)
    # It needs to be mandatory because the Manifest depends on this
    # context "when the select event belongs to 0 delivery groups" do
    #   it "does not assign a delivery group" do
    #     select_event.save
    #     expect(select_event.delivery_group).to be_nil
    #   end
    # end

    context "when the select event belongs to 1 delivery group" do
      let(:select_event) { build(:select_event, :with_location_delivery_group) }

      it "assigns a delivery group" do
        pending "testing the after_create hook on a linked table's properties is kinda imposible. notes in the test"
        # You need to save the select event in order to get a primary id for the select_event_location linking table. 
        # You also need to have these locations set before the initial create because the after_create hook expects
        # them to be there. Ugh.
        select_event.save
        expect(select_event.delivery_group).to eq(delivery_group)
      end
    end

    # 29-Apr-14: This test is deprecated! We always need to have at least
    # 1 Delivery Group for the Event (Event belongsTo Delivery Group)
    # It needs to be mandatory because the Manifest depends on this
    # context "when the select event belongs to >1  delivery groups" do
    #   it "does not assign a delivery group" do
    #     select_event.save
    #     expect(select_event.delivery_group).to be_nil
    #   end
    # end
  end

  describe "#tax_rate" do
    let(:select_event){FactoryGirl.create(:select_event, :with_location_zip_code_tax)}

    context "when the select event's zip code has a tax rate" do
      it "uses the zipcode tax rate" do
        expect(select_event.tax_rate).to eq(BigDecimal.new("9.5"))
      end
    end

    context "when the select event's zip code does not have a tax rate" do
      before { select_event.building.address.zipcode.update_attributes(tax_rate: nil) }

      it "uses the market's default tax rate" do
        expect(select_event.tax_rate).to eq(BigDecimal.new("12.12"))
      end
    end
  end

  describe "finding best sellers" do
    let(:item1){ create(:inventory_item, id: 3) }
    let(:item2){ create(:inventory_item, id: 2) }
    let(:select_event_menu_group){ create(:select_event_menu_group) }
    let(:select_event_menu_item1){ create(:select_event_menu_item, inventory_item: item1, id: 10) }
    let(:select_event_menu_item2){ create(:select_event_menu_item, inventory_item: item2, id: 20) }
    let(:select_event_vendor){ create(:select_event_vendor, vendor: vendor) }
    let(:select_order){ create(:select_order) }
    let(:select_order_item){ create(:select_order_item) }
    let(:vendor){ create(:vendor) }
    let(:select_event){ create(:select_event_with_locations) }

    before do
      select_event_menu_group.select_event_menu_items << select_event_menu_item1
      select_event_menu_group.select_event_menu_items << select_event_menu_item2
      select_event_vendor.select_event_menu_groups << select_event_menu_group
      select_event.select_event_vendors << select_event_vendor

    end

    it "knows how to find the best sellers" do
      SoldCount.increment!(item1)
      SoldCount.increment!(item1)
      SoldCount.increment!(item1)
      SoldCount.increment!(item2)
      SoldCount.increment!(item2)
      expect(select_event.best_sellers).to eq [select_event_menu_item1, select_event_menu_item2]
    end
  end

  describe "finding all order information about a select event" do
    let(:item1){ create(:inventory_item, id: 3) }
    let(:item2){ create(:inventory_item, id: 2) }
    let(:select_event_vendor){ create(:select_event_vendor, vendor: vendor) }
    let!(:select_order){ create(:select_order, select_event: select_event, :status => "checkout_complete") }
    let!(:select_order_item1){ create(:select_order_item, select_order: select_order, inventory_item: item1, status: "current") }
    let!(:select_order_item2){ create(:select_order_item, select_order: select_order, inventory_item: item2, status: "current") }
    let(:vendor){ create(:vendor) }
    let(:select_event){ create(:select_event_with_locations) }

    before do
      select_event.select_event_vendors << select_event_vendor
    end

    it "finds the select event with the order information" do
      expect(select_event.complete_select_orders_information.id).to eql (select_event.id)
    end

    it "finds the correct order item count in the select order" do
      expect(select_event.complete_select_orders_with_item_counts[select_order.id]).to eql (2)
    end
  end


  it "knows if there is a subsidy" do
    expect(select_event.subsidy?).to be_true
  end

  it "knows if user pays delivery" do
    select_event.delivery_fee_payer = "user"
    expect(select_event.user_pays_delivery_fee?).to be_true
  end

  it "knows if user pays gratuity" do
    select_event.gratuity_payer = "account"
    expect(select_event.user_pays_gratuity?).to be_false
  end

  it "knows if user pays tax" do
    select_event.tax_payer = "user"
    expect(select_event.user_pays_tax?).to be_true
  end

  describe "overriding ID" do
    let(:select_event1){ create(:select_event) }
    let(:select_event2){ create(:select_event) }

    it "knows how to find a single prefixed id" do
      expect(SelectEvent.find(select_event1)).to eq(select_event1)
    end

    it "knows how to find multiple prefixed ids" do
      ids = [select_event1.to_param, select_event2.to_param]
      expect(SelectEvent.find(ids).to_a).to eq([select_event1, select_event2])
    end

    it "knows how to find a single id" do
      expect(SelectEvent.find(select_event1.id)).to eq(select_event1)
    end

    it "knows how to find multiple ids" do
      ids = [select_event1.id, select_event2.id]
      expect(SelectEvent.find(ids).to_a).to eq([select_event1, select_event2])
    end

    it "knows how to handle mixed ids" do
      ids = [select_event1.to_param, select_event2.id]
      expect(SelectEvent.find(ids.to_a)).to eq([select_event1, select_event2])
    end

  end

end
