# == Schema Information
#
# Table name: option_groups
#
#  id                :integer          not null, primary key
#  name              :string(255)
#  included          :integer
#  max               :integer
#  inventory_item_id :integer
#  required          :integer
#

require 'spec_helper'

describe OptionGroup do
  let (:option_group) { create(:option_group) }

  it "should be valid" do
    option_group.should be_valid
  end

  describe "when options are not included" do
    before do
      option_group.update_attributes(included: 0)
    end

    context "when # required is greater than # included" do
      it "is valid" do
        option_group.update_attributes(required: 1)
        expect(option_group).to be_valid
      end
    end

    context "when # required is equal to # included" do
      it "is valid" do
        option_group.update_attributes(required: 0)
        expect(option_group).to be_valid
      end
    end
  end

  describe "when options are included" do
    context "when # required is greater than # included" do
      it "is not valid" do
        option_group.update_attributes(required: 2)
        expect(option_group).not_to be_valid
      end
    end

    context "when # required is less than or equal to # included" do
      it "is valid" do
        option_group.update_attributes(required: 1)
        expect(option_group).to be_valid
      end
    end
  end
end
