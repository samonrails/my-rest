# == Schema Information
#
# Table name: delivery_groups_locations
#
#  id                :integer          not null, primary key
#  delivery_group_id :integer
#  location_id       :integer
#  position          :integer
#

require 'spec_helper'

describe "DeliveryGroupsLocation" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
