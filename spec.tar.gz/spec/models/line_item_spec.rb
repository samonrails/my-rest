# == Schema Information
#
# Table name: line_items
#
#  id                              :integer          not null, primary key
#  line_item_type                  :string(255)
#  sku                             :string(255)
#  name                            :string(255)
#  notes                           :text
#  quantity                        :integer
#  include_price_in_expense        :boolean
#  include_price_in_revenue        :boolean
#  event_id                        :integer
#  inventory_item_id               :integer
#  billable_party_type             :string(255)
#  billable_party_id               :integer
#  payable_party_type              :string(255)
#  payable_party_id                :integer
#  tax_rate_expense                :decimal(, )
#  tax_rate_revenue                :decimal(, )
#  line_item_sub_type              :string(255)
#  after_subtotal                  :boolean
#  percentage_of_subtotal          :boolean
#  document_id                     :integer
#  unit_price_expense_cents        :integer
#  unit_price_revenue_cents        :integer
#  parent_id                       :integer
#  menu_template_id                :integer
#  tax_rate_default_locked_expense :boolean          default(FALSE), not null
#  tax_rate_default_locked_revenue :boolean          default(FALSE), not null
#  add_on_parent_id                :integer
#  opposing_line_item_id           :integer
#

require 'spec_helper'

describe LineItem do
  let (:vendor){ create(:vendor) }
  # let (:account){ create(:account) }
  # let(:zip_code) { create(:zip_code) }
  # let(:address) { create(:address, zip_code: zip_code.zipcode) }
  let(:building) { create(:building, :with_zip_code_tax) }
  let(:user) { create(:user) }
  let(:location) { create(:location, building: building) }
  let(:event) { create(:event, location: location) }
  let(:line_item) { create(:line_item, event: event) }
  let(:line_item_a) do
    event.line_items.create!(
        :line_item_type => "Financial",
        :line_item_sub_type => "Credit Memo",
        :sku => 500,
        :name => "newitem",
        :notes => "Do some stuff",
        :quantity => 0,
        :include_price_in_expense => true,
        :include_price_in_revenue => true,
        :billable_party_type => "Account",
        :billable_party_id => event.account.id,
        :unit_price_revenue => 45.15,
        :unit_price_expense => 15.25,
        :tax_rate_expense => 10.00,
        :tax_rate_revenue => 15.05)
  end

  it "should belong to Payable Party" do
    line_item.should belong_to(:payable_party)
  end

  it "should belong to Billable Party" do
    line_item.should belong_to(:billable_party)
  end

  context "payable party" do
    it "should be polymorphic 1" do
      line_item.payable_party = vendor;
      line_item.payable_party_id.should == vendor.id;
    end
    it "should be polymorphic 2" do
      line_item.payable_party = vendor;
      line_item.payable_party_type.should == vendor.class.name
    end
  end

  context "billable party" do
    it "should be polymorphic 1" do
      line_item.billable_party = location.account;
      line_item.billable_party_id.should == location.account.id;
    end
    it "should be polymorphic 2" do
      line_item.billable_party = location.account;
      line_item.billable_party_type.should == location.account.class.name
    end
  end

  it "should be valid" do
    line_item.should be_valid
  end

  describe "sku_display" do
    it "should display sku" do
      line_item.sku_display.should == "#{line_item.sku}"
    end
  end

  describe "name_display" do
    it "should display name" do
      line_item.name_display.should == "#{line_item.name}"
    end
  end

  describe "name_display_condensed" do
    it "should display name condensed" do
      line_item.name_display_condensed.should == "#{line_item.name}"
    end
  end

  describe "name_with_links_display" do
    it "should display name with link" do
      line_item.name_with_links_display.should == "<a class='pointer toggle-modal' data-target='#edit_line_item_form_#{line_item.id.to_s}'>#{line_item.name}</a>"
    end
  end

  describe "quantity_display" do
    it "should display quantity" do
      line_item.quantity_display.should == "8"
    end

    it "should display quantity if 0" do
      line_item_a.quantity_display.should == "-"
    end
  end

  describe "unit_price_expense_display" do
    it "should display unit_price_expense" do
      line_item_a.unit_price_expense_display.should == "$15.25"
    end

    it "should display unit_price_expense" do
      line_item_a.unit_price_expense_display(true).should == "-$15.25"
    end

    it "should not display unit_price_expense if false" do
      line_item.unit_price_expense_display.should == "-"
    end
  end

  describe "unit_price_revenue_display" do
    it "should display unit_price_revenue" do
      line_item_a.unit_price_revenue_display.should == "$45.15"
    end

    it "should display unit_price_revenue" do
      line_item_a.unit_price_revenue_display(true).should == "-$45.15"
    end

    it "should not display unit_price_revenue if false" do
      line_item.unit_price_revenue_display.should == "-"
    end
  end

  describe "tax_rate_expense_display" do
    it "should display tax_rate_expense" do
      line_item_a.tax_rate_expense_display.should == "10.00"
    end

    it "should not display tax_rate_revenue if false" do
      line_item.tax_rate_expense_display.should == "-"
    end
  end

  describe "tax_rate_revenue_display" do
    it "should display tax_rate_revenue" do
      line_item_a.tax_rate_revenue_display.should == "15.05"
    end

    it "should not display tax_rate_revenue_display if false" do
      line_item.tax_rate_revenue_display.should == "-"
    end
  end

  describe "pretty_id" do
    it "should display tax_rate_revenue" do
      line_item_a.pretty_id.should == "#{line_item_a.id.to_s.rjust(7, "0")}"
    end
  end

  describe "required_options_satisfied" do
    it "should return true if inventory_item_id is nil" do
      line_item_a.required_options_satisfied.should == true
    end
  end

  describe "#default_tax_rate" do

    context "when the event's location does not have a zipcode tax rate" do
      let(:building2) { create(:building, :with_zip_code) }
      let(:location2) { create(:location, building: building2) }
      let(:event2) { create(:event, location: location2) }
      let(:line_item2) { create(:line_item, event: event2) }

      it "uses the market's default tax rate" do
        expect(line_item2.default_tax_rate).to eq(BigDecimal.new("12.12"))
      end
    end

    context "when the event's location has a zipcode tax rate" do
      it "uses the zipcode tax rate" do
        expect(line_item.default_tax_rate).to eq(BigDecimal.new("9.5"))
      end
    end
  end
end
