require "spec_helper"

describe Checkout::RecommendationEngine do

  let(:user){ create(:user) }
  let(:select_event){ create(:select_event_with_locations) }

  let(:inventory_item1){ create(:inventory_item) }
  let(:inventory_item2){ create(:inventory_item) }
  let(:inventory_item3){ create(:inventory_item) }

  let(:select_event_menu_group1){ create(:select_event_menu_group) }
  let(:select_event_menu_group2){ create(:select_event_menu_group) }
  let(:select_event_menu_group3){ create(:select_event_menu_group) }

  let(:select_event_menu_item1){ create(:select_event_menu_item) }
  let(:select_event_menu_item2){ create(:select_event_menu_item) }
  let(:select_event_menu_item3){ create(:select_event_menu_item) }

  let(:select_event_vendor1){ create(:select_event_vendor) }
  let(:select_event_vendor2){ create(:select_event_vendor) }
  let(:select_event_vendor3){ create(:select_event_vendor) }

  let(:select_order1){ create(:select_order) }
  let(:select_order2){ create(:select_order) }

  let(:select_order_item1){ create(:select_order_item) }
  let(:select_order_item2){ create(:select_order_item) }

  let(:vendor1){ create(:vendor) }
  let(:vendor2){ create(:vendor) }
  let(:vendor3){ create(:vendor) }

  let(:engine){ Checkout::RecommendationEngine.new(user, select_event) }

  def setup_first_order
    select_event_menu_item1.inventory_item = inventory_item1
    select_event_menu_group1.select_event_menu_items << select_event_menu_item1
    select_event_vendor1.select_event_menu_groups << select_event_menu_group1
    select_event_vendor1.vendor = vendor1
    select_event.select_event_vendors << select_event_vendor1
    select_order1.select_event = select_event
    select_order_item1.inventory_item = inventory_item1
    select_order1.select_order_items << select_order_item1
    user.select_orders << select_order1
  end

  def setup_second_order
    select_event_menu_item2.inventory_item = inventory_item2
    select_event_menu_group2.select_event_menu_items << select_event_menu_item2
    select_event_vendor2.select_event_menu_groups << select_event_menu_group2
    select_event_vendor2.vendor = vendor2
    select_event.select_event_vendors << select_event_vendor2
    select_order2.select_event = select_event
    select_order_item2.inventory_item = inventory_item2
    select_order2.select_order_items << select_order_item2
    user.select_orders << select_order2
  end

  def setup_third_order
    select_event_menu_item3.inventory_item = inventory_item3
    select_event_menu_group3.select_event_menu_items << select_event_menu_item3
    select_event_vendor3.select_event_menu_groups << select_event_menu_group3
    select_event_vendor3.vendor = vendor3
    select_event.select_event_vendors << select_event_vendor3
  end

  before do
    setup_first_order
    setup_second_order
    setup_third_order
  end

  it "has a user" do
    expect(engine.user).to eq(user)
  end

  it "has a select_event" do
    expect(engine.select_event).to eq(select_event)
  end

  it "knows how to get previously ordered and available items" do
    expect(engine.items).to include(select_event_menu_item1, select_event_menu_item2, select_event_menu_item3)
  end

  it "returns correct number of items" do
    expect(engine.items.size).to eq(3)
  end

end
