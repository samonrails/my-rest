# == Schema Information
#
# Table name: checkout_carts
#
#  id         :integer          not null, primary key
#  user_id    :integer
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  token      :string(255)
#

require "spec_helper"

describe Checkout::Cart do
  let(:user){ FactoryGirl.create(:user) }
  let(:cart){ user.cart }
  let(:inventory_item){ FactoryGirl.create(:inventory_item) }
  let(:select_event){ FactoryGirl.create(:select_event_with_locations) }
  let(:anon_cart){ Checkout::Cart.create }

  before do
    cart.add!(select_event, inventory_item)
  end

  it "knows if it is anonymous" do
    expect(cart.anonymous?).to be_false
  end

  it "knows about items it contains" do
    expect(cart.items).to eq([inventory_item])
  end

  it "knows about checkout::items it contains" do
    expect(cart.checkout_items).to eq([cart.selections.first.items.first])
  end

  it "knows when it is empty" do
    expect(cart.is_empty?).to be_false
  end

  it "knows how to clear its self" do
    cart.clear!
    expect(cart.is_empty?).to be_true
  end

  it "knows how to get all selections" do
    expect(cart.selections.size).to eq(1)
  end

  it "knows how to remove an item" do
    item = cart.selection_for(select_event).items.first
    cart.remove!(select_event, item)
    expect(cart.items.size).to eq(0)
  end

  it "knows how to add items" do
    cart.add!(select_event, inventory_item)
    expect(cart.items.size).to eq(2)
  end

  it "knows how to add items via a hash" do
    cart.add_via_hash!({
      parent_id: select_event.id,
      parent_type: "SelectEvent",
      item_id: inventory_item.id,
      item_type: "InventoryItem"
    })

    expect(cart.items.size).to eq(2)
  end

  context "when owned by a user" do
    let(:cart){ user.cart }

    it "has a user" do
      expect(cart.user).to be_present
    end

    it "does not have a token" do
      expect(cart.token).to_not be_present
    end

  end

  context "when anonymous" do
    let(:cart){ Checkout::Cart.create }
    let(:token){ cart.token }

    it "has a token" do
      expect(cart.token).to be_present
    end

    it "does not have a user" do
      expect(cart.user).to_not be_present
    end

    it "knows how to clear old anonymous unclaimed carts" do
      expect{ Checkout::Cart.clear_old_anon_carts! }.to_not change(Checkout::Cart, :count)
      cart.update_attribute(:created_at, 3.months.ago)
      expect{ Checkout::Cart.clear_old_anon_carts! }.to change(Checkout::Cart, :count).by(-1)
    end

    context "and being claimed" do
      before do
        user && cart && anon_cart # Preload
      end

      it "merges any items from the claimed cart" do
        anon_cart.add!(select_event, inventory_item)
        expect(cart.items.size).to eq(1)
        expect(anon_cart.items.size).to eq(1)
        cart.merge!(anon_cart)
        cart.reload
        expect(cart.items.size).to eq(2)
      end

      it "deletes the claimed cart" do
        expect{ cart.merge!(anon_cart) }.to change(Checkout::Cart, :count).by(-1)
      end
    end
  end
end
