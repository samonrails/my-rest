# == Schema Information
#
# Table name: checkout_selection_items
#
#  id             :integer          not null, primary key
#  selection_id   :integer
#  selection_type :string(255)
#  item_id        :integer
#  item_type      :string(255)
#  options        :text
#  instructions   :text
#  side_options   :text
#

require "spec_helper"

describe Checkout::Selections::Item do
  let(:user){ FactoryGirl.create(:user) }
  let(:cart){ user.cart }
  let(:inventory_item){ FactoryGirl.create(:inventory_item) }
  let(:option_group){ FactoryGirl.create(:option_group) }
  let(:inventory_item_option){ FactoryGirl.create(:option_inventory_item) }
  let(:inventory_items_option_group){
    InventoryItemsOptionGroup.create(
      inventory_item_id: inventory_item_option.id,
      option_group_id: option_group.id
    )
  }
  let(:select_event){ FactoryGirl.create(:select_event) }
  let(:ses){ Checkout::Selections::SelectEvent.create(select_event_id: select_event.id) }
  let(:co_item){ Checkout::Selections::Item.create({
      selection_type: "SelectEvent",
      selection_id: select_event.id,
      item_type: "InventoryItem",
      item_id: inventory_item.id
    })
  }

  before do
    ses.items << co_item
    user.cart.selections << ses
  end

  it "has an item" do
    expect(co_item.inventory_item).to eq(inventory_item)
  end

  it "belongs to a selection" do
    expect(co_item.selection).to eq(select_event)
  end

  describe "#type_of_item" do
    it "doesn't allow odd items" do
      co_item.item_type = "Something"
      expect(co_item).to_not be_valid
    end
  end

  describe "#required_options" do
    it "doesn't allow items that don't meet all option groups requirements" do
      option_group.update_attributes(required: 1)
      co_item.inventory_item.option_groups << option_group
      expect(co_item).to_not be_valid
    end
  end

  describe "#all_option_ids" do
    context "when the item has no options or side options selected" do
      it "returns an empty set" do
        expect(co_item.send(:all_option_ids)).to eq([])
      end
    end

    context "when the item has options and side options selected" do
      it "returns the combined set of option ids" do
        co_item.update_attributes(options: [1, 2, 3], side_options: [4, 5, 6])
        expect(co_item.send(:all_option_ids)).to eq([1, 2, 3, 4, 5, 6])
      end
    end
  end

  describe "#options_selected_for" do
    context "when the item has no selected options for the option group" do
      it "returns an empty set" do
        expect(co_item.send(:options_selected_for, option_group)).to eq([])
      end
    end

    context "when the item has selected options for the option group" do
      it "returns the set of selected options" do
        co_item.update_attributes(options: [inventory_items_option_group.id])
        expect(co_item.send(:options_selected_for, option_group)).to include(inventory_items_option_group)
      end
    end
  end

  describe "#options_meet_requirements_for?" do
    context "when the number of options selected is greater than or equal to the required number" do
      it "returns true" do
        co_item.update_attributes(options: [inventory_items_option_group.id])
        expect(co_item.send(:options_meet_requirements_for?, option_group)).to be_true
      end
    end

    context "when the number of options selected is less than the required number" do
      it "returns false" do
        option_group.update_attributes(required: 1)
        inventory_item.option_groups << option_group
        expect(co_item.send(:options_meet_requirements_for?, option_group)).to be_false
      end
    end
  end

  describe "#meets_all_option_groups_requirements?" do
    context "when option groups have no requirements" do
      it "returns true" do
        expect(co_item.send(:meets_all_option_groups_requirements?)).to be_true
      end
    end

    context "when option groups have requirements" do
      describe "when selected options meet all option group requirements" do
        it "returns true" do
          option_group.update_attributes(required: 1)
          co_item.inventory_item.option_groups << option_group
          co_item.update_attributes(options: [inventory_items_option_group.id])
          expect(co_item.send(:meets_all_option_groups_requirements?)).to be_true
        end
      end

      describe "when selected options meet some option group requirements" do
        it "returns false" do
          option_group.update_attributes(required: 2)
          co_item.inventory_item.option_groups << option_group
          co_item.update_attributes(options: [inventory_items_option_group.id])
          expect(co_item.send(:meets_all_option_groups_requirements?)).to be_false
        end
      end

      describe "when selected options meet no option group requirements" do
        it "returns false" do
          option_group.update_attributes(required: 1)
          co_item.inventory_item.option_groups << option_group
          expect(co_item.send(:meets_all_option_groups_requirements?)).to be_false
        end
      end
    end
  end

  context "when no options exist" do
    it "knows how to get option attributes" do
      expect(co_item.ingredient_option_attributes_for_order).to eq([])
    end
  end

  context "when options exist" do
    let(:iiog){ FactoryGirl.create(:inventory_items_option_group) }

    before do
      co_item.options << iiog.id
    end

    it "knows how to get option attributes" do
      attrs = iiog.attributes.except("id").symbolize_keys
      expect(co_item.ingredient_option_attributes_for_order).to eq([attrs])
    end
  end

end
