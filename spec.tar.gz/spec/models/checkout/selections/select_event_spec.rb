# == Schema Information
#
# Table name: checkout_selection_select_events
#
#  id              :integer          not null, primary key
#  cart_id         :integer
#  select_event_id :integer
#

require "spec_helper"

describe Checkout::Selections::SelectEvent do
  let(:user){ FactoryGirl.create(:user) }
  let(:cart){ user.cart }
  let(:item){ ses.items.first }
  let(:inventory_item){ FactoryGirl.create(
    :inventory_item,
    sell_price: 6,
    premium_sell_price: 5
  ) }
  let(:ingredient_option_group){ FactoryGirl.create(:option_group) }
  let(:side_option_group){ FactoryGirl.create(:option_group, included: 0) }
  let(:inventory_item_option){ FactoryGirl.create(
    :option_inventory_item,
    sell_price: 2,
    premium_sell_price: 1
  ) }
  let(:ingredient_inventory_items_option_group){
    InventoryItemsOptionGroup.create(
      inventory_item_id: inventory_item_option.id,
      option_group_id: ingredient_option_group.id
    )
  }
  let(:side_inventory_items_option_group){
    InventoryItemsOptionGroup.create(
      inventory_item_id: inventory_item_option.id,
      option_group_id: side_option_group.id
    )
  }
  let(:select_event){ FactoryGirl.create(:select_event_with_locations) }
  let(:ses){ Checkout::Selections::SelectEvent.create(select_event_id: select_event.id, cart_id: cart.id) }
  let(:options_params) {
    {
      options:
        [
          ingredient_inventory_items_option_group.id
        ],
      side_options:
        [
          side_inventory_items_option_group.id
        ]
    }
  }

  before do
    inventory_item.option_groups << ingredient_option_group
    inventory_item.option_groups << side_option_group
    user.cart.selections << ses
  end

  it "belongs to a cart" do
    expect(ses.cart).to be_present
  end

  it "belongs to a select_event" do
    expect(ses.select_event).to eq(select_event)
  end

  it "has a parent_object defined" do
    expect(ses.parent_object).to eq(select_event)
  end

  it "has items" do
    expect(ses.items.size).to eq(0)
  end

  it "knows how to add items" do
    expect{ user.add_to_cart(select_event, inventory_item); ses.reload }.to change(ses.items, :count).to(1)
  end

  it "knows how to add items from a hash" do
    hash = {item_id: inventory_item.id, item_type: "InventoryItem"}
    expect{ ses.add_via_hash!(hash); ses.reload }.to change(ses.items, :count).to(1)
  end

  it "knows how to remove an item" do
    user.add_to_cart(select_event, inventory_item)
    item = user.cart.selection_for(select_event).items.first
    expect{ ses.remove!(item) }.to change(ses.items, :count).to(0)
  end

  it "knows how to clear its self" do
    user.add_to_cart(select_event, inventory_item)
    expect{ ses.clear!; ses.reload }.to change(ses.items, :count).to(0)
  end

  it "knows if it is empty" do
    user.add_to_cart(select_event, inventory_item)
    expect(ses.is_empty?).to be_false
  end

  describe "money methods" do
    before do
      3.times{ user.add_to_cart(select_event, inventory_item, options_params) }
    end

    it "knows the subtotal of its items" do
      expect(ses.subtotal).to eq(Money.new(2700))
    end

    it "knows the delivery fee" do
      expect(ses.delivery_fee).to eq(select_event.delivery_fee_fixed_amount)
    end

    it "knows the gratuity" do
      expect(ses.gratuity).to eq(Money.new(270))
    end

    it "knows the promotion" do
      expect(ses.promotion).to eq(Money.new(0))
    end

    it "knows the tax amount" do
      expect(ses.tax).to eq(Money.new(360))
    end

    it "knows the total before the subsidy" do
      expect(ses.total_before_subsidy).to eq(Money.new(3395))
    end

    it "knows the subsidy" do
      expect(ses.subsidy).to eq(select_event.subsidy_fixed_amount_cents)
    end

    it "knows the total" do
      expect(ses.total).to eq(Money.new(3395))
    end

    it "knows the subsidy available" do
      expect(ses.subsidy_available).to eq(1)
    end

    it "knows the updated totals" do
      total_hash = {
        subtotal:     Money.new(2700),
        delivery_fee: Money.new(65),
        gratuity:     Money.new(540),
        promotion:    Money.new(0),
        tax:          Money.new(393),
        subsidy:      Money.new(0),
        total:        Money.new(3698)
      }
      expect(ses.updated_totals(20.0)).to eq(total_hash)
    end

    it "formats the totals" do
      formatted_hash = {
        subtotal:     "$27.00",
        delivery_fee: "$0.65",
        gratuity:     "$5.40",
        promotion:    "$0.00",
        tax:          "$3.93",
        subsidy:      "$0.00",
        total:        "$36.98"
      }
      expect(ses.json_totals(20.0)).to eq(formatted_hash)
    end

    describe "ordering" do
      let(:location){ create(:location) }
      let(:params){ {info: {location_id: location.id, gratuity_selected: 0.10}} }
      let(:order){ user.cart.order!(select_event, params) }

      it "knows how to place an order" do
        expect{ order }.to change(Select::SelectOrder, :count).by(1)
      end

      it "sets the order's status as 'checkout_copmlete'" do
        expect(order.status).to eq('checkout_complete')
      end

      it "has the right number of line items" do
        expect{ order }.to change(Select::SelectOrderItem, :count).by(6)
      end

      it "has the correct line items" do
        grouped_items = order.select_order_items.group_by { |soi| soi.inventory_item }
        expect(grouped_items[inventory_item].count).to eq(3)
        expect(grouped_items[inventory_item_option].count).to eq(3)
      end

      it "sets the line items as 'current'" do
        order.select_order_items.each do |soi|
          expect(soi.status).to eq("current")
        end
      end

      it "has the right number of options" do
        expect{ order }.to change(Select::SelectOrderItemOption, :count).by(3)
      end

    end
  end
end
