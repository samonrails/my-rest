require 'spec_helper'

describe Select::SelectManifest do

  #########################
  # Setup some basic vars #
  #########################

  let(:date) { DateTime.now.strftime("%Y-%m-%d") }
  let(:period) { "Lunch" }
  
  let(:select_event_1) do
    create(:select_event, :with_location_delivery_group, 
                          :with_bloated_vendor,
                          ordering_window_end_time_utc: 1.hour.from_now.utc)
  end

  let(:select_event_2) do
    create(:select_event, :with_location_delivery_group, 
                          :with_bloated_vendor,
                          ordering_window_end_time_utc: 1.hour.from_now.utc)
  end

  let(:user_1) { create(:user, :confirmed, accounts: [select_event_1.account]) }
  let(:user_2) { create(:user, :confirmed, accounts: [select_event_2.account]) }


  let (:select_order_1) do
    create(:select_order, select_event: select_event_1, 
                          user: user_1, 
                          location: select_event_1.location, 
                          status: :checkout_complete)
  end
  let (:select_order_item_1_1) do
    create(:select_order_item, inventory_item: select_event_1.vendors.last.menu_templates.last.inventory_items.first, 
                               vendor: select_event_1.vendors.last,
                               select_order: select_order_1,
                               special_instructions: 'Extra special sauce',
                               quantity: 1,
                               status: :current)
  end

  # Next Order from Event 2, also to Vendor 1
  let (:select_order_2) do
    create(:select_order, select_event: select_event_2,
                          user: user_2,
                          location: select_event_2.location,
                          status: :checkout_complete)
  end
  let (:select_order_item_2_1) do
    create(:select_order_item, inventory_item: select_event_1.vendors.last.menu_templates.last.inventory_items.first,
                               vendor: select_event_1.vendors.last,
                               select_order: select_order_2,
                               quantity: 1,
                               special_instructions: 'No garlic please',
                               status: :current)
  end
  let (:select_order_item_2_2) do
    create(:select_order_item, inventory_item: select_event_1.vendors.last.menu_templates.last.inventory_items.first,
                               vendor: select_event_1.vendors.last,
                               select_order: select_order_2,
                               quantity: 1,
                               special_instructions: 'Add extra stuff',
                               status: :current)
  end
  
  # At this point, both Events have Orders only for Vendor 1
  # Whereas Vendor 2 has NO orders from either event...

  ###################
  # Setup Manifests #
  ###################
  
  let (:select_manifest_1) do
    create(:select_manifest, vendor: select_event_1.vendors.last,
                             select_events: [select_event_1, select_event_2])
                           
  end
  let (:select_manifest_2) do
    create(:select_manifest, vendor: select_event_2.vendors.first,
                             select_events: [select_event_1, select_event_2])
  end

  ########################
  # Setup Data for tests #
  ########################

  before do
    select_event_2.vendors << select_event_1.vendors.last
    select_event_2.save

    # Setup Orders w/ Order Items
    select_order_1.select_order_items = [select_order_item_1_1]
    select_order_2.select_order_items = [select_order_item_2_1, select_order_item_2_2]    
  end

  context "manifest 1" do
    it "has events" do
      expect(select_manifest_1.select_events.count).to be > 0
    end

    it "has order items for first event" do
      expect(select_manifest_1.select_events.first.
                               select_orders.first.
                               select_order_items.
                               where(vendor_id: select_manifest_1.vendor_id).
                               count).to be > 0
    end

    it "has order items for second event" do
      expect(select_manifest_1.select_events.second.
                               select_orders.first.
                               select_order_items.
                               where(vendor_id: select_manifest_1.vendor_id).
                               count).to be > 0
    end
  end

  context "manifest 2" do
    it "has events" do
      expect(select_manifest_2.select_events.count).to be > 0
    end

    it "has no order items for first event" do
      expect(select_manifest_2.select_events.first.
                               select_orders.first.
                               select_order_items.
                               where(vendor_id: select_manifest_2.vendor_id).
                               count).to eq(0)
    end

    it "has no order items for second event" do
      expect(select_manifest_2.select_events.second.
                               select_orders.first.
                               select_order_items.
                               where(vendor_id: select_manifest_2.vendor_id).
                               count).to eq(0)
    end
  end

end
