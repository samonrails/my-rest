# == Schema Information
#
# Table name: select_event_vendor_notifications
#
#  id                     :integer          not null, primary key
#  select_event_vendor_id :integer
#  notification           :string(255)
#  user_id                :integer
#  state                  :string(255)
#  created_at             :datetime         not null
#  updated_at             :datetime         not null
#

require 'spec_helper'

describe "SelectEventVendorNotification" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
