# == Schema Information
#
# Table name: documents
#
#  id               :integer          not null, primary key
#  document_type    :string(255)
#  recipient        :string(255)
#  total            :string(255)
#  event_id         :integer
#  created_at       :datetime         not null
#  updated_at       :datetime         not null
#  status           :string(255)
#  name             :string(255)
#  full_file_name   :string(255)
#  creator_id       :integer
#  voucher_group_id :integer
#

require 'spec_helper'

describe "Document" do

  let(:event){create(:event)}
  let(:user){create(:user)}
  let(:event_vendor){create(:event_vendor)}
  
  let(:document_account_type) do
    event
    doc_type = %w(quote invoice invoice_summary).sample
    account_name = event.account.name
    document = Document.create( :document_type => doc_type,
                                :recipient =>     account_name,
                                :total =>        "0",
                                :event_id =>      event.id,
                                :status =>        "requested",
                                :name =>          "requested",
                                :creator_id =>    user.id )
    document
  end

  let(:document_vendor_type) do
    event_vendor
    doc_type = %w(purchase_order packing_slip).sample
    vendor_name = event_vendor.vendor.name
    document = Document.create( :document_type => doc_type,
                                :recipient =>     vendor_name,
                                :total =>        "0",
                                :event_id =>      event_vendor.event.id,
                                :status =>        "requested",
                                :name =>          "requested",
                                :creator_id =>    user.id )
    document
  end

  describe "create event document" do
    it "should create account type document" do
      test_event = Event.find(document_account_type.event_id)
      options = {"doc_type" => document_account_type.document_type, "party" => test_event.account.id, "party_type" => "Account", "id" => test_event.id, "current_user" => document_account_type.creator_id, "document_id" => document_account_type.id}
      result = Document.create_event_document(options)
      expect(result).to eq true
    end

    it "should create vendor document" do
      test_event = Event.find(document_vendor_type.event_id)
      options = {"doc_type" => document_vendor_type.document_type, "party" => test_event.vendors.first.id, "party_type" => "Vendor", "id" => test_event.id, "current_user" => document_vendor_type.creator_id, "document_id" => document_vendor_type.id}
      result = Document.create_event_document(options)
      expect(result).to eq true
    end
  end

  describe "create_vendor_billing_summary_document" do
    it "should create vendor billing summary document" do
      options = {"date" => Date.today, "event_vendor_list" => [event_vendor]}
      result = Document.create_vendor_billing_summary_document(options)
      expect(result["document_name"]).to eq "vendor_billing_summaries/Vendor-Billing-Summary-#{event_vendor.vendor.id.to_s.rjust(6, "0")}-#{Date.today.strftime('%Y%m%d')}.pdf"
    end
  end

end
