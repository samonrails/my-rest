# == Schema Information
#
# Table name: sold_counts
#
#  id                 :integer          not null, primary key
#  target_object_type :string(255)
#  target_object_id   :integer
#  amount             :integer          default(0)
#

require "spec_helper"

describe SoldCount do

  let(:item){ create(:inventory_item) }
  let(:item2){ create(:inventory_item) }

  it "knows how to increment a count" do
    expect{ SoldCount.increment!(item) }.to change{ SoldCount.for(item) }.to(1)
  end

  it "knows how to decrement a count" do
    SoldCount.increment!(item)
    expect{ SoldCount.decrement!(item) }.to change{ SoldCount.for(item) }.to(0)
  end

  it "knows how to get the current count" do
    expect(SoldCount.for(item)).to eq(0)
    SoldCount.increment!(item)
    expect(SoldCount.for(item)).to eq(1)
  end

end
