require 'spec_helper'

describe Select::SelectOrderTransaction do

  it "is tested in the select order model (un-strict sanity checks and transaction creation)" do
    true
  end

end
