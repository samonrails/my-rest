# == Schema Information
#
# Table name: zip_codes
#
#  id         :integer          not null, primary key
#  zipcode    :string(255)
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  tax_rate   :decimal(, )
#  market_id  :integer
#

require 'spec_helper'


describe ZipCode do
  describe ".parse_zipcode_data" do
    context "with zipcode information" do
      describe "when the number of digits in the zipcode is 5" do
        it "includes the zipcode digits as a string" do
          zipcode_data_string = "12345"
          expect(ZipCode.parse_zipcode_data(zipcode_data_string)).to include("12345")
        end
      end

      describe "when the number of digits in the zipcode is greater than or less than 5" do
        it "does not include the zipcode digits as a string" do
          zipcode_data_string = "1234"
          expect(ZipCode.parse_zipcode_data(zipcode_data_string)).not_to include("12345")
        end
      end
    end

    context "with zipcode and tax rate information" do
      describe "when the tax rate format has no decimal point" do
        it "includes the tax rate information as a string" do
          zipcode_data_string = "12345, 10"
          expect(ZipCode.parse_zipcode_data(zipcode_data_string)).to include("10")
        end
      end

      describe "when the tax rate has a decimal point" do
        it "includes the tax rate information as a string" do
          zipcode_data_string = "12345, 10.125"
          expect(ZipCode.parse_zipcode_data(zipcode_data_string)).to include("10.125")
        end
      end

      describe "when the tax rate has a decimal point with no leading digits" do
        it "does not include the tax rate information as a string" do
          zipcode_data_string = "12345, .125"
          expect(ZipCode.parse_zipcode_data(zipcode_data_string)).not_to include(".125")
        end
      end
    end
  end

  describe ".find_or_update_from_data" do
    context "when the data includes zip code information only" do
      let!(:zip_code) { create(:zip_code) }

      describe "when the data is formatted correctly" do
        context "when the zip code already exists" do
          let(:zipcode_data_string) { "60654" }

          it "does not create a new zip code" do
            expect{
              ZipCode.find_or_update_from_data(zipcode_data_string)
            }.not_to change { ZipCode.count }
          end

          it "finds the zip code" do
            expect(ZipCode.find_or_update_from_data(zipcode_data_string)).to eq(zip_code)
          end
        end

        context "when the zip code does not yet exist" do
          let(:zipcode_data_string) { "54321" }

          it "creates a new zip code" do
            expect{
              ZipCode.find_or_update_from_data(zipcode_data_string)
            }.to change { ZipCode.count }.by(1)
          end
        end
      end

      describe "when the data is not formatted correctly" do
        context "when the number of digits is not equal to 5" do
          let(:zipcode_data_string) { "1234" }

          it "returns nil" do
            expect(ZipCode.find_or_update_from_data(zipcode_data_string)).to be_nil
          end
        end
      end
    end

    context "when the data includes zip code and tax rate information" do
      let!(:zip_code) { create(:zip_code, :with_tax_rate) }

      describe "when the data is formatted correctly" do
        let(:zipcode_data_string) { "60654, 10.125" }

        context "when the zip code already exists" do
          it "finds and updates the zip code's tax rate" do
            ZipCode.find_or_update_from_data(zipcode_data_string)
            zip_code.reload
            expect(zip_code.tax_rate).to eq(BigDecimal.new("10.125"))
          end
        end

        context "when the zip code does not yet exist" do
          it "creates a new zip code with the provided tax rate" do
            zipcode_data_string = "54321, 7.5"
            zip_code = ZipCode.find_or_update_from_data(zipcode_data_string)
            zip_code.reload
            expect(zip_code.tax_rate).to eq(BigDecimal.new("7.5"))
          end
        end
      end

      describe "when the data is not formatted correctly" do
        context "when the zip code already exists" do
          let(:zipcode_data_string) { "60654, .825" }

          it "finds the zip code" do
            expect(ZipCode.find_or_update_from_data(zipcode_data_string)).to eq(zip_code)
          end

          it "does not update the update the zip code's tax rate" do
            ZipCode.find_or_update_from_data(zipcode_data_string)
            zip_code.reload
            expect(zip_code.tax_rate).to eq(BigDecimal.new("9.5"))
          end
        end

        context "when the zip code does not yet exist" do
          let(:zipcode_data_string) { "54321, .825" }

          it "creates a new zip code" do
            expect{
              ZipCode.find_or_update_from_data(zipcode_data_string)
            }.to change { ZipCode.count }.by(1)
          end

          it "does not set the new zip code's tax rate" do
            zip_code = ZipCode.find_or_update_from_data(zipcode_data_string)
            zip_code.reload
            expect(zip_code.tax_rate).to be_nil
          end
        end
      end
    end
  end
end
