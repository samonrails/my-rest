# == Schema Information
#
# Table name: users
#
#  id                          :integer          not null, primary key
#  email                       :string(255)      default(""), not null
#  encrypted_password          :string(255)      default(""), not null
#  reset_password_token        :string(255)
#  reset_password_sent_at      :datetime
#  remember_created_at         :datetime
#  sign_in_count               :integer          default(0)
#  current_sign_in_at          :datetime
#  last_sign_in_at             :datetime
#  current_sign_in_ip          :string(255)
#  last_sign_in_ip             :string(255)
#  confirmation_token          :string(255)
#  confirmed_at                :datetime
#  confirmation_sent_at        :datetime
#  unconfirmed_email           :string(255)
#  created_at                  :datetime         not null
#  updated_at                  :datetime         not null
#  first_name                  :string(40)
#  last_name                   :string(40)
#  disable                     :boolean          default(FALSE)
#  created_by                  :string(255)
#  default_account_location_id :integer
#  default_billing_id          :integer
#  default_contact_id          :integer
#  roles_mask                  :integer
#  deleted_at                  :datetime
#  payment_method              :string(255)
#  default_account_id          :integer
#  phone_number                :string(255)
#  position                    :string(255)
#  agreed_terms_at             :datetime
#  utility_account             :boolean          default(FALSE)
#  default_select_payment_id   :integer
#  location_search_count       :integer          default(0)
#  last_location_search_at     :datetime         default(2014-06-02 01:56:18 UTC), not null
#  sign_up_reason              :text
#  migrated_from_drupal        :boolean          default(FALSE)
#

require "spec_helper"

describe User do
  let(:user) { create(:user, :confirmed) }

  it "should be valid" do
    user.should be_valid
  end

  it "should have proper associations with issues" do
    user.opened_assigned_issues.class.should be Array
    user.closed_assigned_issues.class.should be Array
    user.opened_reported_issues.class.should be Array
    user.closed_reported_issues.class.should be Array
  end

  it "has a cart" do
    expect(user.cart).to be_present
  end

  context "displaying user on manifest" do
    let(:user){ create(:user, :confirmed, first_name: "New Fooda", last_name: "Customer", email: "fooda@fooda.com") }

    it "displays email if no name exists" do
      expect(user.manifest_name).to eq('fooda@fooda.com')
    end

    it "displays name if name exists" do
      user.update_attributes(first_name: "Maximus Decimus", last_name: "Meridius")
      expect(user.manifest_name).to eq('Maximus Decimus Meridius')
    end

  end

  context "creating a user" do
    let(:account){ create(:account) }

    def create_user
      User.create_user_after_order!(account.id, "someone@somewhere.com", {cardholder_name: "Anthony BC"})
    end

    context "when the user does not exist" do
      it "creates a new user" do
        # Account factory creates Users, so we're actually creating three users here
        expect{ create_user }.to change(User, :count).by(3)
      end

      it "creates a new 'Member' Account" do
        expect{ create_user }.to change(AccountRole, :count).by(1)
      end

      it "sets the user a 'Foodizen'" do
        expect(create_user.roles).to include('foodizen')
      end

      it "sets the user as created by an admin" do
        expect(create_user.created_by).to eq('guest')
      end

      it "sets the role as a 'member'" do
        user = create_user
        user.reload
        expect(user.account_roles.pluck(:role)).to include('member')
      end

      it "parses and assigns the name correctly" do
        user = create_user
        user.reload
        expect(user.first_name).to eq('Anthony')
        expect(user.last_name).to eq('BC')
      end
    end

    context "when the user does exist" do
      let(:user){ create(:user, email: "someone@somewhere.com") }
      let(:account_role){ build(:account_role, user: user) }

      before do
        user.account_roles << account_role
      end

      it "does not create a new user" do
        # Account factory creates Users, so we're actually creating three users here
        expect{ create_user }.to change(User, :count).by(2)
      end

      it "does not subscribe the User to the Account's email list" do
        Mailchimp.should_not_receive(:subscribe_email).with(account.id, "someone@somewhere.com")
        create_user
      end
    end
  end
end
