# == Schema Information
#
# Table name: delivery_groups
#
#  id        :integer          not null, primary key
#  name      :string(255)
#  market_id :integer
#  vendor_id :integer
#  key       :string(255)      default(""), not null
#

require "spec_helper"

describe DeliveryGroup do
  let(:account){ FactoryGirl.create(:account) }
  let(:location){ FactoryGirl.create(:location) }
  let(:market) { FactoryGirl.create(:market) }
  let(:vendor){ FactoryGirl.create(:vendor) }
  let(:delivery_group){ FactoryGirl.create(:delivery_group, market_id: market.id, vendor_id: vendor.id) }

  it "should be valid" do
    expect(delivery_group).to be_valid
  end

	it { should validate_presence_of(:name) }
	it { should validate_presence_of(:market_id) }
	it { should validate_presence_of(:vendor_id) }

	it "should have associated delivery groups locations" do
		expect(delivery_group).to respond_to(:delivery_groups_locations)
	end

	it "should have associated locations" do
		expect(delivery_group).to respond_to(:locations)
	end

end
