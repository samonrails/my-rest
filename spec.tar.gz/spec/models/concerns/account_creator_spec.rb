require 'spec_helper.rb'

describe AccountCreator do
  before(:each) do
    @account = Account.new(:name => 'Poxabogue Golf Center',
                           :account_type => 'corporate',
                           :active => true
                          )
    @address = @account.build_address(:name => 'Poxabogue Golf Center -ProShop',
                                     :address1 => '3556 Montauk Highway',
                                     :address2 => '',
                                     :city => 'Wainscott',
                                     :state => 'New York',
                                     :zip_code => '11975',
                                     :country => 'United States'
                                    )
    @location = Location.new(:name => 'Loading Docs')

    @account_role = AccountRole.new(:role => 'administrator')
    @user = @account_role.build_user(:email => 'abc@example.com',
                                     :first_name => 'John',
                                     :last_name => 'Doe',
                                     :phone_number => '(123) 123 1231'
                                     )
    @account_creator = AccountCreator.new(@account, @account_role, @location)
  end

  describe 'Validators for AccountCreator' do
    describe 'account_creator#account_valid' do
      it "- should validate if account is valid" do
        @account.name = ''
        expect(@account_creator.account_valid?).to eq false
      end
    end

    describe 'account_creator#location_valid?' do
      it '- validate presence of location name' do
        @location.name = ''
        expect(@account_creator.location_valid?).to eq false
      end
    end

    describe 'account_creator#user_valid?' do
      it " - should validate if a user is valid" do
        expect(@account_creator.user_valid?).to eq true
      end

      it " - should fail if a user first name is not present" do
        @user.first_name = ''
        expect(@account_creator.user_valid?).to eq false
      end

      it "- should fail if a users last name is not present" do
        @user.last_name = ''
        expect(@account_creator.user_valid?).to eq false
      end

      it "- should fail if a user's email is not present" do
        @user.email = ''
        expect(@account_creator.user_valid?).to eq false
      end

      it "- should fail if a user's phone is not present" do
        @user.phone_number = ''
        expect(@account_creator.user_valid?).to eq false
      end

      it '- should fail if a user\'s phone number is not a valid US phone number' do
        @user.phone_number = '91 22 21715922'
        expect(@account_creator.user_valid?).to eq false
      end
    end

    describe 'account_creator#account_role_valid?' do
      it " - should validate if a account has a valid role" do
        expect(@account_creator.account_role_valid?).to eq true
      end

      it "- should fail if an account doesn't have a valid role" do
        @account_role.role = 'admin'
        expect(@account_creator.account_role_valid?).to eq false
      end

      it "- should fail if account is not valid" do
        @account.name = ''
        expect(@account_creator.account_role_valid?).to eq false
      end

      it '- should fail if location is not valid' do
        @location.name = ''
        expect(@account_creator.account_role_valid?).to eq false
      end
    end

    describe 'account_creator#user_email_valid?' do
      it "- should ensure that the user email is present" do
        @user.email = ''
        expect(@account_creator.user_email_valid?).to eq false
      end

      it "- should ensure that it contains an error when email is missing" do
        @user.email = ''
        @account_creator.user_email_valid?
        expect(@account_creator.errors.messages.has_key?(:'user.email')).to eq true
      end
    end

    describe 'account_creator#user_first_name_valid?' do
      it "- should ensure that the users first name is present" do
        @user.first_name = ''
        expect(@account_creator.user_first_name_valid?).to eq false
      end

      it "- should ensure that it contains an error when the first name is
missing" do
        @user.first_name = ''
        @account_creator.user_first_name_valid?
        expect(@account_creator.errors.messages.has_key?(:'user.first_name')).to eq true
      end
    end

    describe 'account_creator#user_phone_number_valid?' do
      it "- should ensure that user enters a valid phone number" do
        @user.phone_number = ''
        @account_creator.user_phone_number_valid?
        expect(@account_creator.errors.messages.has_key?(:'user.phone_number')).to eq true
      end

    end


    describe 'account_creator#user_last_name_valid?' do
      it "- should ensure that the users last name is present" do
        @user.last_name = ''
        expect(@account_creator.user_last_name_valid?).to eq false
      end

      it "- should ensure that it contains an error when the last name is
missing" do
        @user.last_name = ''
        @account_creator.user_last_name_valid?
        expect(@account_creator.errors.messages.has_key?(:'user.last_name')).to eq true
      end
    end

    describe 'account_creator#role_valid' do
      it "- should ensure that the role is valid value as verified by the
account model" do
        @account_role.role = 'admin'
        expect(@account_creator.role_valid?).to eql false
      end

      it "- should ensure that it contains and error when roles is invalid" do
        @account_role.role = 'admin'
        @account_creator.role_valid?
        expect(@account_creator.errors.messages.has_key?(:'account.role')).to eq false
      end
    end

    describe 'account_creator#prepare_account_role' do
      it "- should create an account role for a given account and user" do
        @account.save
        @account_creator.prepare_account_role.should be_an_instance_of(AccountRole)
      end

      it "- should create an association between the user and the account
objects" do
        @account.save
        @account_creator.prepare_account_role
        @account.users.include?(@user).should be_true
      end
    end

    describe 'account_creator#account_role_errors' do
      it 'should return a hash of errors keys and messages' do
        @account_creator.instance_eval { account_role_errors }.should
        be_an_instance_of(ActiveSupport::OrderedHash)
      end
    end

    describe 'account_creator#new' do
      it 'should create an account_creator object with an account instance
variable' do
        account_creator = AccountCreator.new(@account, @account_role, @location)
        account_creator.account.should be_an_instance_of(Account)
      end

      it 'should create an account_creator object with an account_role
instance variable' do
        account_creator = AccountCreator.new(@account, @account_role, @location)
        account_creator.account_role.should be_an_instance_of(AccountRole)
      end
    end

    describe 'account_creator#address_valid?' do
      it 'should ensure that the address1 is present in address' do
        @address.address1 = ''
        account_creator = AccountCreator.new(@account, @account_role, @location)
        expect(account_creator.address_valid?).to eq false
      end

      it 'should add an error message for missing address1 field' do
        @address.address1 = ''
        account_creator = AccountCreator.new(@account, @account_role, @location)
        account_creator.valid?
        expect(account_creator.errors.messages.has_key?(:'address.address1')).to eq true
      end

      it 'should ensure that city is present in the address' do
        @address.city = ''
        account_creator = AccountCreator.new(@account, @account_role, @location)
        expect(account_creator.address_valid?).to eq false
      end

      it 'should add an error message for missing city field' do
        @address.city = ''
        account_creator = AccountCreator.new(@account, @account_role, @location)
        account_creator.valid?
        expect(account_creator.errors.messages.has_key?(:'address.city')).to eq true
      end

      it 'should ensure that state is present in the address' do
        @address.state = ''
        account_creator = AccountCreator.new(@account, @account_role, @location)
        expect(account_creator.address_valid?).to eq false
      end

      it 'should add an error message for missing state field' do
        @address.state = ''
        account_creator = AccountCreator.new(@account, @account_role,
                                             @location)
        account_creator.valid?
       expect(account_creator.errors.messages.has_key?(:'address.state')).to eq true
      end

      it 'should ensure that zip_code is present' do
        @address.zip_code = ''
        account_creator = AccountCreator.new(@account, @account_role,
                                             @location)
        expect(account_creator.address_valid?).to eq false
      end

      it 'should add an error message for missing zip code field' do
        @address.zip_code = ''
        account_creator = AccountCreator.new(@account, @account_role,
                                             @location)
        account_creator.valid?
        expect(account_creator.errors.messages.has_key?(:'address.zip_code')).to eq true
      end
    end

    describe 'account_creator#prepare_building - Building' do
      it 'should return a new unapproved building' do
        account_creator = AccountCreator.new(@account, @account_role, @location)
        @account.save
        account_creator.prepare_account_role
        account_creator.prepare_location
        account_creator.prepare_building.should be_an_instance_of(Building)
      end

      it 'should have a name field with the value of the address1 field' do
        account_creator = AccountCreator.new(@account, @account_role, @location)
        @account.save
        account_creator.prepare_account_role
        account_creator.prepare_location
        building = account_creator.prepare_building
        expect(building.name).to eq @account.address.address1
      end

      it 'should have a market associated with it' do
        market = FactoryGirl.create(:market)
        account_creator =AccountCreator.new(@account, @account_role, @location)
        account_creator.should_receive(:markets_by_zip).and_return([market])
        @account.save
        account_creator.prepare_account_role
        building = account_creator.prepare_building
        building.market.should_not be_nil
      end
      it 'should have address associated with it' do
        account_creator = AccountCreator.new(@account, @account_role, @location)
        @account.save
        account_creator.prepare_account_role
        building = account_creator.prepare_building
        building.address.should_not be_nil
      end
    end

    describe 'account_creator#prepare_location - Location' do
      it 'should return an instance of location' do
        account_creator = AccountCreator.new(@account, @account_role, @location)
        @account.save
        account_creator.prepare_account_role
        account_creator.prepare_location
        expect(@account.reload.locations.empty?).to eq false

      end

      it 'should have be a name' do
        account_creator = AccountCreator.new(@account, @account_role, @location)
        @account.save
        account_creator.prepare_account_role
        account_creator.prepare_location

        @account.reload.locations.first.name.should_not be_nil
      end

      it 'should have a building_address_note - Location' do
        account_creator = AccountCreator.new(@account, @account_role, @location)
        @account.save
        account_creator.prepare_account_role
        account_creator.prepare_location

        @account.reload.locations.first.building_address_notes.should_not be_nil
      end
    end

    describe 'account_creator#markets_by_zip - Markets' do
      it 'should return an array of markets' do
        zip_code = FactoryGirl.create(:zip_code, :zipcode => '10020')
        market = FactoryGirl.create(:market)
        market.zip_codes.push(zip_code)
        account_creator = AccountCreator.new(@account, @account_role, @location)
        expect(account_creator.markets_by_zip('10020').empty?).to eq false
      end
    end

    describe 'account_creator#complete_account_creation! - Account' do
      it 'should have a location with an associated building' do
        account_creator = AccountCreator.new(@account, @account_role,@location)
        @account.save
        zip_code = FactoryGirl.create(:zip_code, :zipcode => @account.address.zip_code)
        market = FactoryGirl.create(:market)
        market.zip_codes.push(zip_code)

        account_creator.prepare_account_role
        account_creator.prepare_location
        account_creator.complete_account_creation!
        (expect(@account.reload.locations.empty?).to eq false) &&
          (expect(@account.reload.locations.first.building.nil?).to eq false)
      end
    end

    it 'should create an account_creator object with an user instance
variable' do
      account_creator = AccountCreator.new(@account, @account_role, @location)
      account_creator.user.should be_an_instance_of(User)
    end
  end
end
