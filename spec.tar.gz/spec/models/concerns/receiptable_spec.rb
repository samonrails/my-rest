require "spec_helper"

describe Receiptable do

  context "while testing" do
    Comment.class_eval do
      include Receiptable
      track_receipts
      # Rails.env.test? is already set
    end

    let(:comment){ FactoryGirl.create(:comment) }

    it "should not create Receipts" do
      expect do
        comment.description = "random"
        comment.save
        comment.reload
      end.to change(comment.receipts, :count).by(0)
    end
  end


  context "tracking deltas" do
    Address.class_eval do
      include Receiptable
      track_receipts
      track_in_testing! # Force testing mode
    end

    let(:address){ FactoryGirl.create(:address) }

    it "creates a Receipt" do
      expect do
        address.name = "random"
        address.save
      end.to change(Receipt, :count).by(2)
    end

    it "has_many receipts" do
      expect do
        address.name = "random"
        address.save
      end.to change(address.receipts, :count).by(1)
    end

    it "tracks the full object at first (baseline)" do
      receipt = address.receipts.first
      expect(receipt.obj).to eq(address.as_json)
    end

    it "tracks only deltas on subsequent changes" do
      address.name = "random"
      address.save
      receipt = address.receipts.last
      expect(receipt.delta).to eq({"name" => ["", "random"]})
    end
  end


  context "tracking objects" do
    Token.class_eval do
      include Receiptable
      track_receipts :object
      track_in_testing! # Force testing mode
    end

    let(:token){ FactoryGirl.create(:token) }

    it "creates a Receipt" do
      expect do
        token.identity_id = 3
        token.save
      end.to change(Receipt, :count).by(2)
    end

    it "has_many receipts" do
      expect do
        token.identity_id = 3
        token.save
      end.to change(token.receipts, :count).by(1)
    end

    it "tracks the entire object" do
      token.identity_id = 3
      token.save
      receipt = token.receipts.last
      expect(receipt.obj).to eq(JSON.parse(token.to_json))
    end
  end

end
