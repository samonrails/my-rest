require 'spec_helper.rb'

describe CateringSignupSearch do
  before(:each) do
    @catering_sales_lead = FactoryGirl.build(:catering_sales_lead)

    @default_params = {
          :zip_code => @catering_sales_lead.zip_code,
          :state => @catering_sales_lead.state,
          :city => @catering_sales_lead.city,
          :company_name => @catering_sales_lead.organization_name
      }

  end

  describe 'initialize' do
    it 'should create a ActiveRecord::Relation object for every search' do
      catering_signup_search = CateringSignupSearch.new(@default_params)
      catering_signup_search.query.should be_an_instance_of(ActiveRecord::Relation)
    end
  end

  describe 'zip_code_clause' do
    it 'should return an instance of activerecord relation' do
      catering_signup_search = CateringSignupSearch.new(@default_params)
      catering_signup_search.zip_code_clause.should be_an_instance_of(ActiveRecord::Relation)
    end
  end


  describe 'state_clause' do
    it 'should return an instance of activerecord relation' do
      catering_signup_search = CateringSignupSearch.new(@default_params)
      catering_signup_search.state_clause.should be_an_instance_of(ActiveRecord::Relation)
    end
  end

  describe 'city_clause' do
    it 'should return an instance of activerecord relation' do
      catering_signup_search = CateringSignupSearch.new(@default_params)
      catering_signup_search.city_clause.should be_an_instance_of(ActiveRecord::Relation)
    end
  end

  describe 'company_name_clause' do
    it 'should return an instance of activerecord relation' do
      catering_signup_search = CateringSignupSearch.new(@default_params)
      catering_signup_search.company_name_clause.should be_an_instance_of(ActiveRecord::Relation)
    end
  end

  describe 'search' do
    it 'should return a CateringSignupSearch object ' do
      @catering_sales_lead.save
      catering_signup_search = CateringSignupSearch.new(@default_params)
      catering_signup_search.search.include?(@categing_sales_lead)
    end
  end
end