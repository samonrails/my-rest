# == Schema Information
#
# Table name: vendors
#
#  id                         :integer          not null, primary key
#  name                       :string(255)
#  legal_name                 :string(255)
#  description                :text
#  website                    :string(255)
#  created_at                 :datetime         not null
#  updated_at                 :datetime         not null
#  image_file_name            :string(255)
#  image_content_type         :string(255)
#  image_file_size            :integer
#  image_updated_at           :datetime
#  default_tax_rate           :decimal(, )      default(0.0), not null
#  address_id                 :integer
#  vendor_manager_id          :integer
#  bio                        :text
#  rating                     :decimal(2, 1)
#  review_count               :integer
#  rating_image_url           :string(255)
#  yelp_url                   :string(255)
#  yelp_id                    :string(255)
#  vendor_type                :string(255)      default("Restaurant")
#  vendor_minimum             :float            default(100.0)
#  concurrent_orders          :integer          default(2)
#  concurrent_orders_time     :integer          default(30)
#  managed_services_lead_time :decimal(, )      default(21.0)
#  min_capacity_usd           :float            default(0.0), not null
#  fee                        :float
#  is_fixed                   :boolean          default(FALSE)
#  cap                        :float            default(100.0)
#  default_delivery_fee_cents :integer          default(0)
#

require "spec_helper"

describe Vendor do
  let(:market_a){ FactoryGirl.create(:market) }
  let(:market_b){ FactoryGirl.create(:market) }
  let!(:delivery_vendor_a){ FactoryGirl.create(:vendor, market_list: market_a.name, vendor_type: "Delivery Service") }
  let!(:delivery_vendor_b){ FactoryGirl.create(:vendor, market_list: market_b.name, vendor_type: "Delivery Service") }
  let!(:restaurant_vendor_a){ FactoryGirl.create(:vendor, market_list: market_a.name, vendor_type: "Restaurant") }
  let!(:restaurant_vendor_b){ FactoryGirl.create(:vendor, market_list: market_b.name, vendor_type: "Restaurant") }

  describe ".vendors_by_type_and_market" do
    context "with a specific market" do
      before do
        @vendors = Vendor.vendors_by_type_and_market("Restaurant", market_a.name)
      end

      it "returns the vendors in that market" do
        expect(@vendors).to include(restaurant_vendor_a)
      end

      it "does not return vendors that are not in that market" do
        expect(@vendors).not_to include(restaurant_vendor_b)
      end
    end

    context "with a specific vendor type" do
      before do
        @vendors = Vendor.vendors_by_type_and_market("Delivery Service", market_b.name)
      end

      it "returns the vendors of that type" do
        expect(@vendors).to include(delivery_vendor_b)
      end

      it "does not return vendors that are not of that type" do
        expect(@vendors).not_to include(delivery_vendor_a)
      end
    end
  end
end
