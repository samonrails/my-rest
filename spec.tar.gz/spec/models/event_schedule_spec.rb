# == Schema Information
#
# Table name: event_schedules
#
#  id                      :integer          not null, primary key
#  schedule                :string(255)
#  product                 :string(255)
#  meal_period             :string(255)
#  location_id             :integer
#  days_to_schedule        :integer
#  contact_id              :integer
#  vendor_id               :integer
#  account_id              :integer
#  event_start_time        :datetime
#  event_end_time          :datetime
#  setup_start_time        :datetime
#  setup_end_time          :datetime
#  schedule_start_date     :datetime
#  schedule_end_date       :datetime
#  pause_start_date        :datetime
#  pause_end_date          :datetime
#  processed_until         :datetime
#  created_by_id           :integer
#  menu_template_id        :integer
#  quantity                :integer
#  created_at              :datetime         not null
#  updated_at              :datetime         not null
#  event_schedule_owner_id :integer
#

require 'spec_helper'

describe EventSchedule do

  let(:vendor) { create(:vendor) }
  let(:account) { create(:account) }
  let(:contact) { create(:contact) }
  let(:location) { create(:location) }
  let!(:utility_user) { create(:user, :confirmed, utility_account: true) }
  let(:user) {create(:user, :confirmed)}

  let(:event_schedule) do
    EventSchedule.new(
      :product => 'catering',
      :location => location,
      :account => account,
      :contact => contact,
      :schedule_start_date => DateTime.now.next_week.utc,
      :event_start_time => DateTime.parse("Thu, 11 Jul 2013 11:30"),
      :event_end_time => DateTime.parse("Thu, 11 Jul 2013 13:30"),
      :setup_start_time => DateTime.parse("Thu, 11 Jul 2013 10:30"),
      :setup_end_time => DateTime.parse("Thu, 11 Jul 2013 11:29"),
      :meal_period => 'Lunch',
      :created_by => user,
      :created_at =>  Date.new(2013,6,30),
      :days_to_schedule => 7,
      :schedule => '{"interval":1,"until":null,"count":null,"validations":null,"rule_type":"IceCube::DailyRule"}'
    )
  end


  it 'should be valid' do
    event_schedule.should be_valid
  end

  describe "#schedulize!" do
    it "should stamp out the proper amount of events" do
      event_schedule.days_to_schedule = 10
      expect {event_schedule.save}.to change{event_schedule.events.count}.by(10)
    end
    it "should just create monday and wednesday events with a monday and wednesday frequency" do
      event_schedule.schedule = IceCube::Rule.weekly.day(:monday, :wednesday).to_json
      event_schedule.save
      expect(event_schedule.events.all? {|x| x.event_start_time.monday? || x.event_start_time.wednesday?}).to be_true
    end
    it "should not create events when the schedule is expired" do
      event_schedule.schedule_start_date = 2.years.ago
      event_schedule.schedule_end_date = 1.year.ago
      expect {event_schedule.save}.not_to change{Event.count}
    end

    it "should not schedule events when the schedule is paused" do
      event_schedule.schedule_start_date = 30.days.from_now
      event_schedule.schedule_end_date = 60.days.from_now
      event_schedule.pause_start_date = 31.days.from_now
      event_schedule.pause_end_date = 32.days.from_now
      event_schedule.save
      result = event_schedule.events.where("event_start_time > ? and event_start_time < ?", 31.days.from_now, 32.days.from_now)
      expect(result).to be_empty
    end
    it "should delay creating events until the schedule starts" do
      event_schedule.save
      expect(event_schedule.events.order('event_start_time asc').first.event_start_time.to_date).to eq DateTime.now.next_week.utc.to_date
    end
    it "should create an additional event when triggered on the next day" do
      event_schedule.schedule_start_date = DateTime.now.next_week
      event_schedule.schedule_end_date = DateTime.now.next_week + 14.days
      event_schedule.days_to_schedule = 3
      event_schedule.save
      Delorean.time_travel_to "Next week tuesday at 1am" do
        expect {event_schedule.schedulize!}.to change{event_schedule.events.count}.by(1)
      end
    end
  end
  describe "#reschedulize!" do
    it "should change the delivery times when it's changed" do
      event_schedule.save
      event_schedule.update_attributes(event_start_time: 30.minutes.from_now)
      hours = event_schedule.events.where(status: "auto_generated").collect {|x| x.event_start_time.strftime('%H:%M')}
      expect(hours.all? {|x| x == 30.minutes.from_now.strftime('%H:%M')}).to be_true
    end
    it "should not touch events that aren't in auto_generated status" do
      event_schedule.save
      random_event = event_schedule.events.sample
      random_event.update_attributes(:status => Status::Event.active)
      expect {
        event_schedule.update_attributes(:event_start_time => random_event.event_start_time + 30.minutes)
      }.not_to change {
        random_event.reload.event_start_time
      }
    end
    describe "cancelations" do
      before do
        event_schedule.schedule_start_date = 60.days.from_now
        event_schedule.schedule_end_date = 90.days.from_now
        event_schedule.save
      end
      it "should cancel events no longer in the window when the schedule is changed" do
        expect {
          event_schedule.update_attributes(schedule_start_date: DateTime.now.next_week,
                                           schedule_end_date:   DateTime.now.next_week + 10.days)
        }.to change{
          event_schedule.events.where(status: Status::Event.canceled).count
        }.by(7)
      end
      it "should not cancel events that have been modified out of auto_generated status" do
        random_event = event_schedule.events.sample
        random_event.update_attributes(:status => Status::Event.active, event_start_time: 30.minutes.from_now)
        expect {
          event_schedule.update_attributes(schedule_start_date: DateTime.now.next_week,
                                           schedule_end_date:   DateTime.now.next_week + 10.days)
        }.not_to change {
          random_event.reload.status || random_event.reload.event_start_time
        }
      end
    end
  end
end
