# == Schema Information
#
# Table name: inventory_item_product_types
#
#  id                :integer          not null, primary key
#  inventory_item_id :integer
#  product_type      :string(20)
#

require 'spec_helper'

describe "InventoryItemProductType" do

  it "should warn us to get off our duffs" do
    pending "fill me out"
  end

end
