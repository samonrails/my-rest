# == Schema Information
#
# Table name: select_event_menu_items
#
#  id                         :integer          not null, primary key
#  select_event_menu_group_id :integer
#  inventory_item_id          :integer
#  position                   :integer
#  created_at                 :datetime         not null
#  updated_at                 :datetime         not null
#

require 'spec_helper'

describe SelectEventMenuItem do

  let(:account){ create(:account, :account_pricing_tier_select) }
  let(:select_event){ create(:select_event_with_locations, account: account) }
  let(:select_event_vendor){ create(:select_event_vendor) }
  let(:select_event_menu_group){ create(:select_event_menu_group, name: "Featured") }
  let(:item) { create(:inventory_item, name_public: "grub", description: "This is mighty tasty!", signature_item: true)}
  let(:item2) { create(:inventory_item) }
  let(:select_event_menu_item){ create(:select_event_menu_item, inventory_item: item) }
  let(:option_group){ create(:option_group) }
  let(:vendor) { create(:vendor, name: "Wendys") }

  before do
    item.dietary_restriction_list.add("Vegan")
    item.save
    vendor.inventory_items << item
    select_event.select_event_vendors << select_event_vendor
    select_event_vendor.select_event_menu_groups << select_event_menu_group
    select_event_menu_group.select_event_menu_items << select_event_menu_item
  end

  it "knows the select_event" do
    expect(select_event_menu_item.select_event).to eq(select_event)
  end

  it "knows the account" do
    expect(select_event_menu_item.account).to eq(account)
  end

 it "knows the name" do
    expect(select_event_menu_item.item_name).to eq("grub")
  end

  it "knows the vendor" do
    expect(select_event_menu_item.item_vendor).to eq("Wendys")
  end

  it "knows the tags" do
    expect(select_event_menu_item.item_tags).to eq(["Vegan"])
  end

  it "knows its options" do
    item.option_groups << option_group
    expect(select_event_menu_item.item_options).to eq([option_group])
  end

  it "knows if it has options" do
    item.option_groups << option_group
    expect(select_event_menu_item.has_options?).to be_true
  end

  it "knows the display info" do
    info = select_event_menu_item.display_info
    expect(info).to be_an(OpenStruct)
    expect(info.name).to eq("grub")
  end

  it "knows if its signature" do
    expect(select_event_menu_item.signature?).to be_true
  end

  describe "user's recommendations" do
    let(:user){ create(:user, :confirmed) }
    let(:select_order){ create(:select_order, user: user) }

    it "knows if previously purchased" do
      select_order.select_order_items.create(inventory_item: item)
      expect(select_event_menu_item.previously_purchased?(user)).to be_true
    end
  end

  describe "retrieving previous order info" do
    let(:user){ create(:user, :confirmed) }
    let(:select_order){ create(:select_order, user: user) }
    let(:item2){ create(:inventory_item, inventory_item_option: true) }
    let(:option_group){ create(:option_group) }
    let(:option_item){ Select::SelectOrderItemOption.create(inventory_item: item2, option_group: option_group) }

    before do
      select_order.select_order_items.create(inventory_item: item, special_instructions: "make it right")
      item.option_groups << option_group
      option_group.inventory_items << item2
      select_order.select_order_items.first.select_order_item_options << option_item
    end

    it "knows if there are previous customizations" do
      expect(select_event_menu_item.previous_customizations(user)).to be_true
    end

    it "knows previous options" do
      expect(select_event_menu_item.previous_options(user)).to eq([option_item.id])
    end

    it "knows previous customizations" do
      expect(select_event_menu_item.previous_instructions(user)).to eq("make it right")
    end
  end
end
