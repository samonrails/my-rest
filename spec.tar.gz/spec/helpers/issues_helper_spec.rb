require "spec_helper"

describe IssuesHelper do

  describe "show_priority" do
    it "should return high priority label" do
      expect(helper.show_priority("High")).to eq "<span class=\"label label-important\">High</span>"
    end
    it "should return high priority label" do
      expect(helper.show_priority("Normal")).to eq "<span class=\"label label-warning\">Normal</span>"
    end
    it "should return high priority label" do
      expect(helper.show_priority("Low")).to eq "<span class=\"label label-success\">Low</span>"
    end
  end

end