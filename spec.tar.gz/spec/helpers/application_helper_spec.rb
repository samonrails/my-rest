require "spec_helper"

describe ApplicationHelper do

  let(:contact_a){create(:contact)}
  let(:contact_b){create(:contact, :primary_contact => true)}
  let(:capacity){create(:capacity)}
  let(:event){create(:event)}
  let(:account){create(:account)}
  let(:user){create(:user)}

  let(:object) do
    level = ["Aggregate Item Level Food Ratings", "Event Level Food Ratings", "Food Presentation", "Order Accuracy", "On Time Delivery", "Ease of Ordering", "Customer Service"].sample
    product_type = Product.find_parent(event.product)
    review = FactoryGirl.create(:review, :reviewable_id => event.id, :reviewable_type => "Event", :additional_event_ratings => level )
    review_rollup = FactoryGirl.create(:reviews_rollup, :reference_id => account.id, :reference_type => "Account",
                                         :item_level_reviews => {:reviews=>[review.id], :rating_array=>[3]},
                                         :event_level_reviews => {:reviews=>[review.id], :rating_array=>[3]},
                                         :food_presentation_reviews => {:reviews=>[review.id], :rating_array=>[3]},
                                         :order_accuracy_reviews => {:reviews=>[review.id], :rating_array=>[3]},
                                         :delivery_reviews => {:reviews=>[review.id], :rating_array=>[3]},
                                         :ease_of_ordering_reviews => {:reviews=>[review.id], :rating_array=>[3]},
                                         :customer_service_reviews => {:reviews=>[review.id], :rating_array=>[3]})
    [review_rollup, level, review]
  end

  describe "flash_class" do
    it "should return alert-error class" do
      expect(helper.flash_class(:alert)).to eq "alert-error"
    end

    it "should return alert-error class" do
      expect(helper.flash_class(:error)).to eq "alert-error"
    end

    it "should return alert-success class" do
      expect(helper.flash_class(:notice)).to eq "alert-success"
    end
  end

  describe "body_class" do
    it "should return controller class" do
      helper.stub(:controller_name){"homepage"}
      expect(helper.body_class).to eq "homepage"
    end
  end

  describe "body_id" do
    it "should return controller class and action name" do
      helper.stub(:controller_name){"homepage"}
      helper.stub(:action_name){"index"}
      expect(helper.body_id).to eq "homepage__index"
    end
  end

  describe "friendly_boolean" do
    it "should return No" do
      expect(helper.friendly_boolean(contact_a.primary_contact)).to eq "No"
    end

    it "should return Yes" do
      expect(helper.friendly_boolean(contact_b.primary_contact)).to eq "Yes"
    end
  end

  describe "icon" do
    it "should return content_tag" do
      expect(helper.icon("icon-plus")).to eq "<i class=\"icon icon-plus\"></i>"
    end
  end

  describe "find_capacity" do
    it "should return vendor capacity" do
      expect(helper.find_capacity(capacity.vendor, capacity.day)).to eq capacity
    end
  end

  describe "average_rating" do
    it "should return average of rating array" do
      ary = [2,3,5,4,1,3]
      expect(helper.average_rating(ary)).to eq 3.0
    end
  end

  describe "reviews_for_current_graph" do
    it "should return reviews" do
      review_rollup = object[0]
      level = object[1]
      review = object[2]
      expect(helper.reviews_for_current_graph(review_rollup, level)).to eq [[review], [3]]
    end
  end

  describe "braintree_links" do
    def payment(status)
      payment_history = FactoryGirl.create(:payment_history, :status => status, :transaction_id => 1234, :amount => 500)
    end

    it "should return refund link" do
      ph = payment("settled")
      expect(helper.braintree_links(ph)).to eq "<a href=\"#\" amount=\"500.0\" class=\"btn btn-danger btn-mini btn-refund\" trans_id=\"1234\">Refund</a>"
    end

    it "should return void link" do
      ph = payment("submitted_for_settlement")
      expect(helper.braintree_links(ph)).to eq "<a href=\"#\" class=\"btn btn-danger btn-mini btn-void\" trans_id=\"1234\">Void</a>"
    end

    it "should return both refund and void links" do
      ph = payment("authorized")
      expect(helper.braintree_links(ph)).to eq "<a href=\"#\" amount=\"500.0\" class=\"btn btn-success btn-mini btn-settle\" trans_id=\"1234\">Settle</a><a href=\"#\" class=\"btn btn-danger btn-mini btn-void\" trans_id=\"1234\">Void</a>"
    end
  end

  describe "created_by" do
    it "should return event creator" do
      event = FactoryGirl.create(:event, :created_by_id => user.id)
      expect(helper.created_by(event)).to eq user.name
    end
    
  end

end