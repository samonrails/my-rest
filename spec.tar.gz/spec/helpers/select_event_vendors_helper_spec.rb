require 'spec_helper'

describe SelectEventVendorsHelper do

  let(:select_event_vendor){create(:select_event_vendor)}
  let(:select_event_menu_group_featured){create(:select_event_menu_group, name: "Featured")}
  let(:select_event_menu_group_all_other){create(:select_event_menu_group, name: "All Other")}
  let(:inventory_item1){create(:inventory_item, name_public: "Apple")}
  let(:inventory_item2){create(:inventory_item, name_public: "Banana")}
  let(:select_event_menu_item1){create(:select_event_menu_item, position: 1, inventory_item: inventory_item1)}
  let(:select_event_menu_item2){create(:select_event_menu_item, position: 2, inventory_item: inventory_item2)}

  before do
    select_event_menu_group_featured.select_event_menu_items << select_event_menu_item1
    select_event_menu_group_featured.select_event_menu_items << select_event_menu_item2
    select_event_vendor.select_event_menu_groups << select_event_menu_group_featured    
  end

  describe "#featured_menu_group" do
    it "returns correct select event menu group" do
      expect(featured_menu_group(select_event_vendor)).to eq(select_event_menu_group_featured)
    end
  end

  describe "#ordered_items_by_position" do
    it "returns correct order" do
      expect(ordered_items_by_position(select_event_menu_group_featured).last).to eq(select_event_menu_item2)
    end
  end

  describe "#all_other_group" do
    it "returns correct select event menu group" do
      select_event_vendor.select_event_menu_groups << select_event_menu_group_all_other
      expect(all_other_group(select_event_vendor)).to eq(select_event_menu_group_all_other)
    end
  end

  describe "#ordered_items_by_name" do
    it "returns correct order" do
      expect(ordered_items_by_name(select_event_menu_group_featured).first).to eq(select_event_menu_item1)
    end
  end

end
