require "spec_helper"

describe MenuTemplatesHelper do

  let(:vendor){create(:vendor)}

  let(:menu_template) do
    menu_template   = create(:menu_template, vendor: vendor, pricing_type: MenuPricingType.menu_level, cogs: 7.10, retail_price: 9.40)
    menu_template.inventory_items << create(:inventory_item, vendor: vendor, cogs: 10)
    menu_template
  end
  let(:menu_template1){create(:menu_template)}

  before(:each) do
    if PricingTier.all.count == 0
      Fooda::Util::create_pricing_tiers
    end
  end

  describe "#average_per_person_price" do
    it "should return per person price for menu template" do
      helper.average_per_person_price(menu_template).should eq "$ 13.33"
    end
    
    it "should return no item added yet" do
      helper.average_per_person_price(menu_template1).should eq "No item added yet"
    end
  end

end