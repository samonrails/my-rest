require 'spec_helper'

describe CheckoutHelper do
  describe "/checkout/_header" do
    let(:user){ create(:user) }
    let(:cart){ user.cart }
    let(:inventory_item){ create(:inventory_item) }
    let(:select_event){ create(:select_event) }

    before do
      cart.add!(select_event, inventory_item)
    end

    it "knows cart count" do
      expect(cart_count(cart)).to eq 1
    end

    it "displays checkout link" do
      expect(checkout_link(cart)).to eq("Checkout (1)")
    end

    it "knows the overlay text" do
      select_event.update_attributes(published: false)
      expect(overlay_text(select_event)).to eq("any orders at this time")
    end

  end
end