require 'spec_helper'

describe DeliveryGroupHelper do

	describe "#all_markets" do
		let(:market){ create(:market) }

		it "provides collection of markets" do
			market
			expect(all_markets).to include([market.name, market.id])
		end

	end

end