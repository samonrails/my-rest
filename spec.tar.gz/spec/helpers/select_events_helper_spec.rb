require "spec_helper"

describe SelectEventsHelper do

  let(:select_event){create(:select_event, :email_list_id => "dummy@fooda.com",
                            :delivery_time => 48.hours.from_now,
                            :ordering_window_start_time => 30.hours.from_now,
                            :ordering_window_end_time => 34.hours.from_now,
                            :introduction_email_time => (Time.now - 1.day).beginning_of_day,
                            :final_email_time => (Time.now - 1.day).beginning_of_day,
                            :ready_and_bagged => 40
                           )}
  let(:vendor){create(:vendor)}

  describe "#email_list_id" do
    it "should return email list id" do
      helper.email_list_id(select_event).should eq "dummy@fooda.com"
    end
  end

  describe "#default_delivery_time" do
    it "should return delivery time" do
      helper.default_delivery_time(select_event).to_time.should eq select_event.delivery_time.to_s(:full_date_time)
    end
  end

  describe "#default_ordering_window_start_time" do
    it "should return ordering window start time" do
      helper.default_ordering_window_start_time(select_event).to_time.should eq select_event.ordering_window_start_time.to_s(:full_date_time)
    end
  end

  describe "#default_ordering_window_end_time" do
    it "should return ordering window end time" do
      helper.default_ordering_window_end_time(select_event).to_time.should eq select_event.ordering_window_end_time.to_s(:full_date_time)
    end
  end

  describe "#default_introduction_email_time" do
    it "should return introduction email time" do
      helper.default_introduction_email_time(select_event).to_time.should eq (Time.now - 1.day).beginning_of_day
    end
  end

  describe "#default_final_email_time" do
    it "should return final email time" do
      helper.default_final_email_time(select_event).to_time.should eq (Time.now - 1.day).beginning_of_day
    end
  end

  describe "#ready_and_bagged" do
    it "should return the ready and bagged" do
      helper.ready_bagged(select_event).should eq 40
    end
  end

  describe "#existing_account_users" do
    it "should return existing account users" do
      helper.existing_account_users(select_event).should eq select_event.account.users
    end
  end
end
