require "spec_helper"

describe SettingsHelper do
end
