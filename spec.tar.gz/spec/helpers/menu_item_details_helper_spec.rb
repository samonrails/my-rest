require 'spec_helper'

describe MenuItemDetailsHelper do
  let(:account) { create(:account) }
  let(:standard_pricing_tier) { create(:pricing_tier, gross_profit: 20) }
  let(:silver_pricing_tier) { create(:pricing_tier, gross_profit: 15) }
  let(:inventory_item) { create(:inventory_item) }

  describe "#item_same_price?" do
    context "when item account price and item sell price are the same" do
      it "returns true" do
        FactoryGirl.create(
          :account_pricing_tier,
          :select,
          account: account,
          pricing_tier: standard_pricing_tier
        )
        expect(item_same_price?(inventory_item, account)).to be_true
      end
    end

    context "when item account price and item sell price are different" do
      it "returns false" do
        pending('Removed after select pricing update to use sell price')
        FactoryGirl.create(
          :account_pricing_tier,
          :select,
          account: account,
          pricing_tier: silver_pricing_tier
        )
        expect(item_same_price?(inventory_item, account)).to be_false
      end
    end
  end

  describe "#item_account_price" do
    it "returns the price considering account pricing tier" do
      pending('Removed after select pricing update to use sell price')
      FactoryGirl.create(
        :account_pricing_tier,
        :select,
        account: account,
        pricing_tier: silver_pricing_tier
      )
      expect(item_account_price(inventory_item, account)).to eq(Money.new(471))
    end
  end

  describe "#item_sell_price" do
    it "returns the price without considering account pricing tier" do
      FactoryGirl.create(
        :account_pricing_tier,
        :select,
        account: account,
        pricing_tier: silver_pricing_tier
      )
      expect(item_sell_price(inventory_item)).to eq(Money.new(500))
    end
  end

  describe "#option_price" do
    let(:option_group) { create(:option_group) }
    let(:inventory_item_option) { create(
      :option_inventory_item,
      sell_price: 6,
      premium_sell_price: 5
    ) }
    let(:iiog) {
      InventoryItemsOptionGroup.create(
        inventory_item_id: inventory_item_option.id,
        option_group_id: option_group.id
      )
    }

    before do
      inventory_item.option_groups << option_group
    end

    context "when price is not 0" do
      it "displays the option price" do
        expect(option_price(account, iiog)).to eq("(+$5.00)")
      end
    end

    context "when price is 0" do
      it "does not display price" do
        inventory_item_option.update_attributes(premium_sell_price: 0)
        expect(option_price(account, iiog)).to be_nil
      end
    end

  end
end
