require "spec_helper"

describe OptionGroupsHelper do
  let(:option_group){ create(:option_group) }
  let(:ingredient_option){ create(:option_inventory_item) }
  let(:side_option){ create(:inventory_item) }

  describe "#tab_info" do

    context "when the option group has ingredients only" do
      before do
        option_group.inventory_items << ingredient_option
      end

      it "activates the ingredients tab" do
        expect(tab_info(option_group)[:class][:ingredients]).to eq("active")
      end

      it "makes the ingredients tab tabbable" do
        expect(tab_info(option_group)[:toggle][:ingredients]).to eq("tab")
      end

      it "disables the sides tab" do
        expect(tab_info(option_group)[:class][:sides]).to eq("disabled")
      end

      it "makes the sides tab not tabbable" do
        expect(tab_info(option_group)[:toggle][:sides]).to eq("")
      end
    end

    context "when the option group has sides only" do
      before do
        option_group.inventory_items << side_option
      end

      it "activates the sides tab" do
        expect(tab_info(option_group)[:class][:sides]).to eq("active")
      end

      it "makes the sides tab tabbable" do
        expect(tab_info(option_group)[:toggle][:sides]).to eq("tab")
      end

      it "disables the ingredients tab" do
        expect(tab_info(option_group)[:class][:ingredients]).to eq("disabled")
      end

      it "makes the ingredients tab not tabbable" do
        expect(tab_info(option_group)[:toggle][:ingredients]).to eq("")
      end
    end

    context "when the option group has neither ingredients nor sides (is empty)" do
      it "activates the ingredients tab" do
        expect(tab_info(option_group)[:class][:ingredients]).to eq("active")
      end

      it "makes the ingredients tab tabbable" do
        expect(tab_info(option_group)[:toggle][:ingredients]).to eq("tab")
      end

      it "makes the sides tab tabbable" do
        expect(tab_info(option_group)[:toggle][:sides]).to eq("tab")
      end
    end
  end
end
