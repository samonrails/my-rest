require "spec_helper"

describe SearchSortPaginateHelper do

  describe "ssp_sort_link" do
    it "should generate link" do
      helper.stub(:params) {{ "action"=>"index", "controller"=>"admin/managed_services_reports" }}
      helper.ssp_sort_link(:account).should match("<a href=\"/admin/managed_services_reports")
    end
  end

  describe "column_display" do
    it "should returns true" do
      expect(helper.column_display({ "action"=>"index", "controller"=>"admin/managed_services_reports" }, "Account")).to eq(true) 
    end

    it "should returns false" do
      column = ["Event End Time", "Setup Start Time", "Setup End Time"].sample
      expect(helper.column_display({ "action"=>"index", "controller"=>"admin/managed_services_reports" }, column)).to eq(false) 
    end
  end

  describe "label_to_display" do
    it "should return 'Show Accounts Created From' label" do
      helper.stub(:params) {{ "action"=>"index", "controller"=>"admin/managed_services_reports" }}
      helper.request.stub(:path) {"/admin/general_reports"}
      expect(helper.label_to_display({ :name => :created_at, :as => :datetimerange }, "start_time")).to eq("Show Accounts Created From")
    end

    it "should return 'Show Accounts Created To' label" do
      helper.stub(:params) {{ "action"=>"index", "controller"=>"admin/managed_services_reports" }}
      helper.request.stub(:path) {"/admin/general_reports"}
      expect(helper.label_to_display({ :name => :created_at, :as => :datetimerange }, "end_time")).to eq("Show Accounts Created To")
    end

    it "should return '' label" do
      helper.stub(:params) {{ "action"=>"index", "controller"=>"admin/managed_services_reports" }}
      expect(helper.label_to_display({ :name => :event_start_time, :as => :datetimerange }, "start_time")).to eq("Event Start Time")
    end

    it "should return '' label" do
      helper.stub(:params) {{ "action"=>"index", "controller"=>"admin/managed_services_reports" }}
      expect(helper.label_to_display({ :name => :event_start_time, :as => :datetimerange }, "end_time")).to eq("Event End Time")
    end
  end

end