require "spec_helper"

describe Select::SelectEmailPresenter do

  let(:account_1)  { FactoryGirl.create(:account) }
  let(:account_2)  { FactoryGirl.create(:account) }
  let(:building_1) { FactoryGirl.create(:building) }
  let(:building_2) { FactoryGirl.create(:building) }

  let(:location_1) { FactoryGirl.create(:location, building: building_1, account: account_1) }
  let(:location_2) { FactoryGirl.create(:location, building: building_2, account: account_2) }

  let(:featured_vendor)   { FactoryGirl.create(:vendor) }
  let(:vendor_2)          { FactoryGirl.create(:vendor) }
  let(:vendor_3)          { FactoryGirl.create(:vendor) }
  let(:vendor_4)          { FactoryGirl.create(:vendor) }

  let(:inventory_item_1)  { FactoryGirl.create(:inventory_item, signature_item: true,  meal_type: "entrees") }
  let(:inventory_item_2)  { FactoryGirl.create(:inventory_item, signature_item: false, meal_type: "salads") }
  let(:inventory_item_3)  { FactoryGirl.create(:inventory_item, signature_item: false, meal_type: "desserts", retail_price: 10) }
  let(:inventory_item_4)  { FactoryGirl.create(:inventory_item, signature_item: true,  meal_type: "entrees") }
  let(:inventory_item_5)  { FactoryGirl.create(:inventory_item, signature_item: false, meal_type: "salads") }
  let(:inventory_item_6)  { FactoryGirl.create(:inventory_item, signature_item: false, meal_type: "desserts", retail_price: 10) }
  let(:inventory_item_7)  { FactoryGirl.create(:inventory_item, signature_item: true,  meal_type: "entrees") }
  let(:inventory_item_8)  { FactoryGirl.create(:inventory_item, signature_item: false, meal_type: "salads") }
  let(:inventory_item_9)  { FactoryGirl.create(:inventory_item, signature_item: false, meal_type: "desserts", retail_price: 10) }
  let(:inventory_item_10) { FactoryGirl.create(:inventory_item, signature_item: true,  meal_type: "entrees") }
  let(:inventory_item_11) { FactoryGirl.create(:inventory_item, signature_item: false, meal_type: "salads") }
  let(:inventory_item_12) { FactoryGirl.create(:inventory_item, signature_item: false, meal_type: "desserts", retail_price: 10) }

  let(:menu_template_1)   { FactoryGirl.create(:menu_template, vendor: featured_vendor, inventory_items: [inventory_item_1, inventory_item_2, inventory_item_3]) }
  let(:menu_template_2)   { FactoryGirl.create(:menu_template, vendor: vendor_2, inventory_items: [inventory_item_4, inventory_item_5, inventory_item_6]) }
  let(:menu_template_3)   { FactoryGirl.create(:menu_template, vendor: vendor_3, inventory_items: [inventory_item_7, inventory_item_8, inventory_item_9]) }
  let(:menu_template_4)   { FactoryGirl.create(:menu_template, vendor: vendor_4, inventory_items: [inventory_item_10, inventory_item_11, inventory_item_12]) }

  let(:select_event_vendor_1) { FactoryGirl.create(:select_event_vendor, vendor: featured_vendor, menu_template: menu_template_1) }
  let(:select_event_vendor_2) { FactoryGirl.create(:select_event_vendor, vendor: vendor_2, menu_template: menu_template_2) }
  let(:select_event_vendor_3) { FactoryGirl.create(:select_event_vendor, vendor: vendor_3, menu_template: menu_template_3) }
  let(:select_event_vendor_4) { FactoryGirl.create(:select_event_vendor, vendor: vendor_4, menu_template: menu_template_4) }

  let(:select_event_1) do
    FactoryGirl.create(:select_event, :with_location_zip_code_tax,
                                      ordering_window_start_time: (DateTime.now - 1.hour),
                                      ordering_window_end_time: (DateTime.now + 1.hour),
                                      featured_vendor_id: featured_vendor.id,
                                      select_event_vendors: [select_event_vendor_1,
                                                             select_event_vendor_2,
                                                             select_event_vendor_3])
  end
  let(:select_event_2) do
    FactoryGirl.create(:select_event, :with_location_zip_code_tax,
                                      ordering_window_start_time: (DateTime.now - 1.hour),
                                      ordering_window_end_time: (DateTime.now + 1.hour),
                                      select_event_vendors: [select_event_vendor_1,
                                                             select_event_vendor_2,
                                                             select_event_vendor_3,
                                                             select_event_vendor_4])
  end

  context "select email with 3 (or fewer) vendors" do
    let(:email_presenter) { Select::SelectEmailPresenter.new(select_event_1) }

    it "should use the layout for 3 (or fewer) vendors" do
      expect(email_presenter.layout_name).to eq("select_event_email_3_vendors")
    end

    it "knows the count of non-featured vendors" do
      expect(email_presenter.vendors.count).to eq(2)
    end

    it "knows about the featured vendor" do
      expect(email_presenter.featured_vendor.vendor_name).to eq(featured_vendor.name)
    end

    it "knows about other non-featured vendors" do
      other_vendors = email_presenter.vendors
      expect(other_vendors.first.vendor_name).to eq(select_event_vendor_2.vendor.name)
      expect(other_vendors.second.vendor_name).to eq(select_event_vendor_3.vendor.name)
    end

    it "knows about signature inventory items for the event (known_for)" do
      known_for_names = email_presenter.known_for.map(&:item_name).sort
      compare_names = [inventory_item_1.name_public,
                       inventory_item_4.name_public,
                       inventory_item_7.name_public].sort
      expect(known_for_names.count).to eq(3)
      expect(known_for_names).to eq(compare_names)
    end

    it "knows about salads for the event (health_friendly)" do
      health_friendly_names = email_presenter.health_friendly.items.map(&:item_name).sort
      compare_names = [inventory_item_2.name_public,
                       inventory_item_5.name_public,
                       inventory_item_8.name_public].sort
      expect(health_friendly_names.count).to eq(3)
      expect(health_friendly_names).to eq(compare_names)
    end

    it "knows about items with retail price under $7 for the event (cost_conscious)" do
      cost_conscious_names = email_presenter.cost_conscious.items.map(&:item_name).sort
      compare_names = [inventory_item_1.name_public,
                       inventory_item_2.name_public,
                       inventory_item_4.name_public,
                       inventory_item_5.name_public,
                       inventory_item_7.name_public,
                       inventory_item_8.name_public].sort
      expect(cost_conscious_names.count).to eq(6)
      expect(cost_conscious_names).to eq(compare_names)
    end

  end

  context "select email with 4 (or more) vendors" do
    let(:email_presenter) { Select::SelectEmailPresenter.new(select_event_2) }

    it "should use the default layout" do
      expect(email_presenter.layout_name).to eq("select_event_email_default")
    end

    it "knows the count of non-featured vendors" do
      expect(email_presenter.vendors.count).to eq(3)
    end

    it "knows about the featured vendor" do
      expect(email_presenter.featured_vendor.vendor_name).to eq(featured_vendor.name)
    end

    it "knows about other non-featured vendors" do
      other_vendors = email_presenter.vendors
      expect(other_vendors.first.vendor_name).to eq(select_event_vendor_2.vendor.name)
      expect(other_vendors.second.vendor_name).to eq(select_event_vendor_3.vendor.name)
      expect(other_vendors.third.vendor_name).to eq(select_event_vendor_4.vendor.name)
    end

    it "knows about signature inventory items for the event (known_for)" do
      known_for_names = email_presenter.known_for.map(&:item_name).sort
      compare_names = [inventory_item_1.name_public,
                       inventory_item_4.name_public,
                       inventory_item_7.name_public,
                       inventory_item_10.name_public].sort
      expect(known_for_names.count).to eq(4)
      expect(known_for_names).to eq(compare_names)
    end

    it "knows about salads for the event (health_friendly)" do
      health_friendly_names = email_presenter.health_friendly.items.map(&:item_name).sort
      compare_names = [inventory_item_2.name_public,
                       inventory_item_5.name_public,
                       inventory_item_8.name_public,
                       inventory_item_11.name_public].sort
      expect(health_friendly_names.count).to eq(4)
      expect(health_friendly_names).to eq(compare_names)
    end

    it "knows about items with retail price under $7 for the event (cost_conscious)" do
      cost_conscious_names = email_presenter.cost_conscious.items.map(&:item_name).sort
      compare_names = [inventory_item_1.name_public,
                       inventory_item_2.name_public,
                       inventory_item_4.name_public,
                       inventory_item_5.name_public,
                       inventory_item_7.name_public,
                       inventory_item_8.name_public,
                       inventory_item_10.name_public,
                       inventory_item_11.name_public].sort
      expect(cost_conscious_names.count).to eq(8)
      expect(cost_conscious_names).to eq(compare_names)
    end


  end

end
