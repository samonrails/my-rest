require "spec_helper"

describe MyPresenter do

  let(:period) { "Lunch" }
  let(:date) { DateTime.now.strftime("%Y-%m-%d") }
  let(:select_event) { FactoryGirl.create(:select_event, :with_account_locations, :with_vendor_and_item, ordering_window_start_time: (DateTime.now - 1.hour), ordering_window_end_time: (DateTime.now + 1.hour), delivery_time: (DateTime.now + 2.hours)) }
  let(:user) { FactoryGirl.create(:user, :confirmed, accounts: [select_event.account]) }
  let(:select_order) { FactoryGirl.create(:select_order, :with_event_order_item, select_event: select_event, user: user, status: :checkout_complete, created_at: DateTime.now) }
  let(:mypresenter_options) {{user: user, date: date, building_id: select_event.location.building.id, period: period}}
  let(:myp) { MyPresenter.new(mypresenter_options) }

  it "has a user" do
    expect(myp.user).to eq(user)
  end

  it "has a date" do
    expect(myp.date).to eq(Date.parse(date))
  end

  it "has a building" do
    expect(myp.building).to eq(select_event.location.building)
  end

  it "has a period" do
    expect(myp.period).to eq("Lunch")
  end

  it "knows about available buildings" do
    expect(myp.buildings).to eq([select_event.location.building])
  end

  describe "#week_nav" do
    it "names abbreviate the days of the week" do
      myp.week_nav.each_with_index do |d, i|
        expect(d.abbr).to eq(d.date.strftime('%^a'))
      end
    end

    it "returns the date in the hash" do
      day = Date.today
      myp.week_nav.each_with_index do |d, i|
        expect(d.date).to eq(day + i.days)
      end
    end

    it "returns the selected status in the hash" do
      myp.week_nav.each_with_index do |d, i|
        if myp.date == d.date
          expect(d.selected).to be_true
        else
          expect(d.selected).to be_false
        end
      end
    end
  end

  it 'knows how to display open text' do
    future = DateTime.now + 24.hours
    select_event.update_attributes(ordering_window_start_time: future)
    expect(myp.window_open_text(select_event)).to_not eq("")
  end

  it "knows about select events to display" do
    # Without this myp test below fails! :(
    expect(select_event).to be_valid
    # myp should have the correct number of events
    expect(myp.display_events.count).to eq(1)

    # myp should display the correct event
    display_event = myp.display_events.first[:display]
    expect(display_event.vendor_name).to eq(select_event.vendors.first.name)
    expect(display_event.start_timestamp).to eq(select_event.ordering_window_start_time_utc.to_i)
    expect(display_event.end_timestamp).to eq(select_event.ordering_window_end_time_utc.to_i)
    expect(display_event.delivery_timestamp).to eq(select_event.delivery_time.to_i)
  end

  it "knows about previous activities to display" do
    # Without this myp test below fails! :(
    expect(select_order).to be_valid
    # should have the correct number of previous activities
    previous_activities = myp.previous_activities
    expect(previous_activities.count).to eq(1)

    # Ensure that our lone activity data is as expected
    inventory_item = select_event.vendors.first.menu_templates.first.inventory_items.first
    activity = previous_activities.first
    expect(activity.vendor_name).to eq(inventory_item.vendor.name)
    expect(activity.item_name).to eq(inventory_item.name_public)
    expect(activity.description).to eq(inventory_item.description)
  end

  it "knows about items to recommend" do
    # Without this myp test below fails! :(
    expect(select_order).to be_valid

    # should have the correct number of recommendations
    recommendations = myp.recommendations
    expect(recommendations.count).to eq(2)

    # Ensure that our recommendation data is as expected
    recommendation = recommendations.first
    inventory_item = select_event.vendors.first.menu_templates.first.inventory_items.first
    expect(recommendation.item_name).to eq(inventory_item.name_public)
    expect(recommendation.vendor_name).to eq(inventory_item.vendor.name)

    # Ensure that our recommendation data is as expected
    recommendation = recommendations.second
    expect(recommendation.item_name).to eq(inventory_item.name_public)
    expect(recommendation.vendor_name).to eq(inventory_item.vendor.name)
  end

  context "order for the day" do
    it "knows when you have ordered for the day" do
      # Without this myp test below fails! :(
      expect(select_order).to be_valid

      # should have the correct number of orders
      events_orders = myp.events_orders
      expect(events_orders.count).to eq(1)

      # Ensure that our order data is as expected
      display_order = events_orders.first
      inventory_item = select_event.vendors.first.menu_templates.first.inventory_items.first
      expect(display_order.item_name).to eq(inventory_item.name_public)
      expect(display_order.vendor_name).to eq(inventory_item.vendor.name)
    end

    it "knows when you have not ordered for the day" do
      # Without this myp test below fails! :(
      expect(select_order).to be_valid
      select_order.destroy

      # should have the correct number of orders
      events_orders = myp.events_orders
      expect(events_orders).to be_nil
    end
  end
end
