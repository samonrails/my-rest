require "spec_helper"

describe Checkout::MenuPagePresenter do

  let(:user){ create(:user, first_name: "Maximus", last_name: "Decimus Meridius" ) }
  let(:select_event){ create(:select_event, :with_location_zip_code_tax, delivery_time: DateTime.parse("2014-01-01 13:00:00"), ordering_window_start_time:  DateTime.parse("2013-12-30 19:59:00") , ordering_window_end_time: DateTime.parse("2013-12-31 19:59:00") ) }
  let(:select_order) { create(:select_order) }
  let(:soi) { create(:select_order_item, quantity: 1, status: :current) }
  let(:item){ soi.inventory_item }
  let(:upsell_item) { create(:inventory_item, vendor: vendor, eligible_for_select_add_ons: true) }
  let(:vendor){ item.vendor }
  let(:select_event_vendor) { create(:select_event_vendor, vendor: vendor, select_event: select_event) }
  let(:select_event_menu_group){ create(:select_event_menu_group, select_event_vendor: select_event_vendor) }
  let(:select_event_menu_item){ create(:select_event_menu_item, inventory_item: item, select_event_menu_group: select_event_menu_group) }
  let(:upsell_select_event_menu_item){ create(:select_event_menu_item, inventory_item: upsell_item, select_event_menu_group: select_event_menu_group) }

  let(:presenter){ Checkout::MenuPagePresenter.new(user, select_event) }

  before do
    select_event.vendors << vendor
    select_order.select_order_items << soi
    user.select_orders << select_order
    select_event.select_event_vendors << select_event_vendor
  end

  it "has a user" do
    expect(presenter.user).to eq(user)
  end

  it "has a select_event" do
    expect(presenter.select_event).to eq(select_event)
  end

  it "knows how to get recommended items" do
    presenter.stub(__recommended_items: [select_event_menu_item])
    info = OpenStruct.new(select_event_menu_item.display_info)
    expect(presenter.recommended_items).to eq([info])
  end

  it "knows how to get best selling items" do
    presenter.should_receive(:__best_selling_items).and_return([ select_event_menu_item ])
    info = OpenStruct.new(select_event_menu_item.display_info)
    expect(presenter.best_selling_items).to eq([info])
  end

  it "knows how many best selling item pages exist" do
    semis = double(:semis, count: 150)
    select_event.stub(select_event_menu_items: semis)
    expect(presenter.total_best_selling_pages).to eq(3)
  end

  it "knows if multiple vendors" do
    expect(presenter.multiple_vendors?).to be_false
  end

  it "knows if multiple vendors" do
    expect(presenter.multiple_vendors?).to be_false
  end

  it "knows if pagination is needed" do
    expect(presenter.pagination?).to be_false
  end

  context "when displaying item info" do
    let(:item2) { create(:inventory_item, name_public: "grub", description: "This is mighty tasty!")}
    let(:menu_item) { create(:select_event_menu_item, inventory_item: item2) }
    let(:group) { create(:option_group, name: "Add On's", required: 1) }
    let(:vendor) { create(:vendor, name: "Wendys") }

    before do
      vendor.inventory_items << item2
      item2.dietary_restriction_list.add("Vegan")
      item2.save
      group.inventory_items << item
    end

    it "knows if headline needed" do
      select_event_vendor.select_event_menu_groups << select_event_menu_group
      select_event_menu_group.select_event_menu_items << menu_item
      pps = presenter.previously_purchased_menu_items
      expect(presenter.headline(menu_item.display_info, pps)).to be_nil
    end

    it "knows the option group name" do
      expect(presenter.option_group_name(group)).to eq("Add On's")
    end

    it "knows if required" do
      expect(presenter.option_group_required(group)).to eq("(Required:1)")
    end

    it "knows if nothing required" do
      group.required = 0
      expect(presenter.option_group_required(group)).to eq("")
    end

    it "knows the option items" do
      expect(presenter.option_group_items(group).map(&:inventory_item)).to include(item)
    end
  end

  describe "when displaying subsidy information" do

    context "percentage subsidy" do
      let(:select_event){ create(:select_event_with_locations, :percentage_subsidy_10)}

      it "knows percentage no cap" do
        h = "10.0% subsidy available from #{select_event.account.name} "
        expect(presenter.subsidy_headline).to eq(h)
      end

      it "knows percentage with cap" do
        user.select_orders.destroy_all
        select_event.update_attributes(subsidy_percentage_fixed_amount_cap_cents: 1000, is_subsidy_percentage_capped: true)
        h = "10.0% subsidy available from #{select_event.account.name} up to $0.00"
        expect(presenter.subsidy_headline).to eq(h)
      end

      it "knows if its a promotion or not" do
        select_event.update_attributes(is_subsidy_promotion: true)
        h = "10.0% subsidy available from Fooda "
        expect(presenter.subsidy_headline).to eq(h)
      end
    end

    context "fixed subsidy" do
      let(:select_event){ create(:select_event_with_locations, :fixed_subsidy_10) }

      it "knows fixed amount" do
        h = "$10.00 subsidy available from #{select_event.account.name} "
        expect(presenter.subsidy_headline(Money.new(1000))).to eq(h)
      end

      it "knows if its a promotion or not" do
        select_event.update_attributes(is_subsidy_promotion: true)
        h = "$10.00 subsidy available from Fooda "
        expect(presenter.subsidy_headline(Money.new(1000))).to eq(h)
      end

      it "knows when to hide the headline" do
        expect(presenter.hide_headline?(Money.new(500))).to be_false
        expect(presenter.hide_headline?(Money.new(0))).to be_true
      end
    end

    context "full subsidy" do
      let(:select_event){ create(:select_event_with_locations, :full_subsidy) }

      it "knows fully subsidized" do
        h = "Full subsidy available from #{select_event.account.name} "
        expect(presenter.subsidy_headline).to eq(h)
      end
    end

    context "no subsidy" do
      let(:select_event) { create(:select_event_with_locations, :no_subsidy) }

      it "knows to hide the headline" do
        expect(presenter.hide_headline?(Money.new(0))).to be_true
      end
    end
  end

  describe "#upsell_items_for" do
    it "includes items marked as select upsell items" do
      expect(presenter.upsell_items_for(select_event_menu_item)).to include(upsell_select_event_menu_item)
    end

    it "does not include items that are not marked as select upsell items" do
      expect(presenter.upsell_items_for(select_event_menu_item)).not_to include(select_event_menu_item)
    end
  end

end
