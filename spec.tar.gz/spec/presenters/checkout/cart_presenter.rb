require "spec_helper"

describe Checkout::CartPresenter do
  let(:user){ create(:user, first_name: "Maximus", last_name: "Decimus Meridius" ) }
  let(:select_event){ create(:select_event, :fixed_subsidy_5) }
  let(:item){ create(:inventory_item) }
  let(:option_group){ create(:option_group) }
  let(:item_option){ create(:option_inventory_item) }
  let(:address){ create(:address, :work, :with_zip_code_tax) }
  let(:building){ create(:building, address: address) }
  let(:location){ create(:location, building: building) } 

  let(:presenter){ Checkout::CartPresenter.new(user.cart, select_event) }

  before { select_event.locations << location }

  describe "when giving a subsidy notification" do
    
    it "displays fixed amount left from company" do
      notification = "You have $5.00 left from your Company."
      expect(presenter.subsidy_notification_at_checkout).to eq(notification)
    end

    it "displays fixed amount left from fooda" do
      select_event.is_subsidy_promotion = true
      notification = "You have $5.00 left from Fooda."
      expect(presenter.subsidy_notification_at_checkout).to eq(notification)
    end

    it "displays empty string if necessary" do
      select_event.subsidy = "percentage"
      expect(presenter.subsidy_notification_at_checkout).to eq("")
    end
  end

  describe "displaying delivery details" do    

    it "knows the delivery address" do
      expect(presenter.delivery_address_top).to eq("600 W. Chicago Ave.")
    end

    it "knows the delivery address" do
      expect(presenter.delivery_address_bottom).to eq("Chicago IL 60654")
    end

  end

  describe "when displaying location information" do

    it "knows if there are many location options" do
      expect(presenter.location_options?).to be_false
    end

    it "knows if a location is included" do
      select_event.locations << location
      expect(presenter.location_options).to include([location.building_address_notes, location.id])
    end
  end
end
